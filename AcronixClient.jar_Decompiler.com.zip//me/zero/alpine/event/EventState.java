package me.zero.alpine.event;

public enum EventState {
   PRE,
   POST;
}
