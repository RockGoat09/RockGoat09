package me.zero.alpine.listener;

public interface Listenable {
}
