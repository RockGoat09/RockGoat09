package org.spongepowered.asm.service;

public interface ITransformer {
}
