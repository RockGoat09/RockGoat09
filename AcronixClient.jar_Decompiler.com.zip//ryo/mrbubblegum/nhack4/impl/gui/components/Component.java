package ryo.mrbubblegum.nhack4.impl.gui.components;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import ryo.mrbubblegum.nhack4.impl.gui.LiteGui;
import ryo.mrbubblegum.nhack4.impl.gui.components.items.Item;
import ryo.mrbubblegum.nhack4.impl.gui.components.items.buttons.Button;
import ryo.mrbubblegum.nhack4.impl.gui.components.items.buttons.ModuleButton;
import ryo.mrbubblegum.nhack4.impl.util.ColorUtil;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Feature;
import ryo.mrbubblegum.nhack4.lite.client.ClickGui;
import ryo.mrbubblegum.nhack4.lite.client.Colors;
import ryo.mrbubblegum.nhack4.lite.hud.HUD;
import ryo.mrbubblegum.nhack4.loader.Loader;

public class Component extends Feature {
   private final ArrayList<Item> items = new ArrayList();
   private final ResourceLocation dots = new ResourceLocation("textures/dots.png");
   public boolean drag;
   private int x;
   private int y;
   private int x2;
   private int y2;
   private int width;
   private int height;
   private boolean open;
   private boolean hidden = false;

   public Component(String name, int x, int y, boolean open) {
      super(name);
      this.x = x;
      this.y = y;
      this.width = (Integer)ClickGui.getInstance().guiWidth.getValue();
      this.height = 19;
      this.open = open;
      this.setupItems();
   }

   public void setupItems() {
   }

   private void drag(int mouseX, int mouseY) {
      if (this.drag) {
         this.x = this.x2 + mouseX;
         this.y = this.y2 + mouseY;
      }
   }

   private void drawOutline(float thickness, int color) {
      float totalItemHeight = 0.0F;
      if (this.open) {
         totalItemHeight = this.getTotalItemHeight() - 2.0F;
      }

      RenderUtil.drawLine((float)this.x, (float)this.y - 1.5F, (float)this.x, (float)(this.y + this.height) + totalItemHeight, thickness, ColorUtil.toRGBA((Integer)ClickGui.getInstance().o_red.getValue(), (Integer)ClickGui.getInstance().o_green.getValue(), (Integer)ClickGui.getInstance().o_blue.getValue(), (Integer)ClickGui.getInstance().o_alpha.getValue()));
      RenderUtil.drawLine((float)this.x, (float)this.y - 1.5F, (float)(this.x + this.width), (float)this.y - 1.5F, thickness, ColorUtil.toRGBA((Integer)ClickGui.getInstance().o_red.getValue(), (Integer)ClickGui.getInstance().o_green.getValue(), (Integer)ClickGui.getInstance().o_blue.getValue(), (Integer)ClickGui.getInstance().o_alpha.getValue()));
      RenderUtil.drawLine((float)(this.x + this.width), (float)this.y - 1.5F, (float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, thickness, ColorUtil.toRGBA((Integer)ClickGui.getInstance().o_red.getValue(), (Integer)ClickGui.getInstance().o_green.getValue(), (Integer)ClickGui.getInstance().o_blue.getValue(), (Integer)ClickGui.getInstance().o_alpha.getValue()));
      RenderUtil.drawLine((float)this.x, (float)(this.y + this.height) + totalItemHeight, (float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, thickness, ColorUtil.toRGBA((Integer)ClickGui.getInstance().o_red.getValue(), (Integer)ClickGui.getInstance().o_green.getValue(), (Integer)ClickGui.getInstance().o_blue.getValue(), (Integer)ClickGui.getInstance().o_alpha.getValue()));
   }

   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drag(mouseX, mouseY);
      float totalItemHeight = this.open ? this.getTotalItemHeight() - 2.0F : 0.0F;
      int color = -7829368;
      if (this.open) {
         RenderUtil.drawRect((float)this.x, (float)this.y + 14.0F, (float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, 0);
         if ((Boolean)ClickGui.getInstance().outlineNew.getValue()) {
            this.drawOutline((Float)ClickGui.getInstance().outlineThickness.getValue(), color);
         }
      }

      if ((Boolean)ClickGui.getInstance().devSettings.getValue()) {
         color = (Boolean)ClickGui.getInstance().colorSync.getValue() ? Colors.INSTANCE.getCurrentColorHex() : ColorUtil.toARGB((Integer)ClickGui.getInstance().topRed.getValue(), (Integer)ClickGui.getInstance().topGreen.getValue(), (Integer)ClickGui.getInstance().topBlue.getValue(), (Integer)ClickGui.getInstance().topAlpha.getValue());
      }

      if ((Boolean)ClickGui.getInstance().rainbowRolling.getValue() && (Boolean)ClickGui.getInstance().colorSync.getValue() && (Boolean)Colors.INSTANCE.rainbow.getValue()) {
         RenderUtil.drawGradientRect((float)this.x, (float)this.y - 1.5F, (float)this.width, (float)(this.height - 4), (Integer)HUD.getInstance().colorMap.get(MathUtil.clamp(this.y, 0, this.renderer.scaledHeight)), (Integer)HUD.getInstance().colorMap.get(MathUtil.clamp(this.y + this.height - 4, 0, this.renderer.scaledHeight)));
      } else {
         RenderUtil.drawRect((float)this.x, (float)this.y - 1.5F, (float)(this.x + this.width), (float)(this.y + this.height - 6), color);
      }

      if ((Boolean)ClickGui.getInstance().frameSettings.getValue()) {
         if ((Boolean)ClickGui.getInstance().colorSync.getValue()) {
            Colors.INSTANCE.getCurrentColorHex();
         } else {
            ColorUtil.toARGB((Integer)ClickGui.getInstance().frameRed.getValue(), (Integer)ClickGui.getInstance().frameGreen.getValue(), (Integer)ClickGui.getInstance().frameBlue.getValue(), (Integer)ClickGui.getInstance().frameAlpha.getValue());
         }

         RenderUtil.drawRect((float)this.x, (float)this.y + 11.0F, (float)(this.x + this.width), (float)(this.y + this.height - 6), (Boolean)ClickGui.getInstance().colorSync.getValue() ? Colors.INSTANCE.getCurrentColor().getRGB() : ColorUtil.toARGB((Integer)ClickGui.getInstance().frameRed.getValue(), (Integer)ClickGui.getInstance().frameGreen.getValue(), (Integer)ClickGui.getInstance().frameBlue.getValue(), (Integer)ClickGui.getInstance().frameAlpha.getValue()));
      }

      if (this.open) {
         RenderUtil.drawRect((float)this.x, (float)this.y + 12.5F, (float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, ColorUtil.toRGBA((Integer)ClickGui.getInstance().b_red.getValue(), (Integer)ClickGui.getInstance().b_green.getValue(), (Integer)ClickGui.getInstance().b_blue.getValue(), (Integer)ClickGui.getInstance().b_alpha.getValue()));
      }

      if (this.open) {
         RenderUtil.drawRect((float)this.x, (float)this.y + 12.5F, (float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, 0);
         if ((Boolean)ClickGui.getInstance().outline.getValue()) {
            Color currentColor;
            if ((Boolean)ClickGui.getInstance().rainbowRolling.getValue()) {
               GlStateManager.func_179090_x();
               GlStateManager.func_179147_l();
               GlStateManager.func_179118_c();
               GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
               GlStateManager.func_179103_j(7425);
               GL11.glBegin(1);
               currentColor = new Color((Integer)HUD.getInstance().colorMap.get(MathUtil.clamp(this.y, 0, this.renderer.scaledHeight)));
               GL11.glColor4f((float)currentColor.getRed() / 255.0F, (float)currentColor.getGreen() / 255.0F, (float)currentColor.getBlue() / 255.0F, (float)currentColor.getAlpha() / 255.0F);
               GL11.glVertex3f((float)(this.x + this.width), (float)this.y - 1.5F, 0.0F);
               GL11.glVertex3f((float)this.x, (float)this.y - 1.5F, 0.0F);
               GL11.glVertex3f((float)this.x, (float)this.y - 1.5F, 0.0F);
               float currentHeight = (float)this.getHeight() - 1.5F;
               Iterator var8 = this.getItems().iterator();

               Item item;
               while(var8.hasNext()) {
                  item = (Item)var8.next();
                  currentColor = new Color((Integer)HUD.getInstance().colorMap.get(MathUtil.clamp((int)((float)this.y + (currentHeight += (float)item.getHeight() + 1.5F)), 0, this.renderer.scaledHeight)));
                  GL11.glColor4f((float)currentColor.getRed() / 255.0F, (float)currentColor.getGreen() / 255.0F, (float)currentColor.getBlue() / 255.0F, (float)currentColor.getAlpha() / 255.0F);
                  GL11.glVertex3f((float)this.x, (float)this.y + currentHeight, 0.0F);
                  GL11.glVertex3f((float)this.x, (float)this.y + currentHeight, 0.0F);
               }

               currentColor = new Color((Integer)HUD.getInstance().colorMap.get(MathUtil.clamp((int)((float)(this.y + this.height) + totalItemHeight), 0, this.renderer.scaledHeight)));
               GL11.glColor4f((float)currentColor.getRed() / 255.0F, (float)currentColor.getGreen() / 255.0F, (float)currentColor.getBlue() / 255.0F, (float)currentColor.getAlpha() / 255.0F);
               GL11.glVertex3f((float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, 0.0F);
               GL11.glVertex3f((float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, 0.0F);
               var8 = this.getItems().iterator();

               while(var8.hasNext()) {
                  item = (Item)var8.next();
                  currentColor = new Color((Integer)HUD.getInstance().colorMap.get(MathUtil.clamp((int)((float)this.y + (currentHeight -= (float)item.getHeight() + 1.5F)), 0, this.renderer.scaledHeight)));
                  GL11.glColor4f((float)currentColor.getRed() / 255.0F, (float)currentColor.getGreen() / 255.0F, (float)currentColor.getBlue() / 255.0F, (float)currentColor.getAlpha() / 255.0F);
                  GL11.glVertex3f((float)(this.x + this.width), (float)this.y + currentHeight, 0.0F);
                  GL11.glVertex3f((float)(this.x + this.width), (float)this.y + currentHeight, 0.0F);
               }

               GL11.glVertex3f((float)(this.x + this.width), (float)this.y, 0.0F);
               GL11.glEnd();
               GlStateManager.func_179103_j(7424);
               GlStateManager.func_179084_k();
               GlStateManager.func_179141_d();
               GlStateManager.func_179098_w();
            } else {
               GlStateManager.func_179090_x();
               GlStateManager.func_179147_l();
               GlStateManager.func_179118_c();
               GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
               GlStateManager.func_179103_j(7425);
               GL11.glBegin(2);
               currentColor = (Boolean)ClickGui.getInstance().colorSync.getValue() ? new Color(Colors.INSTANCE.getCurrentColorHex()) : new Color(Loader.colorManager.getColorAsIntFullAlpha());
               GL11.glColor4f((float)currentColor.getRed(), (float)currentColor.getGreen(), (float)currentColor.getBlue(), (float)currentColor.getAlpha());
               GL11.glVertex3f((float)this.x, (float)this.y - 1.5F, 0.0F);
               GL11.glVertex3f((float)(this.x + this.width), (float)this.y - 1.5F, 0.0F);
               GL11.glVertex3f((float)(this.x + this.width), (float)(this.y + this.height) + totalItemHeight, 0.0F);
               GL11.glVertex3f((float)this.x, (float)(this.y + this.height) + totalItemHeight, 0.0F);
               GL11.glEnd();
               GlStateManager.func_179103_j(7424);
               GlStateManager.func_179084_k();
               GlStateManager.func_179141_d();
               GlStateManager.func_179098_w();
            }
         }
      }

      if ((Boolean)ClickGui.getInstance().categoryTextCenter.getValue()) {
         Loader.textManager.drawStringWithShadow(this.getName(), (float)this.x + (float)(this.width / 2) - (float)(this.renderer.getStringWidth(this.getName()) / 2), (float)this.y - 4.0F - (float)LiteGui.getClickGui().getTextOffset(), -1);
      } else {
         Loader.textManager.drawStringWithShadow(this.getName(), (float)this.x + 3.0F, (float)this.y - 4.0F - (float)LiteGui.getClickGui().getTextOffset(), -1);
      }

      if (this.open) {
         if ((Boolean)ClickGui.getInstance().categoryDots.getValue()) {
            mc.func_110434_K().func_110577_a(this.dots);
            ModuleButton.drawCompleteImage((float)this.x - 5.5F + (float)this.width - 12.0F, (float)this.y - 8.0F - (float)LiteGui.getClickGui().getTextOffset(), 12, 11);
         }

         float y = (float)(this.getY() + this.getHeight()) - 3.0F;
         Iterator var11 = this.getItems().iterator();

         while(var11.hasNext()) {
            Item item = (Item)var11.next();
            if (!item.isHidden()) {
               item.setLocation((float)this.x + 2.0F, y);
               item.setWidth(this.getWidth() - 4);
               item.drawScreen(mouseX, mouseY, partialTicks);
               y += (float)item.getHeight() + 1.5F;
            }
         }
      }

   }

   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
      if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
         this.x2 = this.x - mouseX;
         this.y2 = this.y - mouseY;
         LiteGui.getClickGui().getComponents().forEach((component) -> {
            if (component.drag) {
               component.drag = false;
            }

         });
         this.drag = true;
      } else if (mouseButton == 1 && this.isHovering(mouseX, mouseY)) {
         this.open = !this.open;
         Util.mc.func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
      } else if (this.open) {
         this.getItems().forEach((item) -> {
            item.mouseClicked(mouseX, mouseY, mouseButton);
         });
      }
   }

   public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
      if (releaseButton == 0) {
         this.drag = false;
      }

      if (this.open) {
         this.getItems().forEach((item) -> {
            item.mouseReleased(mouseX, mouseY, releaseButton);
         });
      }
   }

   public void onKeyTyped(char typedChar, int keyCode) {
      if (this.open) {
         this.getItems().forEach((item) -> {
            item.onKeyTyped(typedChar, keyCode);
         });
      }
   }

   public void addButton(Button button) {
      this.items.add(button);
   }

   public int getX() {
      return this.x;
   }

   public void setX(int x) {
      this.x = x;
   }

   public int getY() {
      return this.y;
   }

   public void setY(int y) {
      this.y = y;
   }

   public int getWidth() {
      return this.width;
   }

   public void setWidth(int width) {
      this.width = width;
   }

   public int getHeight() {
      return this.height;
   }

   public void setHeight(int height) {
      this.height = height;
   }

   public boolean isHidden() {
      return this.hidden;
   }

   public void setHidden(boolean hidden) {
      this.hidden = hidden;
   }

   public boolean isOpen() {
      return this.open;
   }

   public final ArrayList<Item> getItems() {
      return this.items;
   }

   private boolean isHovering(int mouseX, int mouseY) {
      return mouseX >= this.getX() && mouseX <= this.getX() + this.getWidth() && mouseY >= this.getY() && mouseY <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
   }

   private float getTotalItemHeight() {
      float height = 0.0F;

      Item item;
      for(Iterator var2 = this.getItems().iterator(); var2.hasNext(); height += (float)item.getHeight() + 1.5F) {
         item = (Item)var2.next();
      }

      return height;
   }
}
