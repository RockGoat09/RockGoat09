package ryo.mrbubblegum.nhack4.impl.gui.particle;

import javax.vecmath.Vector2f;
import net.minecraft.client.gui.ScaledResolution;
import ryo.mrbubblegum.nhack4.impl.util.ColorUtil;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.lite.client.ClickGui;

public final class ParticleSystem {
   private final int PARTS = 200;
   private final Particle[] particles = new Particle[200];
   private ScaledResolution scaledResolution;

   public ParticleSystem(ScaledResolution scaledResolution) {
      this.scaledResolution = scaledResolution;

      for(int i = 0; i < 200; ++i) {
         this.particles[i] = new Particle(new Vector2f((float)(Math.random() * (double)scaledResolution.func_78326_a()), (float)(Math.random() * (double)scaledResolution.func_78328_b())));
      }

   }

   public static double map(double value, double a, double b, double c, double d) {
      value = (value - a) / (b - a);
      return c + value * (d - c);
   }

   public void update() {
      for(int i = 0; i < 200; ++i) {
         Particle particle = this.particles[i];
         if (this.scaledResolution != null) {
            boolean isOffScreenX = particle.getPos().x > (float)this.scaledResolution.func_78326_a() || particle.getPos().x < 0.0F;
            boolean isOffScreenY = particle.getPos().y > (float)this.scaledResolution.func_78328_b() || particle.getPos().y < 0.0F;
            if (isOffScreenX || isOffScreenY) {
               particle.respawn(this.scaledResolution);
            }
         }

         particle.update();
      }

   }

   public void render(int mouseX, int mouseY) {
      if ((Boolean)ClickGui.getInstance().particles.getValue()) {
         for(int i = 0; i < 200; ++i) {
            Particle particle = this.particles[i];

            for(int j = 1; j < 200; ++j) {
               if (i != j) {
                  Particle otherParticle = this.particles[j];
                  Vector2f diffPos = new Vector2f(particle.getPos());
                  diffPos.sub(otherParticle.getPos());
                  float diff = diffPos.length();
                  int distance = (Integer)ClickGui.getInstance().particleLength.getValue() / (this.scaledResolution.func_78325_e() <= 1 ? 3 : this.scaledResolution.func_78325_e());
                  int lineAlpha;
                  if (diff < (float)distance && (lineAlpha = (int)map((double)diff, (double)distance, 0.0D, 0.0D, 127.0D)) > 8) {
                     RenderUtil.drawLine(particle.getPos().x + particle.getSize() / 2.0F, particle.getPos().y + particle.getSize() / 2.0F, otherParticle.getPos().x + otherParticle.getSize() / 2.0F, otherParticle.getPos().y + otherParticle.getSize() / 2.0F, 1.0F, Particle.changeAlpha(ColorUtil.toRGBA((Integer)ClickGui.getInstance().particlered.getValue(), (Integer)ClickGui.getInstance().particlegreen.getValue(), (Integer)ClickGui.getInstance().particleblue.getValue()), lineAlpha));
                  }
               }
            }

            particle.render(mouseX, mouseY);
         }

      }
   }

   public ScaledResolution getScaledResolution() {
      return this.scaledResolution;
   }

   public void setScaledResolution(ScaledResolution scaledResolution) {
      this.scaledResolution = scaledResolution;
   }
}
