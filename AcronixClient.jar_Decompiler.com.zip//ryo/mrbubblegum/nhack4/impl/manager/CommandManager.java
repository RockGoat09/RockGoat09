package ryo.mrbubblegum.nhack4.impl.manager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import ryo.mrbubblegum.nhack4.impl.util.TextUtil;
import ryo.mrbubblegum.nhack4.lite.Feature;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.command.commands.BindCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.BookCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.BrowseCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ChatClearCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ClearRamCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ConfigCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.CoordsCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.CrashCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.FakePlayerCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.FriendCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.HelpCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.HistoryCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ModuleCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.NameMCCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.OpenFolderCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.PeekCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.PornCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.PrefixCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.QueueCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ReloadCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ReloadSoundCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.ToggleCommand;
import ryo.mrbubblegum.nhack4.system.command.commands.UnloadCommand;

public class CommandManager extends Feature {
   private final ArrayList<Command> commands = new ArrayList();
   private String clientMessage;
   private String prefix;

   public CommandManager() {
      super("Command");
      this.clientMessage = TextUtil.coloredString("[", TextUtil.Color.WHITE) + TextUtil.coloredString("NHACK4", TextUtil.Color.LIGHT_PURPLE) + TextUtil.coloredString("]", TextUtil.Color.WHITE);
      this.prefix = ".";
      this.commands.add(new BindCommand());
      this.commands.add(new ModuleCommand());
      this.commands.add(new NameMCCommand());
      this.commands.add(new PrefixCommand());
      this.commands.add(new FakePlayerCommand());
      this.commands.add(new BrowseCommand());
      this.commands.add(new OpenFolderCommand());
      this.commands.add(new ChatClearCommand());
      this.commands.add(new QueueCommand());
      this.commands.add(new ConfigCommand());
      this.commands.add(new ClearRamCommand());
      this.commands.add(new CoordsCommand());
      this.commands.add(new FriendCommand());
      this.commands.add(new HelpCommand());
      this.commands.add(new ReloadCommand());
      this.commands.add(new UnloadCommand());
      this.commands.add(new ReloadSoundCommand());
      this.commands.add(new PeekCommand());
      this.commands.add(new ToggleCommand());
      this.commands.add(new BookCommand());
      this.commands.add(new CrashCommand());
      this.commands.add(new HistoryCommand());
      this.commands.add(new PornCommand());
   }

   public static String[] removeElement(String[] input, int indexToDelete) {
      LinkedList<String> result = new LinkedList();

      for(int i = 0; i < input.length; ++i) {
         if (i != indexToDelete) {
            result.add(input[i]);
         }
      }

      return (String[])result.toArray(input);
   }

   private static String strip(String str, String key) {
      return str.startsWith(key) && str.endsWith(key) ? str.substring(key.length(), str.length() - key.length()) : str;
   }

   public void executeCommand(String command) {
      String[] parts = command.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
      String name = parts[0].substring(1);
      String[] args = removeElement(parts, 0);

      for(int i = 0; i < args.length; ++i) {
         if (args[i] != null) {
            args[i] = strip(args[i], "\"");
         }
      }

      Iterator var7 = this.commands.iterator();

      Command c;
      do {
         if (!var7.hasNext()) {
            Command.sendMessage("Unknown command. Try 'help' for a list of commands.");
            return;
         }

         c = (Command)var7.next();
      } while(!c.getName().equalsIgnoreCase(name));

      c.execute(parts);
   }

   public Command getCommandByName(String name) {
      Iterator var2 = this.commands.iterator();

      Command command;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         command = (Command)var2.next();
      } while(!command.getName().equals(name));

      return command;
   }

   public ArrayList<Command> getCommands() {
      return this.commands;
   }

   public String getClientMessage() {
      return this.clientMessage;
   }

   public void setClientMessage(String clientMessage) {
      this.clientMessage = clientMessage;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setPrefix(String prefix) {
      this.prefix = prefix;
   }
}
