package ryo.mrbubblegum.nhack4.impl.manager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import ryo.mrbubblegum.nhack4.impl.util.Util;

public class InventoryManager implements Util {
   public Map<String, List<ItemStack>> inventories = new HashMap();
   private int recoverySlot = -1;

   public void update() {
      if (this.recoverySlot != -1) {
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(this.recoverySlot == 8 ? 7 : this.recoverySlot + 1));
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(this.recoverySlot));
         mc.field_71439_g.field_71071_by.field_70461_c = this.recoverySlot;
         mc.field_71442_b.func_78750_j();
         this.recoverySlot = -1;
      }

   }

   public void recoverSilent(int slot) {
      this.recoverySlot = slot;
   }
}
