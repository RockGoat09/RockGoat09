package ryo.mrbubblegum.nhack4.impl.manager;

import ryo.mrbubblegum.nhack4.lite.Feature;

public class MovementManager extends Feature {
   public void setMotion(double d, double d2, double d3) {
      if (mc.field_71439_g != null) {
         if (mc.field_71439_g.func_184218_aH()) {
            mc.field_71439_g.field_184239_as.field_70159_w = d;
            mc.field_71439_g.field_184239_as.field_70181_x = d2;
            mc.field_71439_g.field_184239_as.field_70179_y = d;
         } else {
            mc.field_71439_g.field_70159_w = d;
            mc.field_71439_g.field_70181_x = d2;
            mc.field_71439_g.field_70179_y = d3;
         }
      }

   }
}
