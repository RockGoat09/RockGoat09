package ryo.mrbubblegum.nhack4.impl.util;

import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;

public class MovementUtil implements Util {
   public static Vec3d calculateLine(Vec3d x1, Vec3d x2, double distance) {
      double length = Math.sqrt(multiply(x2.field_72450_a - x1.field_72450_a) + multiply(x2.field_72448_b - x1.field_72448_b) + multiply(x2.field_72449_c - x1.field_72449_c));
      double unitSlopeX = (x2.field_72450_a - x1.field_72450_a) / length;
      double unitSlopeY = (x2.field_72448_b - x1.field_72448_b) / length;
      double unitSlopeZ = (x2.field_72449_c - x1.field_72449_c) / length;
      double x = x1.field_72450_a + unitSlopeX * distance;
      double y = x1.field_72448_b + unitSlopeY * distance;
      double z = x1.field_72449_c + unitSlopeZ * distance;
      return new Vec3d(x, y, z);
   }

   public static Vec2f calculateLineNoY(Vec2f x1, Vec2f x2, double distance) {
      double length = Math.sqrt(multiply((double)(x2.field_189982_i - x1.field_189982_i)) + multiply((double)(x2.field_189983_j - x1.field_189983_j)));
      double unitSlopeX = (double)(x2.field_189982_i - x1.field_189982_i) / length;
      double unitSlopeZ = (double)(x2.field_189983_j - x1.field_189983_j) / length;
      float x = (float)((double)x1.field_189982_i + unitSlopeX * distance);
      float z = (float)((double)x1.field_189983_j + unitSlopeZ * distance);
      return new Vec2f(x, z);
   }

   public static double multiply(double one) {
      return one * one;
   }

   public static double[] forward(double d) {
      float f = Minecraft.func_71410_x().field_71439_g.field_71158_b.field_192832_b;
      float f2 = Minecraft.func_71410_x().field_71439_g.field_71158_b.field_78902_a;
      float f3 = Minecraft.func_71410_x().field_71439_g.field_70126_B + (Minecraft.func_71410_x().field_71439_g.field_70177_z - Minecraft.func_71410_x().field_71439_g.field_70126_B) * Minecraft.func_71410_x().func_184121_ak();
      if (f != 0.0F) {
         if (f2 > 0.0F) {
            f3 += (float)(f > 0.0F ? -45 : 45);
         } else if (f2 < 0.0F) {
            f3 += (float)(f > 0.0F ? 45 : -45);
         }

         f2 = 0.0F;
         if (f > 0.0F) {
            f = 1.0F;
         } else if (f < 0.0F) {
            f = -1.0F;
         }
      }

      double d2 = Math.sin(Math.toRadians((double)(f3 + 90.0F)));
      double d3 = Math.cos(Math.toRadians((double)(f3 + 90.0F)));
      double d4 = (double)f * d * d3 + (double)f2 * d * d2;
      double d5 = (double)f * d * d2 - (double)f2 * d * d3;
      return new double[]{d4, d5};
   }

   public static boolean isMoving(EntityLivingBase entityLivingBase) {
      return entityLivingBase.field_191988_bg != 0.0F || entityLivingBase.field_70702_br != 0.0F;
   }

   public static void setSpeed(EntityLivingBase entityLivingBase, double d) {
      double[] dArray = forward(d);
      entityLivingBase.field_70159_w = dArray[0];
      entityLivingBase.field_70179_y = dArray[1];
   }

   public static double getBaseMoveSpeed() {
      double d = 0.2873D;
      if (Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71439_g.func_70644_a((Potion)Objects.requireNonNull(Potion.func_188412_a(1)))) {
         int n = ((PotionEffect)Objects.requireNonNull(Minecraft.func_71410_x().field_71439_g.func_70660_b((Potion)Objects.requireNonNull(Potion.func_188412_a(1))))).func_76458_c();
         d *= 1.0D + 0.2D * (double)(n + 1);
      }

      return d;
   }

   public static void setMotion(double x, double y, double z) {
      if (mc.field_71439_g != null) {
         if (mc.field_71439_g.func_184218_aH()) {
            mc.field_71439_g.field_184239_as.field_70159_w = x;
            mc.field_71439_g.field_184239_as.field_70181_x = y;
            mc.field_71439_g.field_184239_as.field_70179_y = x;
         } else {
            mc.field_71439_g.field_70159_w = x;
            mc.field_71439_g.field_70181_x = y;
            mc.field_71439_g.field_70179_y = z;
         }
      }

   }

   public static Vec3d extrapolatePlayerPositionWithGravity(EntityPlayer player, int ticks) {
      double totalDistance = 0.0D;
      double extrapolatedMotionY = player.field_70181_x;

      for(int i = 0; i < ticks; ++i) {
         totalDistance += multiply(player.field_70159_w) + multiply(extrapolatedMotionY) + multiply(player.field_70179_y);
         extrapolatedMotionY -= 0.1D;
      }

      double horizontalDistance = multiply(player.field_70159_w) + multiply(player.field_70179_y) * (double)ticks;
      Vec2f horizontalVec = calculateLineNoY(new Vec2f((float)player.field_70142_S, (float)player.field_70136_U), new Vec2f((float)player.field_70165_t, (float)player.field_70161_v), horizontalDistance);
      double addedY = player.field_70181_x;
      double finalY = player.field_70163_u;
      Vec3d tempPos = new Vec3d((double)horizontalVec.field_189982_i, player.field_70163_u, (double)horizontalVec.field_189983_j);

      for(int i = 0; i < ticks; ++i) {
         finalY += addedY;
         addedY -= 0.1D;
      }

      RayTraceResult result = mc.field_71441_e.func_72933_a(player.func_174791_d(), new Vec3d(tempPos.field_72450_a, finalY, tempPos.field_72449_c));
      return result != null && result.field_72313_a != Type.ENTITY ? result.field_72307_f : new Vec3d(tempPos.field_72450_a, finalY, tempPos.field_72449_c);
   }

   public static Vec3d extrapolatePlayerPosition(EntityPlayer player, int ticks) {
      double totalDistance = 0.0D;
      double extrapolatedMotionY = player.field_70181_x;

      for(int i = 0; i < ticks; ++i) {
      }

      Vec3d lastPos = new Vec3d(player.field_70142_S, player.field_70137_T, player.field_70136_U);
      Vec3d currentPos = new Vec3d(player.field_70165_t, player.field_70163_u, player.field_70161_v);
      double distance = multiply(player.field_70159_w) + multiply(player.field_70181_x) + multiply(player.field_70179_y);
      double extrapolatedPosY = player.field_70163_u;
      if (!player.func_189652_ae()) {
         extrapolatedPosY -= 0.1D;
      }

      Vec3d tempVec = calculateLine(lastPos, currentPos, distance * (double)ticks);
      Vec3d finalVec = new Vec3d(tempVec.field_72450_a, extrapolatedPosY, tempVec.field_72449_c);
      RayTraceResult result = mc.field_71441_e.func_72933_a(player.func_174791_d(), finalVec);
      return new Vec3d(tempVec.field_72450_a, player.field_70163_u, tempVec.field_72449_c);
   }
}
