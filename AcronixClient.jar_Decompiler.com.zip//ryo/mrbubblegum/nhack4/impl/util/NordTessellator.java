package ryo.mrbubblegum.nhack4.impl.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class NordTessellator extends Tessellator {
   public static NordTessellator INSTANCE = new NordTessellator();

   public NordTessellator() {
      super(2097152);
   }

   public static void prepare(int mode2) {
      prepareGL();
      begin(mode2);
   }

   public static void prepareGL() {
      GL11.glBlendFunc(770, 771);
      GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.func_187441_d(1.5F);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179140_f();
      GlStateManager.func_179129_p();
      GlStateManager.func_179141_d();
      GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
   }

   public static void begin(int mode2) {
      INSTANCE.func_178180_c().func_181668_a(mode2, DefaultVertexFormats.field_181706_f);
   }

   public static void release() {
      render();
      releaseGL();
   }

   public static void render() {
      INSTANCE.func_78381_a();
   }

   public static void releaseGL() {
      GlStateManager.func_179089_o();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179098_w();
      GlStateManager.func_179147_l();
      GlStateManager.func_179126_j();
   }

   public static void drawBox(BlockPos blockPos, int argb, int sides) {
      int a = argb >>> 24 & 255;
      int r = argb >>> 16 & 255;
      int g = argb >>> 8 & 255;
      int b = argb & 255;
      drawBox(blockPos, r, g, b, a, sides);
   }

   public static void drawBox(double x, double y, double z, int argb, int sides) {
      int a = argb >>> 24 & 255;
      int r = argb >>> 16 & 255;
      int g = argb >>> 8 & 255;
      int b = argb & 255;
      drawBox(INSTANCE.func_178180_c(), x, y, z, 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
   }

   public static void drawBoxSmall(double x, double y, double z, int argb, int sides) {
      int a = argb >>> 24 & 255;
      int r = argb >>> 16 & 255;
      int g = argb >>> 8 & 255;
      int b = argb & 255;
      drawBox(INSTANCE.func_178180_c(), x, y, z, 0.25F, 0.25F, 0.25F, r, g, b, a, sides);
   }

   public static void drawBox(BlockPos blockPos, int r, int g, int b, int a, int sides) {
      drawBox(INSTANCE.func_178180_c(), (double)blockPos.func_177958_n(), (double)blockPos.func_177956_o(), (double)blockPos.func_177952_p(), 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
   }

   public static BufferBuilder getBufferBuilder() {
      return INSTANCE.func_178180_c();
   }

   public static void drawBox(BufferBuilder buffer, double x, double y, double z, float w, float h, float d, int r, int g, int b, int a, int sides) {
      if ((sides & 1) != 0) {
         buffer.func_181662_b(x + (double)w, y, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 2) != 0) {
         buffer.func_181662_b(x + (double)w, y + (double)h, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y + (double)h, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y + (double)h, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y + (double)h, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 4) != 0) {
         buffer.func_181662_b(x + (double)w, y, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y + (double)h, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y + (double)h, z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 8) != 0) {
         buffer.func_181662_b(x, y, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y + (double)h, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y + (double)h, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 16) != 0) {
         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y + (double)h, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x, y + (double)h, z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 32) != 0) {
         buffer.func_181662_b(x + (double)w, y, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y + (double)h, z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b(x + (double)w, y + (double)h, z + (double)d).func_181669_b(r, g, b, a).func_181675_d();
      }

   }

   public static void drawLines(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
      if ((sides & 17) != 0) {
         buffer.func_181662_b((double)x, (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)x, (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 18) != 0) {
         buffer.func_181662_b((double)x, (double)(y + h), (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)x, (double)(y + h), (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 33) != 0) {
         buffer.func_181662_b((double)(x + w), (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 34) != 0) {
         buffer.func_181662_b((double)(x + w), (double)(y + h), (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)(y + h), (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 5) != 0) {
         buffer.func_181662_b((double)x, (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 6) != 0) {
         buffer.func_181662_b((double)x, (double)(y + h), (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)(y + h), (double)z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 9) != 0) {
         buffer.func_181662_b((double)x, (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 10) != 0) {
         buffer.func_181662_b((double)x, (double)(y + h), (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)(y + h), (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 20) != 0) {
         buffer.func_181662_b((double)x, (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)x, (double)(y + h), (double)z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 36) != 0) {
         buffer.func_181662_b((double)(x + w), (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)(y + h), (double)z).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 24) != 0) {
         buffer.func_181662_b((double)x, (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)x, (double)(y + h), (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

      if ((sides & 40) != 0) {
         buffer.func_181662_b((double)(x + w), (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)(y + h), (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      }

   }

   public static void drawRectangle(float x, float y, float w, float h, int color) {
      float r = (float)(color >> 16 & 255) / 255.0F;
      float g = (float)(color >> 8 & 255) / 255.0F;
      float b = (float)(color & 255) / 255.0F;
      float a = (float)(color >> 24 & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)h, 0.0D).func_181666_a(r, g, b, a).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)h, 0.0D).func_181666_a(r, g, b, a).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)y, 0.0D).func_181666_a(r, g, b, a).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_181666_a(r, g, b, a).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179084_k();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
   }

   public static void drawBoundingBoxBlockPos(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPos(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPosXInMiddle(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPosXInMiddle2(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPosSouth(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPosNorth(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPosEast(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBottomBlockPosWest(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha / 2).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxBlockPosHalf(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 0.5D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBottomBoxBlockPos(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 0.0D, z + 1.0D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxChestBlockPos(BlockPos bp, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = (double)bp.func_177958_n() + 0.06D - mc.func_175598_ae().field_78730_l;
      double y = (double)bp.func_177956_o() - mc.func_175598_ae().field_78731_m;
      double z = (double)bp.func_177952_p() + 0.06D - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 0.881D, y + 0.875D, z + 0.881D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxItem(double xloc, double yloc, double zloc, float width, int r, int g, int b, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Minecraft mc = Minecraft.func_71410_x();
      double x = xloc - 0.2D - mc.func_175598_ae().field_78730_l;
      double y = yloc - mc.func_175598_ae().field_78731_m;
      double z = zloc - 0.2D - mc.func_175598_ae().field_78728_n;
      AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 0.4D, y + 0.4D, z + 0.4D);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      bufferbuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181669_b(r, g, b, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBoxFace(AxisAlignedBB bb, float width, int red, int green, int blue, int alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181669_b(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181669_b(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181669_b(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181669_b(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawFullFace(AxisAlignedBB bb, BlockPos blockPos, float width, int red, int green, int blue, int alpha, int alpha2) {
      prepare(7);
      drawFace(blockPos, red, green, blue, alpha, 63);
      release();
      drawBoundingBoxFace(bb, width, red, green, blue, alpha2);
   }

   public static void drawFace(BlockPos blockPos, int argb, int sides) {
      int a = argb >>> 24 & 255;
      int r = argb >>> 16 & 255;
      int g = argb >>> 8 & 255;
      int b = argb & 255;
      drawFace(blockPos, r, g, b, a, sides);
   }

   public static void drawBoxBottom(BufferBuilder buffer, float x, float y, float z, float w, float d, int r, int g, int b, int a) {
      buffer.func_181662_b((double)(x + w), (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
      buffer.func_181662_b((double)(x + w), (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      buffer.func_181662_b((double)x, (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
      buffer.func_181662_b((double)x, (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
   }

   public static void drawBoxBottom(BlockPos bp, int r, int g, int b, int a) {
      prepare(7);
      drawBoxBottom(INSTANCE.func_178180_c(), (float)bp.func_177958_n(), (float)bp.func_177956_o(), (float)bp.func_177952_p(), 1.0F, 1.0F, r, g, b, a);
      release();
   }

   public static void drawFace(BlockPos blockPos, int r, int g, int b, int a, int sides) {
      drawFace(INSTANCE.func_178180_c(), (float)blockPos.func_177958_n(), (float)blockPos.func_177956_o(), (float)blockPos.func_177952_p(), 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
   }

   public static void drawFace(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
      if ((sides & 1) != 0) {
         buffer.func_181662_b((double)(x + w), (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)(x + w), (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)x, (double)y, (double)(z + d)).func_181669_b(r, g, b, a).func_181675_d();
         buffer.func_181662_b((double)x, (double)y, (double)z).func_181669_b(r, g, b, a).func_181675_d();
      }

   }

   public static Vec3d getInterpolatedPos(Entity entity, float ticks) {
      return (new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)).func_178787_e(getInterpolatedAmount(entity, (double)ticks));
   }

   public static Vec3d getInterpolatedAmount(Entity entity, double ticks) {
      return getInterpolatedAmount(entity, ticks, ticks, ticks);
   }

   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
      return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
   }

   public static void drawBorderedRect(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
      enableGL2D();
      fakeGuiRect(x + width, y + width, x1 - width, y1 - width, internalColor);
      fakeGuiRect(x + width, y, x1 - width, y + width, borderColor);
      fakeGuiRect(x, y, x + width, y1, borderColor);
      fakeGuiRect(x1 - width, y, x1, y1, borderColor);
      fakeGuiRect(x + width, y1 - width, x1 - width, y1, borderColor);
      disableGL2D();
   }

   public static void fakeGuiRect(double left, double top, double right, double bottom, int color) {
      double j;
      if (left < right) {
         j = left;
         left = right;
         right = j;
      }

      if (top < bottom) {
         j = top;
         top = bottom;
         bottom = j;
      }

      float f3 = (float)(color >> 24 & 255) / 255.0F;
      float f = (float)(color >> 16 & 255) / 255.0F;
      float f1 = (float)(color >> 8 & 255) / 255.0F;
      float f2 = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.func_179131_c(f, f1, f2, f3);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
      bufferbuilder.func_181662_b(left, bottom, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b(right, bottom, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b(right, top, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b(left, top, 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
   }

   private static void enableGL2D() {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
   }

   private static void disableGL2D() {
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
   }
}
