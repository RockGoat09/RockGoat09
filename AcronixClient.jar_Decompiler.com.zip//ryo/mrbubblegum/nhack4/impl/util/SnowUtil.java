package ryo.mrbubblegum.nhack4.impl.util;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public final class SnowUtil {
   private static final IntBuffer VIEWPORT = GLAllocation.func_74527_f(16);
   private static final FloatBuffer MODELVIEW = GLAllocation.func_74529_h(16);
   private static final FloatBuffer PROJECTION = GLAllocation.func_74529_h(16);

   public static void updateModelViewProjectionMatrix() {
      GL11.glGetFloat(2982, MODELVIEW);
      GL11.glGetFloat(2983, PROJECTION);
      GL11.glGetInteger(2978, VIEWPORT);
      ScaledResolution res = new ScaledResolution(Minecraft.func_71410_x());
      GLUProjection.getInstance().updateMatrices(VIEWPORT, MODELVIEW, PROJECTION, (double)((float)res.func_78326_a() / (float)Minecraft.func_71410_x().field_71443_c), (double)((float)res.func_78328_b() / (float)Minecraft.func_71410_x().field_71440_d));
   }

   public static void DrawPolygon(double x, double y, int radius, int sides, int color) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(6, DefaultVertexFormats.field_181705_e);
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      bufferbuilder.func_181662_b(x, y, 0.0D).func_181675_d();
      double TWICE_PI = 6.283185307179586D;

      for(int i = 0; i <= sides; ++i) {
         double angle = 6.283185307179586D * (double)i / (double)sides + Math.toRadians(180.0D);
         bufferbuilder.func_181662_b(x + Math.sin(angle) * (double)radius, y + Math.cos(angle) * (double)radius, 0.0D).func_181675_d();
      }

      tessellator.func_78381_a();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

   public static void drawRect(float x, float y, float w, float h, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
   }

   public static void drawRect(float x, float y, float w, float h, int color, float alpha) {
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)w, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
   }

   public static void drawGradientRect(float left, float top, float right, float bottom, int startColor, int endColor) {
      float f = (float)(startColor >> 24 & 255) / 255.0F;
      float f1 = (float)(startColor >> 16 & 255) / 255.0F;
      float f2 = (float)(startColor >> 8 & 255) / 255.0F;
      float f3 = (float)(startColor & 255) / 255.0F;
      float f4 = (float)(endColor >> 24 & 255) / 255.0F;
      float f5 = (float)(endColor >> 16 & 255) / 255.0F;
      float f6 = (float)(endColor >> 8 & 255) / 255.0F;
      float f7 = (float)(endColor & 255) / 255.0F;
      GlStateManager.func_179090_x();
      GlStateManager.func_179147_l();
      GlStateManager.func_179118_c();
      GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.func_179103_j(7425);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)right, (double)top, 0.0D).func_181666_a(f1, f2, f3, f).func_181675_d();
      bufferbuilder.func_181662_b((double)left, (double)top, 0.0D).func_181666_a(f1, f2, f3, f).func_181675_d();
      bufferbuilder.func_181662_b((double)left, (double)bottom, 0.0D).func_181666_a(f5, f6, f7, f4).func_181675_d();
      bufferbuilder.func_181662_b((double)right, (double)bottom, 0.0D).func_181666_a(f5, f6, f7, f4).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179103_j(7424);
      GlStateManager.func_179084_k();
      GlStateManager.func_179141_d();
      GlStateManager.func_179098_w();
   }

   public static void drawTriangle(float x, float y, float size, float theta, int color) {
      GL11.glTranslated((double)x, (double)y, 0.0D);
      GL11.glRotatef(180.0F + theta, 0.0F, 0.0F, 1.0F);
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      GL11.glColor4f(red, green, blue, alpha);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(1.0F);
      GL11.glBegin(6);
      GL11.glVertex2d(0.0D, (double)size);
      GL11.glVertex2d((double)(1.0F * size), (double)(-size));
      GL11.glVertex2d((double)(-(1.0F * size)), (double)(-size));
      GL11.glEnd();
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glRotatef(-180.0F - theta, 0.0F, 0.0F, 1.0F);
      GL11.glTranslated((double)(-x), (double)(-y), 0.0D);
   }

   public static void drawOutlineRect(float x, float y, float w, float h, float thickness, int c) {
      drawRect(x, y, x - thickness, h, c);
      drawRect(w + thickness, y, w, h, c);
      drawRect(x, y, w, y - thickness, c);
      drawRect(x, h + thickness, w, h, c);
   }

   public static void drawLine(float x, float y, float x1, float y1, float thickness, int hex) {
      float red = (float)(hex >> 16 & 255) / 255.0F;
      float green = (float)(hex >> 8 & 255) / 255.0F;
      float blue = (float)(hex & 255) / 255.0F;
      float alpha = (float)(hex >> 24 & 255) / 255.0F;
      GlStateManager.func_179094_E();
      GlStateManager.func_179090_x();
      GlStateManager.func_179147_l();
      GlStateManager.func_179118_c();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      GlStateManager.func_179103_j(7425);
      GL11.glLineWidth(thickness);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)x1, (double)y1, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179103_j(7424);
      GL11.glDisable(2848);
      GlStateManager.func_179084_k();
      GlStateManager.func_179141_d();
      GlStateManager.func_179098_w();
      GlStateManager.func_179121_F();
   }

   public static void drawLine3D(float x, float y, float z, float x1, float y1, float z1, float thickness, int hex) {
      float red = (float)(hex >> 16 & 255) / 255.0F;
      float green = (float)(hex >> 8 & 255) / 255.0F;
      float blue = (float)(hex & 255) / 255.0F;
      float alpha = (float)(hex >> 24 & 255) / 255.0F;
      GlStateManager.func_179094_E();
      GlStateManager.func_179090_x();
      GlStateManager.func_179147_l();
      GlStateManager.func_179118_c();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      GlStateManager.func_179103_j(7425);
      GL11.glLineWidth(thickness);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GlStateManager.func_179097_i();
      GL11.glEnable(34383);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)x, (double)y, (double)z).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b((double)x1, (double)y1, (double)z1).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179103_j(7424);
      GL11.glDisable(2848);
      GlStateManager.func_179126_j();
      GL11.glDisable(34383);
      GlStateManager.func_179084_k();
      GlStateManager.func_179141_d();
      GlStateManager.func_179098_w();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBox(AxisAlignedBB bb, float width, float red, float green, float blue, float alpha) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(width);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, 0.0F).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, 0.0F).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
      tessellator.func_78381_a();
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawBoundingBox(AxisAlignedBB bb, float width, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      drawBoundingBox(bb, width, red, green, blue, alpha);
   }

   public static void drawPlane(double x, double y, double z, AxisAlignedBB bb, float width, int color) {
      GL11.glPushMatrix();
      GL11.glTranslated(x, y, z);
      drawPlane(bb, width, color);
      GL11.glPopMatrix();
   }

   public static void drawPlane(AxisAlignedBB axisalignedbb, float width, int color) {
      GlStateManager.func_179094_E();
      GlStateManager.func_187441_d(width);
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_187428_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ONE);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      drawPlane(axisalignedbb, color);
      GL11.glDisable(2848);
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void drawPlane(AxisAlignedBB boundingBox, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      double minX = boundingBox.field_72340_a;
      double minY = boundingBox.field_72338_b;
      double minZ = boundingBox.field_72339_c;
      double maxX = boundingBox.field_72336_d;
      double maxY = boundingBox.field_72337_e;
      double maxZ = boundingBox.field_72334_f;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(minX, minY, minZ).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(maxX, minY, maxZ).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(minX, minY, maxZ).func_181666_a(red, green, blue, 0.0F).func_181675_d();
      bufferbuilder.func_181662_b(maxZ, minY, minZ).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
   }

   public static void drawFilledBox(AxisAlignedBB bb, int color) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179147_l();
      GlStateManager.func_179097_i();
      GlStateManager.func_179120_a(770, 771, 0, 1);
      GlStateManager.func_179090_x();
      GlStateManager.func_179132_a(false);
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      GlStateManager.func_179121_F();
   }

   public static void glScissor(float x, float y, float x1, float y1, ScaledResolution sr) {
      GL11.glScissor((int)(x * (float)sr.func_78325_e()), (int)((float)Minecraft.func_71410_x().field_71440_d - y1 * (float)sr.func_78325_e()), (int)((x1 - x) * (float)sr.func_78325_e()), (int)((y1 - y) * (float)sr.func_78325_e()));
   }

   public static void glBillboard(float x, float y, float z) {
      float scale = 0.02666667F;
      GlStateManager.func_179137_b((double)x - Minecraft.func_71410_x().func_175598_ae().field_78725_b, (double)y - Minecraft.func_71410_x().func_175598_ae().field_78726_c, (double)z - Minecraft.func_71410_x().func_175598_ae().field_78723_d);
      GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(-Minecraft.func_71410_x().field_71439_g.field_70177_z, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(Minecraft.func_71410_x().field_71439_g.field_70125_A, Minecraft.func_71410_x().field_71474_y.field_74320_O == 2 ? -1.0F : 1.0F, 0.0F, 0.0F);
      GlStateManager.func_179152_a(-scale, -scale, scale);
   }

   public static void glBillboardDistanceScaled(float x, float y, float z, EntityPlayer player, float scale) {
      glBillboard(x, y, z);
      int distance = (int)player.func_70011_f((double)x, (double)y, (double)z);
      float scaleDistance = (float)distance / 2.0F / (2.0F + (2.0F - scale));
      if (scaleDistance < 1.0F) {
         scaleDistance = 1.0F;
      }

      GlStateManager.func_179152_a(scaleDistance, scaleDistance, scaleDistance);
   }

   public static void drawTexture(float x, float y, float textureX, float textureY, float width, float height) {
      float f = 0.00390625F;
      float f1 = 0.00390625F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      bufferbuilder.func_181662_b((double)x, (double)(y + height), 0.0D).func_187315_a((double)(textureX * f), (double)((textureY + height) * f1)).func_181675_d();
      bufferbuilder.func_181662_b((double)(x + width), (double)(y + height), 0.0D).func_187315_a((double)((textureX + width) * f), (double)((textureY + height) * f1)).func_181675_d();
      bufferbuilder.func_181662_b((double)(x + width), (double)y, 0.0D).func_187315_a((double)((textureX + width) * f), (double)(textureY * f1)).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_187315_a((double)(textureX * f), (double)(textureY * f1)).func_181675_d();
      tessellator.func_78381_a();
   }

   public static void drawTexture(float x, float y, float width, float height, float u, float v, float t, float s) {
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(4, DefaultVertexFormats.field_181707_g);
      bufferbuilder.func_181662_b((double)(x + width), (double)y, 0.0D).func_187315_a((double)t, (double)v).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)y, 0.0D).func_187315_a((double)u, (double)v).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)(y + height), 0.0D).func_187315_a((double)u, (double)s).func_181675_d();
      bufferbuilder.func_181662_b((double)x, (double)(y + height), 0.0D).func_187315_a((double)u, (double)s).func_181675_d();
      bufferbuilder.func_181662_b((double)(x + width), (double)(y + height), 0.0D).func_187315_a((double)t, (double)s).func_181675_d();
      bufferbuilder.func_181662_b((double)(x + width), (double)y, 0.0D).func_187315_a((double)t, (double)v).func_181675_d();
      tessellator.func_78381_a();
   }

   public static void DrawNodusBetterRect(double x, double y, double x1, double y1, int color2, int color) {
      GL11.glEnable(3042);
      GL11.glEnable(2848);
      drawRect((float)((int)x), (float)((int)y), (float)((int)x1), (float)((int)y1), color);
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      drawRect((float)((int)x * 2 - 1), (float)((int)y * 2), (float)((int)x * 2), (float)((int)y1 * 2 - 1), color2);
      drawRect((float)((int)x * 2), (float)((int)y * 2 - 1), (float)((int)x1 * 2), (float)((int)y * 2), color2);
      drawRect((float)((int)x1 * 2), (float)((int)y * 2), (float)((int)x1 * 2 + 1), (float)((int)y1 * 2 - 1), color2);
      drawRect((float)((int)x * 2), (float)((int)y1 * 2 - 1), (float)((int)x1 * 2), (float)((int)y1 * 2), color2);
      GL11.glDisable(3042);
      GL11.glScalef(2.0F, 2.0F, 2.0F);
   }

   public static void DrawNodusRect(float par0, float par1, float par2, float par3, int par4) {
      float var5;
      if (par0 < par2) {
         var5 = par0;
         par0 = par2;
         par2 = var5;
      }

      if (par1 < par3) {
         var5 = par1;
         par1 = par3;
         par3 = var5;
      }

      float var10 = (float)(par4 >> 24 & 255) / 255.0F;
      float var6 = (float)(par4 >> 16 & 255) / 255.0F;
      float var7 = (float)(par4 >> 8 & 255) / 255.0F;
      float var8 = (float)(par4 & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glDisable(2896);
      OpenGlHelper.func_148821_a(770, 771, 1, 0);
      GL11.glColor4f(var6, var7, var8, var10);
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_181662_b((double)par0, (double)par3, 0.0D).func_181666_a(var6, var7, var8, var10).func_181675_d();
      bufferbuilder.func_181662_b((double)par2, (double)par3, 0.0D).func_181666_a(var6, var7, var8, var10).func_181675_d();
      bufferbuilder.func_181662_b((double)par2, (double)par1, 0.0D).func_181666_a(var6, var7, var8, var10).func_181675_d();
      bufferbuilder.func_181662_b((double)par0, (double)par1, 0.0D).func_181666_a(var6, var7, var8, var10).func_181675_d();
      tessellator.func_78381_a();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

   public static void drawSplitString(String p_Name, int p_X, int p_Y, int p_K, int p_Color) {
      Minecraft.func_71410_x().field_71466_p.func_78279_b(p_Name, p_X, p_Y, p_K, p_Color);
   }

   public static void drawBorderedRect(int x, int y, int x1, int y1, int color, float lineWidth, int color1) {
      drawRect((float)x, (float)y, (float)x1, (float)y1, color);
      setupOverlayRendering();
      disableDefaults();
      GL11.glColor4d(getRedFromHex(color1), getGreenFromHex(color1), getBlueFromHex(color1), getAlphaFromHex(color1));
      GL11.glLineWidth(lineWidth);
      GL11.glBegin(1);
      GL11.glVertex2d((double)x, (double)y);
      GL11.glVertex2d((double)x, (double)y1);
      GL11.glVertex2d((double)x1, (double)y1);
      GL11.glVertex2d((double)x1, (double)y);
      GL11.glVertex2d((double)x, (double)y);
      GL11.glVertex2d((double)x1, (double)y);
      GL11.glVertex2d((double)x, (double)y1);
      GL11.glVertex2d((double)x1, (double)y1);
      GL11.glEnd();
      enableDefaults();
   }

   public static void drawRect(int x, int y, int x1, int y1, int color, int p_CustomAlpha) {
      setupOverlayRendering();
      disableDefaults();
      GL11.glColor4d(getRedFromHex(color), getGreenFromHex(color), getBlueFromHex(color), p_CustomAlpha > 0 ? (double)p_CustomAlpha : getAlphaFromHex(color));
      GL11.glBegin(7);
      GL11.glVertex2i(x1, y);
      GL11.glVertex2i(x, y);
      GL11.glVertex2i(x, y1);
      GL11.glVertex2i(x1, y1);
      GL11.glEnd();
      enableDefaults();
   }

   public static void drawRoundedRect(int x, int y, int x1, int y1, int radius, int color, int p_CustomAlpha) {
      disableDefaults();
      float newX = (float)Math.abs(x + radius);
      float newY = (float)Math.abs(y + radius);
      float newX1 = (float)Math.abs(x1 - radius);
      float newY1 = (float)Math.abs(y1 - radius);
      drawRect(newX, newY, newX1, newY1, color);
      drawRect((float)x, newY, newX, newY1, color);
      drawRect(newX1, newY, (float)x1, newY1, color);
      drawRect(newX, (float)y, newX1, newY, color);
      drawRect(newX, newY1, newX1, (float)y1, color);
      drawQuarterCircle((int)newX, (int)newY, radius, 0, color, p_CustomAlpha);
      drawQuarterCircle((int)newX1, (int)newY, radius, 1, color, p_CustomAlpha);
      drawQuarterCircle((int)newX, (int)newY1, radius, 2, color, p_CustomAlpha);
      drawQuarterCircle((int)newX1, (int)newY1, radius, 3, color, p_CustomAlpha);
      enableDefaults();
   }

   public static void drawLine2D(int x, int y, int x1, int y1, int color, float lineWidth) {
      setupOverlayRendering();
      disableDefaults();
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glColor4d(getRedFromHex(color), getGreenFromHex(color), getBlueFromHex(color), getAlphaFromHex(color));
      GL11.glBegin(1);
      GL11.glVertex2i(x, y);
      GL11.glVertex2i(x1, y1);
      GL11.glEnd();
      GL11.glDisable(2848);
      enableDefaults();
   }

   public static void drawBorderedCircle(int x, int y, int radius, int color, float lineWidth, int color1) {
      drawCircle(x, y, radius, color);
      drawUnfilledCircle(x, y, radius, lineWidth, color1);
   }

   public static void drawUnfilledCircle(int x, int y, int radius, float lineWidth, int color) {
      setupOverlayRendering();
      disableDefaults();
      GL11.glColor4d(getRedFromHex(color), getGreenFromHex(color), getBlueFromHex(color), getAlphaFromHex(color));
      GL11.glLineWidth(lineWidth);
      GL11.glEnable(2848);
      GL11.glBegin(2);

      for(int i = 0; i <= 360; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.141526D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.141526D / 180.0D) * (double)radius);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      enableDefaults();
   }

   public static void drawCircle(int x, int y, int radius, int color) {
      setupOverlayRendering();
      disableDefaults();
      GL11.glColor4d(getRedFromHex(color), getGreenFromHex(color), getBlueFromHex(color), getAlphaFromHex(color));
      GL11.glBegin(9);

      for(int i = 0; i <= 360; ++i) {
         GL11.glVertex2d((double)x + Math.sin((double)i * 3.141526D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.141526D / 180.0D) * (double)radius);
      }

      GL11.glEnd();
      enableDefaults();
   }

   public static void drawQuarterCircle(int x, int y, int radius, int mode, int color, int p_CustomAlpha) {
      disableDefaults();
      GL11.glColor4d(getRedFromHex(color), getGreenFromHex(color), getBlueFromHex(color), p_CustomAlpha > 0 ? (double)p_CustomAlpha : getAlphaFromHex(color));
      GL11.glBegin(9);
      GL11.glVertex2d((double)x, (double)y);
      int i;
      if (mode == 0) {
         for(i = 0; i <= 90; ++i) {
            GL11.glVertex2d((double)x + Math.sin((double)i * 3.141526D / 180.0D) * (double)(radius * -1), (double)y + Math.cos((double)i * 3.141526D / 180.0D) * (double)(radius * -1));
         }
      } else if (mode == 1) {
         for(i = 90; i <= 180; ++i) {
            GL11.glVertex2d((double)x + Math.sin((double)i * 3.141526D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.141526D / 180.0D) * (double)radius);
         }
      } else if (mode == 2) {
         for(i = 90; i <= 180; ++i) {
            GL11.glVertex2d((double)x + Math.sin((double)i * 3.141526D / 180.0D) * (double)(radius * -1), (double)y + Math.cos((double)i * 3.141526D / 180.0D) * (double)(radius * -1));
         }
      } else if (mode == 3) {
         for(i = 0; i <= 90; ++i) {
            GL11.glVertex2d((double)x + Math.sin((double)i * 3.141526D / 180.0D) * (double)radius, (double)y + Math.cos((double)i * 3.141526D / 180.0D) * (double)radius);
         }
      }

      GL11.glEnd();
      enableDefaults();
   }

   public static double getAlphaFromHex(int color) {
      return (double)((float)(color >> 24 & 255) / 255.0F);
   }

   public static double getRedFromHex(int color) {
      return (double)((float)(color >> 16 & 255) / 255.0F);
   }

   public static double getGreenFromHex(int color) {
      return (double)((float)(color >> 8 & 255) / 255.0F);
   }

   public static double getBlueFromHex(int color) {
      return (double)((float)(color & 255) / 255.0F);
   }

   public static int getScreenWidth() {
      IntBuffer viewport = BufferUtils.createIntBuffer(16);
      GL11.glGetInteger(2978, viewport);
      return Math.round((float)viewport.get(2));
   }

   public static int getScreenHeight() {
      IntBuffer viewport = BufferUtils.createIntBuffer(16);
      GL11.glGetInteger(2978, viewport);
      return Math.round((float)viewport.get(3));
   }

   public static void setupGradient() {
      GL11.glDisable(3553);
      GL11.glEnable(3042);
      GL11.glDisable(3008);
      GL11.glShadeModel(7425);
   }

   public static void unsetupGradient() {
      GL11.glShadeModel(7424);
      GL11.glDisable(3042);
      GL11.glEnable(3008);
      GL11.glEnable(3553);
   }

   public static void setupOverlayRendering() {
      GL11.glClear(256);
      GL11.glMatrixMode(5889);
      GL11.glLoadIdentity();
      GL11.glOrtho(0.0D, (double)getScreenWidth(), (double)getScreenHeight(), 0.0D, 1000.0D, 3000.0D);
      GL11.glMatrixMode(5888);
      GL11.glLoadIdentity();
      GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
   }

   public static void disableDefaults() {
      GL11.glEnable(3042);
      GL11.glDisable(2896);
      GL11.glDisable(3553);
   }

   public static void enableDefaults() {
      GL11.glDisable(3042);
      GL11.glEnable(3553);
      GL11.glEnable(2896);
   }

   public static void disableLighting() {
      GL11.glDisable(2896);
   }

   public static String trimStringToWidth(String substring, int width) {
      return Minecraft.func_71410_x().field_71466_p.func_78269_a(substring, width);
   }

   public static String trimStringToWidth(String text, int j, boolean b) {
      return Minecraft.func_71410_x().field_71466_p.func_78262_a(text, j, b);
   }

   public static void drawColorBox(AxisAlignedBB axisalignedbb, float red, float green, float blue, float alpha) {
      Tessellator ts = Tessellator.func_178181_a();
      BufferBuilder vb = ts.func_178180_c();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
      ts.func_78381_a();
   }

   public static void drawColorBox(AxisAlignedBB axisalignedbb, Color c) {
      Tessellator ts = Tessellator.func_178181_a();
      BufferBuilder vb = ts.func_178180_c();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      ts.func_78381_a();
      vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).func_181675_d();
      ts.func_78381_a();
   }

   public static void drawBox(AxisAlignedBB boundingBox) {
      assert boundingBox != null;

      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72337_e, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
      GlStateManager.func_187447_r(7);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72339_c);
      GlStateManager.func_187435_e((float)boundingBox.field_72340_a, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187435_e((float)boundingBox.field_72336_d, (float)boundingBox.field_72338_b, (float)boundingBox.field_72334_f);
      GlStateManager.func_187437_J();
   }

   public static void drawOutlinedBox(AxisAlignedBB bb) {
      GL11.glBegin(1);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f);
      GL11.glVertex3d(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c);
      GL11.glEnd();
   }

   public static void drawESPOutline(AxisAlignedBB bb, float red, float green, float blue, float alpha, float width) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glLineWidth(width);
      GL11.glColor4f(red / 255.0F, green / 255.0F, blue / 255.0F, alpha / 255.0F);
      drawOutlinedBox(bb);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static void drawESP(AxisAlignedBB bb, float red, float green, float blue, float alpha) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4f(red / 255.0F, green / 255.0F, blue / 255.0F, alpha / 255.0F);
      drawBox(bb);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
   }
}
