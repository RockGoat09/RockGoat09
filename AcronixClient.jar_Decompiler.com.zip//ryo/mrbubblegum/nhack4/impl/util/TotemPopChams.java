package ryo.mrbubblegum.nhack4.impl.util;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import ryo.mrbubblegum.nhack4.lite.render.PopChams;

public class TotemPopChams {
   private static final Minecraft mc = Minecraft.func_71410_x();
   EntityOtherPlayerMP player;
   ModelPlayer playerModel;
   Long startTime;
   double alphaFill;
   double alphaLine;

   public TotemPopChams(EntityOtherPlayerMP player, ModelPlayer playerModel, Long startTime, double alphaFill, double alphaLine) {
      MinecraftForge.EVENT_BUS.register(this);
      this.player = player;
      this.playerModel = playerModel;
      this.startTime = startTime;
      this.alphaFill = alphaFill;
      this.alphaLine = alphaFill;
   }

   public static void renderEntity(EntityLivingBase entity, ModelBase modelBase, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
      if (mc.func_175598_ae() != null) {
         float partialTicks = mc.func_184121_ak();
         double x = entity.field_70165_t - mc.func_175598_ae().field_78730_l;
         double y = entity.field_70163_u - mc.func_175598_ae().field_78731_m;
         double z = entity.field_70161_v - mc.func_175598_ae().field_78728_n;
         GlStateManager.func_179094_E();
         if (entity.func_70093_af()) {
            y -= 0.125D;
         }

         float interpolateRotation = interpolateRotation(entity.field_70760_ar, entity.field_70761_aq, partialTicks);
         float interpolateRotation2 = interpolateRotation(entity.field_70758_at, entity.field_70759_as, partialTicks);
         float var10000 = interpolateRotation2 - interpolateRotation;
         var10000 = entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks;
         renderLivingAt(x, y, z);
         float f8 = handleRotationFloat(entity, partialTicks);
         prepareRotations(entity);
         float f9 = prepareScale(entity, scale);
         GlStateManager.func_179141_d();
         modelBase.func_78086_a(entity, limbSwing, limbSwingAmount, partialTicks);
         modelBase.func_78087_a(limbSwing, limbSwingAmount, f8, entity.field_70759_as, entity.field_70125_A, f9, entity);
         modelBase.func_78088_a(entity, limbSwing, limbSwingAmount, f8, entity.field_70759_as, entity.field_70125_A, f9);
         GlStateManager.func_179121_F();
      }
   }

   public static void prepareTranslate(EntityLivingBase entityIn, double x, double y, double z) {
      renderLivingAt(x - mc.func_175598_ae().field_78730_l, y - mc.func_175598_ae().field_78731_m, z - mc.func_175598_ae().field_78728_n);
   }

   public static void renderLivingAt(double x, double y, double z) {
      GlStateManager.func_179109_b((float)x, (float)y, (float)z);
   }

   public static float prepareScale(EntityLivingBase entity, float scale) {
      GlStateManager.func_179091_B();
      GlStateManager.func_179152_a(-1.0F, -1.0F, 1.0F);
      double widthX = entity.func_184177_bl().field_72336_d - entity.func_184177_bl().field_72340_a;
      double widthZ = entity.func_184177_bl().field_72334_f - entity.func_184177_bl().field_72339_c;
      GlStateManager.func_179139_a((double)scale + widthX, (double)(scale * entity.field_70131_O), (double)scale + widthZ);
      float f = 0.0625F;
      GlStateManager.func_179109_b(0.0F, -1.501F, 0.0F);
      return 0.0625F;
   }

   public static void prepareRotations(EntityLivingBase entityLivingBase) {
      GlStateManager.func_179114_b(180.0F - entityLivingBase.field_70177_z, 0.0F, 1.0F, 0.0F);
   }

   public static float interpolateRotation(float prevYawOffset, float yawOffset, float partialTicks) {
      float f;
      for(f = yawOffset - prevYawOffset; f < -180.0F; f += 360.0F) {
      }

      while(f >= 180.0F) {
         f -= 360.0F;
      }

      return prevYawOffset + partialTicks * f;
   }

   public static Color newAlpha(Color color, int alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   public static void glColor(Color color) {
      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
   }

   public static float handleRotationFloat(EntityLivingBase livingBase, float partialTicks) {
      return 0.0F;
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent event) {
      if (this.player != null && mc.field_71441_e != null && mc.field_71439_g != null) {
         GL11.glLineWidth(1.0F);
         Color lineColorS = new Color((Integer)PopChams.rL.getValue(), (Integer)PopChams.gL.getValue(), (Integer)PopChams.bL.getValue(), (Integer)PopChams.aL.getValue());
         Color fillColorS = new Color((Integer)PopChams.rF.getValue(), (Integer)PopChams.gF.getValue(), (Integer)PopChams.bF.getValue(), (Integer)PopChams.aF.getValue());
         int lineA = lineColorS.getAlpha();
         int fillA = fillColorS.getAlpha();
         long time = System.currentTimeMillis() - this.startTime - ((Number)PopChams.fadestart.getValue()).longValue();
         if (System.currentTimeMillis() - this.startTime > ((Number)PopChams.fadestart.getValue()).longValue()) {
            double normal = this.normalize((double)time, 0.0D, ((Number)PopChams.fadetime.getValue()).doubleValue());
            normal = MathHelper.func_151237_a(normal, 0.0D, 1.0D);
            normal = -normal + 1.0D;
            lineA *= (int)normal;
            fillA *= (int)normal;
         }

         Color lineColor = newAlpha(lineColorS, lineA);
         Color fillColor = newAlpha(fillColorS, fillA);
         if (this.player != null && this.playerModel != null) {
            NordTessellator.prepareGL();
            GL11.glPushAttrib(1048575);
            GL11.glEnable(2881);
            GL11.glEnable(2848);
            if (this.alphaFill > 1.0D) {
               this.alphaFill -= (double)(Float)PopChams.fadetime.getValue();
            }

            Color fillFinal = new Color(fillColor.getRed(), fillColor.getGreen(), fillColor.getBlue(), (int)this.alphaFill);
            if (this.alphaLine > 1.0D) {
               this.alphaLine -= (double)(Float)PopChams.fadetime.getValue();
            }

            Color outlineFinal = new Color(lineColor.getRed(), lineColor.getGreen(), lineColor.getBlue(), (int)this.alphaLine);
            glColor(fillFinal);
            GL11.glPolygonMode(1032, 6914);
            renderEntity(this.player, this.playerModel, this.player.field_184619_aG, this.player.field_70721_aZ, (float)this.player.field_70173_aa, this.player.field_70759_as, this.player.field_70125_A, 1.0F);
            glColor(outlineFinal);
            GL11.glPolygonMode(1032, 6913);
            renderEntity(this.player, this.playerModel, this.player.field_184619_aG, this.player.field_70721_aZ, (float)this.player.field_70173_aa, this.player.field_70759_as, this.player.field_70125_A, 1.0F);
            GL11.glPolygonMode(1032, 6914);
            GL11.glPopAttrib();
            NordTessellator.releaseGL();
         }

      }
   }

   double normalize(double value, double min, double max) {
      return (value - min) / (max - min);
   }
}
