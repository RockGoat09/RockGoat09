package ryo.mrbubblegum.nhack4.impl.util;

import net.minecraft.client.Minecraft;

public interface Util {
   Minecraft mc = Minecraft.func_71410_x();
}
