package ryo.mrbubblegum.nhack4.impl.util.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class HoleUtilSafety implements ryo.mrbubblegum.nhack4.impl.util.Util {
   private static final Block[] NO_BLAST;
   private static final Vec3i[] OFFSETS_2x2 = new Vec3i[]{new Vec3i(0, 0, 0), new Vec3i(1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(1, 0, 1)};
   public static BlockPos[] holeOffsets = new BlockPos[]{new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(0, -1, 0)};

   public static boolean is2x2(BlockPos blockPos) {
      return is2x2(blockPos, true);
   }

   public static boolean isAir(BlockPos blockPos) {
      return mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150350_a;
   }

   public static boolean isObbyHole(BlockPos blockPos) {
      boolean bl = true;
      int n = 0;
      BlockPos[] var3 = holeOffsets;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         BlockPos blockPos2 = var3[var5];
         Block block = mc.field_71441_e.func_180495_p(blockPos.func_177971_a(blockPos2)).func_177230_c();
         if (!isSafeBlock(blockPos.func_177971_a(blockPos2))) {
            bl = false;
         } else if (block == Blocks.field_150343_Z || block == Blocks.field_150477_bB || block == Blocks.field_150467_bQ) {
            ++n;
         }
      }

      if (mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 2, 0)).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 1, 0)).func_177230_c() != Blocks.field_150350_a) {
         bl = false;
      }

      if (n < 1) {
         bl = false;
      }

      return bl;
   }

   public static HoleUtilSafety.Hole isDoubleHole(BlockPos blockPos) {
      if (checkOffset(blockPos, 1, 0)) {
         return new HoleUtilSafety.Hole(false, true, blockPos, blockPos.func_177982_a(1, 0, 0));
      } else {
         return checkOffset(blockPos, 0, 1) ? new HoleUtilSafety.Hole(false, true, blockPos, blockPos.func_177982_a(0, 0, 1)) : null;
      }
   }

   public static boolean isHole(BlockPos blockPos) {
      boolean bl = false;
      int n = 0;
      BlockPos[] var3 = holeOffsets;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         BlockPos blockPos2 = var3[var5];
         if (!mc.field_71441_e.func_180495_p(blockPos.func_177971_a(blockPos2)).func_185904_a().func_76222_j()) {
            ++n;
         }
      }

      if (n == 5) {
         bl = true;
      }

      return bl;
   }

   public static List<HoleUtilSafety.Hole> getHoles(double d, BlockPos blockPos, boolean bl) {
      ArrayList<HoleUtilSafety.Hole> arrayList = new ArrayList();
      List<BlockPos> list = getSphere(d, blockPos, true, false);
      Iterator var6 = list.iterator();

      while(true) {
         while(true) {
            BlockPos blockPos2;
            do {
               if (!var6.hasNext()) {
                  return arrayList;
               }

               blockPos2 = (BlockPos)var6.next();
            } while(mc.field_71441_e.func_180495_p(blockPos2).func_177230_c() != Blocks.field_150350_a);

            if (isObbyHole(blockPos2)) {
               arrayList.add(new HoleUtilSafety.Hole(false, false, blockPos2));
            } else if (isBedrockHoles(blockPos2)) {
               arrayList.add(new HoleUtilSafety.Hole(true, false, blockPos2));
            } else {
               HoleUtilSafety.Hole hole;
               if (bl && (hole = isDoubleHole(blockPos2)) != null && (mc.field_71441_e.func_180495_p(hole.pos1.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150350_a || mc.field_71441_e.func_180495_p(hole.pos2.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150350_a)) {
                  arrayList.add(hole);
               }
            }
         }
      }
   }

   public static boolean is2x2(BlockPos blockPos, boolean bl) {
      if (bl && !isAir(blockPos)) {
         return false;
      } else if (is2x2Partial(blockPos)) {
         return true;
      } else {
         BlockPos blockPos2 = blockPos.func_177982_a(-1, 0, 0);
         boolean bl2 = isAir(blockPos2);
         if (bl2 && is2x2Partial(blockPos2)) {
            return true;
         } else {
            BlockPos blockPos3 = blockPos.func_177982_a(0, 0, -1);
            boolean bl3 = isAir(blockPos3);
            if (bl3 && is2x2Partial(blockPos3)) {
               return true;
            } else {
               return (bl2 || bl3) && is2x2Partial(blockPos.func_177982_a(-1, 0, -1));
            }
         }
      }
   }

   public static boolean is2x1(BlockPos blockPos, boolean bl) {
      if (bl) {
         if (!isAir(blockPos)) {
            return false;
         }

         if (!isAir(blockPos.func_177984_a())) {
            return false;
         }

         if (isAir(blockPos.func_177977_b())) {
            return false;
         }
      }

      int n = 0;
      EnumFacing[] var3 = EnumFacing.field_176754_o;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         EnumFacing enumFacing = var3[var5];
         BlockPos blockPos2 = blockPos.func_177972_a(enumFacing);
         if (isAir(blockPos2)) {
            if (!isAir(blockPos2.func_177984_a())) {
               return false;
            }

            if (isAir(blockPos2.func_177977_b())) {
               return false;
            }

            EnumFacing[] var8 = EnumFacing.field_176754_o;
            int var9 = var8.length;

            for(int var10 = 0; var10 < var9; ++var10) {
               EnumFacing enumFacing2 = var8[var10];
               if (enumFacing2 != enumFacing.func_176734_d()) {
                  IBlockState iBlockState = mc.field_71441_e.func_180495_p(blockPos2.func_177972_a(enumFacing2));
                  if (Arrays.stream(NO_BLAST).noneMatch((block) -> {
                     return block == iBlockState.func_177230_c();
                  })) {
                     return false;
                  }
               }
            }

            ++n;
         }

         if (n > 0) {
            return false;
         }
      }

      return n == 0;
   }

   public static boolean is2x1(BlockPos blockPos) {
      return is2x1(blockPos, true);
   }

   public static boolean[] is1x1(BlockPos blockPos) {
      return is1x1(blockPos, new boolean[]{false, true});
   }

   public static boolean is2x2Partial(BlockPos blockPos) {
      HashSet<BlockPos> hashSet = new HashSet();
      Vec3i[] var2 = OFFSETS_2x2;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Vec3i arrenumFacing = var2[var4];
         hashSet.add(blockPos.func_177971_a(arrenumFacing));
      }

      boolean bl = false;
      Iterator var12 = hashSet.iterator();

      while(var12.hasNext()) {
         BlockPos blockPos2 = (BlockPos)var12.next();
         if (!isAir(blockPos2) || !isAir(blockPos2.func_177984_a()) || isAir(blockPos2.func_177977_b())) {
            return false;
         }

         if (isAir(blockPos2.func_177981_b(2))) {
            bl = true;
         }

         EnumFacing[] var14 = EnumFacing.field_176754_o;
         int var6 = var14.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            EnumFacing enumFacing = var14[var7];
            BlockPos blockPos3 = blockPos2.func_177972_a(enumFacing);
            if (!hashSet.contains(blockPos3)) {
               IBlockState iBlockState = mc.field_71441_e.func_180495_p(blockPos3);
               if (Arrays.stream(NO_BLAST).noneMatch((block) -> {
                  return block == iBlockState.func_177230_c();
               })) {
                  return false;
               }
            }
         }
      }

      return bl;
   }

   static boolean isSafeBlock(BlockPos blockPos) {
      return mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150357_h || mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150477_bB;
   }

   public static List<BlockPos> getSphere(double d, BlockPos blockPos, boolean bl, boolean bl2) {
      ArrayList<BlockPos> arrayList = new ArrayList();
      int n = blockPos.func_177958_n();
      int n2 = blockPos.func_177956_o();
      int n3 = blockPos.func_177952_p();

      for(int n4 = n - (int)d; (double)n4 <= (double)n + d; ++n4) {
         for(int n5 = n3 - (int)d; (double)n5 <= (double)n3 + d; ++n5) {
            int n6 = bl ? n2 - (int)d : n2;

            while(true) {
               double d2 = (double)n6;
               double d3 = (double)n2 + d;
               if (!(d2 < d3)) {
                  break;
               }

               double d5 = (double)((n - n4) * (n - n4) + (n3 - n5) * (n3 - n5) + (bl ? (n2 - n6) * (n2 - n6) : 0));
               if (d5 < d * d && (!bl2 || !(d5 < (d - 1.0D) * (d - 1.0D)))) {
                  BlockPos blockPos2 = new BlockPos(n4, n6, n5);
                  arrayList.add(blockPos2);
               }

               ++n6;
            }
         }
      }

      return arrayList;
   }

   public static boolean checkOffset(BlockPos blockPos, int n, int n2) {
      return mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(blockPos.func_177982_a(n, 0, n2)).func_177230_c() == Blocks.field_150350_a && isSafeBlock(blockPos.func_177982_a(0, -1, 0)) && isSafeBlock(blockPos.func_177982_a(n, -1, n2)) && isSafeBlock(blockPos.func_177982_a(n * 2, 0, n2 * 2)) && isSafeBlock(blockPos.func_177982_a(-n, 0, -n2)) && isSafeBlock(blockPos.func_177982_a(n2, 0, n)) && isSafeBlock(blockPos.func_177982_a(-n2, 0, -n)) && isSafeBlock(blockPos.func_177982_a(n, 0, n2).func_177982_a(n2, 0, n)) && isSafeBlock(blockPos.func_177982_a(n, 0, n2).func_177982_a(-n2, 0, -n));
   }

   public static boolean[] isHole(BlockPos blockPos, boolean bl) {
      boolean[] arrbl = new boolean[]{false, true};
      return isAir(blockPos) && isAir(blockPos.func_177984_a()) && (!bl || isAir(blockPos.func_177981_b(2))) ? is1x1(blockPos, arrbl) : arrbl;
   }

   public static boolean[] is1x1(BlockPos blockPos, boolean[] arrbl) {
      EnumFacing[] var2 = EnumFacing.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         EnumFacing enumFacing = var2[var4];
         IBlockState iBlockState;
         if (enumFacing != EnumFacing.UP && (iBlockState = mc.field_71441_e.func_180495_p(blockPos.func_177972_a(enumFacing))).func_177230_c() != Blocks.field_150357_h) {
            if (Arrays.stream(NO_BLAST).noneMatch((block) -> {
               return block == iBlockState.func_177230_c();
            })) {
               return arrbl;
            }

            arrbl[1] = false;
         }
      }

      arrbl[0] = true;
      return arrbl;
   }

   public static boolean isBedrockHoles(BlockPos blockPos) {
      boolean bl = true;
      BlockPos[] var2 = holeOffsets;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         BlockPos blockPos2 = var2[var4];
         Block block = mc.field_71441_e.func_180495_p(blockPos.func_177971_a(blockPos2)).func_177230_c();
         if (block != Blocks.field_150357_h) {
            bl = false;
         }
      }

      if (mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 2, 0)).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(blockPos.func_177982_a(0, 1, 0)).func_177230_c() != Blocks.field_150350_a) {
         bl = false;
      }

      return bl;
   }

   static {
      NO_BLAST = new Block[]{Blocks.field_150357_h, Blocks.field_150343_Z, Blocks.field_150467_bQ, Blocks.field_150477_bB};
   }

   public static class Hole {
      public BlockPos pos1;
      public BlockPos pos2;
      public boolean doubleHole;
      public boolean bedrock;

      public Hole(boolean bl, boolean bl2, BlockPos blockPos, BlockPos blockPos2) {
         this.bedrock = bl;
         this.doubleHole = bl2;
         this.pos1 = blockPos;
         this.pos2 = blockPos2;
      }

      public Hole(boolean bl, boolean bl2, BlockPos blockPos) {
         this.bedrock = bl;
         this.doubleHole = bl2;
         this.pos1 = blockPos;
      }
   }
}
