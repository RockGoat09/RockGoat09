package ryo.mrbubblegum.nhack4.injections.mixins;

import net.minecraft.world.biome.Biome.BiomeProperties;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({BiomeProperties.class})
public class MixinBiomeProperties {
}
