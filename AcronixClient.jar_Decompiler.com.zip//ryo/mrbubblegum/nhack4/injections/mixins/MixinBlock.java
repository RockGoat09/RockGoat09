package ryo.mrbubblegum.nhack4.injections.mixins;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({Block.class})
public abstract class MixinBlock {
   /** @deprecated */
   @Shadow
   @Deprecated
   public abstract float func_176195_g(IBlockState var1, World var2, BlockPos var3);
}
