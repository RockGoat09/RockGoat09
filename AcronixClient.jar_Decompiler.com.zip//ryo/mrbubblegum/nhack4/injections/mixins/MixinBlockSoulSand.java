package ryo.mrbubblegum.nhack4.injections.mixins;

import net.minecraft.block.Block;
import net.minecraft.block.BlockSoulSand;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({BlockSoulSand.class})
public class MixinBlockSoulSand extends Block {
   public MixinBlockSoulSand() {
      super(Material.field_151595_p, MapColor.field_151650_B);
   }
}
