package ryo.mrbubblegum.nhack4.injections.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.lite.render.NoRender;
import ryo.mrbubblegum.nhack4.lite.render.ViewModel;
import ryo.mrbubblegum.nhack4.world.events.RenderItemEvent;

@Mixin({ItemRenderer.class})
public abstract class MixinItemRenderer {
   private final boolean injection = true;

   @Shadow
   public abstract void func_187457_a(AbstractClientPlayer var1, float var2, float var3, EnumHand var4, float var5, ItemStack var6, float var7);

   @Inject(
      method = {"transformSideFirstPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void transformSideFirstPerson(EnumHandSide hand, float p_187459_2_, CallbackInfo cancel) {
      RenderItemEvent event = new RenderItemEvent(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D, 1.0D, 1.0D, 1.0D);
      MinecraftForge.EVENT_BUS.post(event);
      if (ViewModel.getInstance().isEnabled()) {
         boolean bob = ViewModel.getInstance().isDisabled() || (Boolean)ViewModel.getInstance().doBob.getValue();
         int i = hand == EnumHandSide.RIGHT ? 1 : -1;
         GlStateManager.func_179109_b((float)i * 0.56F, -0.52F + (bob ? p_187459_2_ : 0.0F) * -0.6F, -0.72F);
         if (hand == EnumHandSide.RIGHT) {
            GlStateManager.func_179137_b(event.getMainX(), event.getMainY(), event.getMainZ());
            RenderUtil.rotationHelper((float)event.getMainRotX(), (float)event.getMainRotY(), (float)event.getMainRotZ());
         } else {
            GlStateManager.func_179137_b(event.getOffX(), event.getOffY(), event.getOffZ());
            RenderUtil.rotationHelper((float)event.getOffRotX(), (float)event.getOffRotY(), (float)event.getOffRotZ());
         }

         cancel.cancel();
      }

   }

   @Inject(
      method = {"renderFireInFirstPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderFireInFirstPersonHook(CallbackInfo info) {
      if (NoRender.getInstance().isOn() && (Boolean)NoRender.getInstance().fire.getValue()) {
         info.cancel();
      }

   }

   @Inject(
      method = {"transformEatFirstPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void transformEatFirstPerson(float p_187454_1_, EnumHandSide hand, ItemStack stack, CallbackInfo cancel) {
      if (ViewModel.getInstance().isEnabled()) {
         if (!(Boolean)ViewModel.getInstance().noEatAnimation.getValue()) {
            float f = (float)Minecraft.func_71410_x().field_71439_g.func_184605_cv() - p_187454_1_ + 1.0F;
            float f1 = f / (float)stack.func_77988_m();
            float f3;
            if (f1 < 0.8F) {
               f3 = MathHelper.func_76135_e(MathHelper.func_76134_b(f / 4.0F * 3.1415927F) * 0.1F);
               GlStateManager.func_179109_b(0.0F, f3, 0.0F);
            }

            f3 = 1.0F - (float)Math.pow((double)f1, 27.0D);
            int i = hand == EnumHandSide.RIGHT ? 1 : -1;
            GlStateManager.func_179137_b((double)(f3 * 0.6F * (float)i) * (Double)ViewModel.getInstance().eatX.getValue(), (double)(f3 * 0.5F) * -(Double)ViewModel.getInstance().eatY.getValue(), 0.0D);
            GlStateManager.func_179114_b((float)i * f3 * 90.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.func_179114_b(f3 * 10.0F, 1.0F, 0.0F, 0.0F);
            GlStateManager.func_179114_b((float)i * f3 * 30.0F, 0.0F, 0.0F, 1.0F);
         }

         cancel.cancel();
      }

   }

   @Inject(
      method = {"renderSuffocationOverlay"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderSuffocationOverlay(CallbackInfo ci) {
      if (NoRender.getInstance().isOn() && (Boolean)NoRender.getInstance().blocks.getValue()) {
         ci.cancel();
      }

   }
}
