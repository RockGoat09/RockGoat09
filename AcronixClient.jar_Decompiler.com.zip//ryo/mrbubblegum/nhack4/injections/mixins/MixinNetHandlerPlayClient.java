package ryo.mrbubblegum.nhack4.injections.mixins;

import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityMetadata;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.world.events.DeathEvent;

@Mixin({NetHandlerPlayClient.class})
public class MixinNetHandlerPlayClient {
   @Inject(
      method = {"handleEntityMetadata"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void handleEntityMetadataHook(SPacketEntityMetadata packetIn, CallbackInfo info) {
      EntityPlayer player;
      Entity entity;
      if (Util.mc.field_71441_e != null && (entity = Util.mc.field_71441_e.func_73045_a(packetIn.func_149375_d())) instanceof EntityPlayer && (player = (EntityPlayer)entity).func_110143_aJ() <= 0.0F) {
         MinecraftForge.EVENT_BUS.post(new DeathEvent(player));
         if (Loader.totemPopManager != null) {
            Loader.totemPopManager.onDeath(player);
         }
      }

   }
}
