package ryo.mrbubblegum.nhack4.injections.mixins;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.lite.client.Colors;
import ryo.mrbubblegum.nhack4.lite.render.CrystalModify;
import ryo.mrbubblegum.nhack4.loader.Loader;

@Mixin({RenderEnderCrystal.class})
public abstract class MixinRenderEnderCrystal {
   private static final ResourceLocation RES_ITEM_GLINT = new ResourceLocation("textures/misc/enchanted_item_glint.png");
   @Final
   @Shadow
   private static ResourceLocation field_110787_a;
   @Shadow
   public ModelBase field_76995_b;
   @Shadow
   public ModelBase field_188316_g;

   @Shadow
   public abstract void func_76986_a(EntityEnderCrystal var1, double var2, double var4, double var6, float var8, float var9);

   @Redirect(
      method = {"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"
)
   )
   private void render1(ModelBase var1, Entity var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (!Loader.moduleManager.isModuleEnabled(CrystalModify.class)) {
         var1.func_78088_a(var2, var3, var4, var5, var6, var7, var8);
      }

   }

   @Redirect(
      method = {"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V",
   ordinal = 1
)
   )
   private void render2(ModelBase var1, Entity var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (!Loader.moduleManager.isModuleEnabled(CrystalModify.class)) {
         var1.func_78088_a(var2, var3, var4, var5, var6, var7, var8);
      }

   }

   @Inject(
      method = {"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"},
      at = {@At("RETURN")},
      cancellable = true
   )
   public void IdoRender(EntityEnderCrystal var1, double var2, double var4, double var6, float var8, float var9, CallbackInfo var10) {
      Minecraft mc = Minecraft.func_71410_x();
      mc.field_71474_y.field_74347_j = false;
      if (Loader.moduleManager.isModuleEnabled(CrystalModify.class)) {
         GL11.glPushMatrix();
         float var14 = (float)var1.field_70261_a + var9;
         GlStateManager.func_179137_b(var2, var4, var6);
         GlStateManager.func_179152_a((Float)CrystalModify.INSTANCE.size.getValue(), (Float)CrystalModify.INSTANCE.size.getValue(), (Float)CrystalModify.INSTANCE.size.getValue());
         Minecraft.func_71410_x().func_175598_ae().field_78724_e.func_110577_a(field_110787_a);
         float var15 = MathHelper.func_76126_a(var14 * 0.2F) / 2.0F + 0.5F;
         var15 += var15 * var15;
         float spinSpeed = (Float)CrystalModify.INSTANCE.crystalSpeed.getValue();
         float bounceSpeed = (Float)CrystalModify.INSTANCE.crystalBounce.getValue();
         if ((Boolean)CrystalModify.INSTANCE.texture.getValue()) {
            if (var1.func_184520_k()) {
               this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
            } else {
               this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
            }
         }

         GL11.glPushAttrib(1048575);
         if (((CrystalModify.modes)CrystalModify.INSTANCE.mode.getValue()).equals(CrystalModify.modes.WIREFRAME)) {
            GL11.glPolygonMode(1032, 6913);
         }

         if (((CrystalModify.BlendModes)CrystalModify.INSTANCE.blendModes.getValue()).equals(CrystalModify.BlendModes.Default)) {
            GL11.glBlendFunc(770, 771);
         }

         if (((CrystalModify.BlendModes)CrystalModify.INSTANCE.blendModes.getValue()).equals(CrystalModify.BlendModes.Brighter)) {
            GL11.glBlendFunc(770, 32772);
         }

         GL11.glDisable(3008);
         GL11.glDisable(3553);
         GL11.glDisable(2896);
         GL11.glEnable(3042);
         GL11.glLineWidth(1.5F);
         GL11.glEnable(2960);
         GL11.glDisable(2929);
         GL11.glDepthMask(false);
         GL11.glEnable(10754);
         Color visibleColor = (Boolean)CrystalModify.INSTANCE.colorSync.getValue() ? Colors.INSTANCE.getCurrentColor() : new Color((Integer)CrystalModify.INSTANCE.red.getValue(), (Integer)CrystalModify.INSTANCE.green.getValue(), (Integer)CrystalModify.INSTANCE.blue.getValue());
         Color hiddenColor = (Boolean)CrystalModify.INSTANCE.colorSync.getValue() ? Colors.INSTANCE.getCurrentColor() : new Color((Integer)CrystalModify.INSTANCE.hiddenRed.getValue(), (Integer)CrystalModify.INSTANCE.hiddenGreen.getValue(), (Integer)CrystalModify.INSTANCE.hiddenBlue.getValue());
         Color outlineColor = (Boolean)CrystalModify.INSTANCE.colorSync.getValue() ? Colors.INSTANCE.getCurrentColor() : new Color((Integer)CrystalModify.INSTANCE.outlineRed.getValue(), (Integer)CrystalModify.INSTANCE.outlineGreen.getValue(), (Integer)CrystalModify.INSTANCE.outlineBlue.getValue());
         if ((Boolean)CrystalModify.INSTANCE.hiddenSync.getValue()) {
            GL11.glColor4f((float)visibleColor.getRed() / 255.0F, (float)visibleColor.getGreen() / 255.0F, (float)visibleColor.getBlue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.alpha.getValue() / 255.0F);
         } else {
            GL11.glColor4f((float)hiddenColor.getRed() / 255.0F, (float)hiddenColor.getGreen() / 255.0F, (float)hiddenColor.getBlue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.hiddenAlpha.getValue() / 255.0F);
         }

         if (var1.func_184520_k()) {
            this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
         } else {
            this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
         }

         GL11.glEnable(2929);
         GL11.glDepthMask(true);
         GL11.glColor4f((float)visibleColor.getRed() / 255.0F, (float)visibleColor.getGreen() / 255.0F, (float)visibleColor.getBlue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.alpha.getValue() / 255.0F);
         if (var1.func_184520_k()) {
            this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
         } else {
            this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
         }

         if ((Boolean)CrystalModify.INSTANCE.enchanted.getValue()) {
            mc.func_110434_K().func_110577_a(RES_ITEM_GLINT);
            GL11.glTexCoord3d(1.0D, 1.0D, 1.0D);
            GL11.glEnable(3553);
            GL11.glBlendFunc(768, 771);
            GL11.glColor4f((float)(Integer)CrystalModify.INSTANCE.enchantRed.getValue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.enchantGreen.getValue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.enchantBlue.getValue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.enchantAlpha.getValue() / 255.0F);
            if (var1.func_184520_k()) {
               this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
            } else {
               this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
            }

            if (((CrystalModify.BlendModes)CrystalModify.INSTANCE.blendModes.getValue()).equals(CrystalModify.BlendModes.Default)) {
               GL11.glBlendFunc(768, 771);
            }

            if (((CrystalModify.BlendModes)CrystalModify.INSTANCE.blendModes.getValue()).equals(CrystalModify.BlendModes.Brighter)) {
               GL11.glBlendFunc(770, 32772);
            } else {
               GL11.glBlendFunc(770, 771);
            }

            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         }

         GL11.glEnable(3042);
         GL11.glEnable(2896);
         GL11.glEnable(3553);
         GL11.glEnable(3008);
         GL11.glPopAttrib();
         if ((Boolean)CrystalModify.INSTANCE.outline.getValue()) {
            if (((CrystalModify.outlineModes)CrystalModify.INSTANCE.outlineMode.getValue()).equals(CrystalModify.outlineModes.WIRE)) {
               GL11.glPushAttrib(1048575);
               GL11.glPolygonMode(1032, 6913);
               GL11.glDisable(3008);
               GL11.glDisable(3553);
               GL11.glDisable(2896);
               GL11.glEnable(3042);
               GL11.glBlendFunc(770, 771);
               GL11.glLineWidth((Float)CrystalModify.INSTANCE.lineWidth.getValue());
               GL11.glEnable(2960);
               GL11.glDisable(2929);
               GL11.glDepthMask(false);
               GL11.glEnable(10754);
               GL11.glColor4f((float)outlineColor.getRed() / 255.0F, (float)outlineColor.getGreen() / 255.0F, (float)outlineColor.getBlue() / 255.0F, (float)(Integer)CrystalModify.INSTANCE.outlineAlpha.getValue() / 255.0F);
               if (var1.func_184520_k()) {
                  this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               } else {
                  this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               }

               GL11.glEnable(2929);
               GL11.glDepthMask(true);
               if (var1.func_184520_k()) {
                  this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               } else {
                  this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               }

               GL11.glEnable(3042);
               GL11.glEnable(2896);
               GL11.glEnable(3553);
               GL11.glEnable(3008);
               GL11.glPopAttrib();
            } else {
               RenderUtil.setColor(new Color(outlineColor.getRed(), outlineColor.getGreen(), outlineColor.getBlue()));
               RenderUtil.renderOne((Float)CrystalModify.INSTANCE.lineWidth.getValue());
               if (var1.func_184520_k()) {
                  this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               } else {
                  this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               }

               RenderUtil.renderTwo();
               if (var1.func_184520_k()) {
                  this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               } else {
                  this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               }

               RenderUtil.renderThree();
               RenderUtil.renderFour(outlineColor);
               RenderUtil.setColor(new Color(outlineColor.getRed(), outlineColor.getGreen(), outlineColor.getBlue()));
               if (var1.func_184520_k()) {
                  this.field_76995_b.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               } else {
                  this.field_188316_g.func_78088_a(var1, 0.0F, var14 * spinSpeed, var15 * bounceSpeed, 0.0F, 0.0F, 0.0625F);
               }

               RenderUtil.renderFive();
               RenderUtil.setColor(Color.WHITE);
            }
         }

         GL11.glPopMatrix();
      }

   }
}
