package ryo.mrbubblegum.nhack4.injections.mixins.accessors;

import net.minecraft.network.play.client.CPacketPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({CPacketPlayer.class})
public interface ICPacketPlayer {
   @Accessor("yaw")
   float getYaw();

   @Accessor("yaw")
   void setYaw(float var1);

   @Accessor("pitch")
   float getPitch();

   @Accessor("pitch")
   void setPitch(float var1);

   @Accessor("y")
   double getY();

   @Accessor("y")
   void setY(double var1);

   @Accessor("onGround")
   void setOnGround(boolean var1);

   @Accessor("rotating")
   boolean isRotating();

   @Accessor("moving")
   boolean isMoving();
}
