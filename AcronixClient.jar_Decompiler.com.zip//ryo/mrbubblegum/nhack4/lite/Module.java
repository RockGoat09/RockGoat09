package ryo.mrbubblegum.nhack4.lite;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.minecraftforge.common.MinecraftForge;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.hud.HUD;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Bind;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;
import ryo.mrbubblegum.nhack4.world.events.Render2DEvent;
import ryo.mrbubblegum.nhack4.world.events.Render3DEvent;

public class Module extends Feature {
   private final String description;
   private final Module.Category category;
   public Setting<Boolean> enabled = this.register(new Setting("Enabled", false));
   public Setting<Boolean> drawn = this.register(new Setting("Drawn", true));
   public Setting<Bind> bind = this.register(new Setting("Bind", new Bind(-1)));
   public Setting<String> displayName;
   public boolean hasListener;
   public boolean alwaysListening;
   public boolean hidden;
   public float arrayListOffset = 0.0F;
   public float arrayListVOffset = 0.0F;
   public float offset;
   public float vOffset;
   public boolean sliding;
   public Module.Animation animation;

   public Module(String name, String description, Module.Category category, boolean hasListener, boolean hidden, boolean alwaysListening) {
      super(name);
      this.displayName = this.register(new Setting("DisplayName", name));
      this.description = description;
      this.category = category;
      this.hasListener = hasListener;
      this.hidden = hidden;
      this.alwaysListening = alwaysListening;
      this.animation = new Module.Animation(this);
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void onToggle() {
   }

   public void onLoad() {
   }

   public void onTick() {
   }

   public void onLogin() {
   }

   public void onLogout() {
   }

   public void onUpdate() {
   }

   public void onRender2D(Render2DEvent event) {
   }

   public void onRender3D(Render3DEvent event) {
   }

   public void onUnload() {
   }

   public String getDisplayInfo() {
      return null;
   }

   public boolean isOn() {
      return (Boolean)this.enabled.getValue();
   }

   public boolean isOff() {
      return !(Boolean)this.enabled.getValue();
   }

   public void setEnabled(boolean enabled) {
      if (enabled) {
         this.enable();
      } else {
         this.disable();
      }

   }

   public void enable() {
      this.enabled.setValue(true);
      this.onToggle();
      this.onEnable();
      if (this.isOn() && this.hasListener && !this.alwaysListening) {
         MinecraftForge.EVENT_BUS.register(this);
      }

   }

   public void disable() {
      if (this.hasListener && !this.alwaysListening) {
         MinecraftForge.EVENT_BUS.unregister(this);
      }

      this.enabled.setValue(false);
      this.onToggle();
      this.onDisable();
   }

   public void toggle() {
      ClientEvent event = new ClientEvent(!this.isEnabled() ? 1 : 0, this);
      MinecraftForge.EVENT_BUS.post(event);
      if (!event.isCanceled()) {
         this.setEnabled(!this.isEnabled());
      }

   }

   public String getDisplayName() {
      return (String)this.displayName.getValue();
   }

   public void setDisplayName(String name) {
      Module module = Loader.moduleManager.getModuleByDisplayName(name);
      Module originalModule = Loader.moduleManager.getModuleByName(name);
      if (module == null && originalModule == null) {
         Command.sendMessage(this.getDisplayName() + ", Original name: " + this.getName() + ", has been renamed to: " + name);
         this.displayName.setValue(name);
      } else {
         Command.sendMessage("§cA module of this name already exists.");
      }
   }

   public String getDescription() {
      return this.description;
   }

   public boolean isSliding() {
      return this.sliding;
   }

   public boolean isDrawn() {
      return (Boolean)this.drawn.getValue();
   }

   public void setDrawn(boolean drawn) {
      this.drawn.setValue(drawn);
   }

   public Module.Category getCategory() {
      return this.category;
   }

   public String getInfo() {
      return null;
   }

   public Bind getBind() {
      return (Bind)this.bind.getValue();
   }

   public void setBind(int key) {
      this.bind.setValue(new Bind(key));
   }

   public boolean listening() {
      return this.hasListener && this.isOn() || this.alwaysListening;
   }

   public String getFullArrayString() {
      return this.getDisplayName() + "§8" + (this.getDisplayInfo() != null ? " [§r" + this.getDisplayInfo() + "§8]" : "");
   }

   public class Animation extends Thread {
      public Module module;
      public float offset;
      public float vOffset;
      public String lastText;
      public boolean shouldMetaSlide;
      ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();

      public Animation(Module module) {
         super("Animation");
         this.module = module;
      }

      public void run() {
         String text = this.module.getDisplayName() + "§7" + (this.module.getDisplayInfo() != null ? " [§f" + this.module.getDisplayInfo() + "§7]" : "");
         this.module.offset = (float)Module.this.renderer.getStringWidth(text) / ((Integer)HUD.getInstance().animationHorizontalTime.getValue()).floatValue();
         this.module.vOffset = (float)Module.this.renderer.getFontHeight() / ((Integer)HUD.getInstance().animationVerticalTime.getValue()).floatValue();
         Module var10000;
         if (this.module.isEnabled() && (Integer)HUD.getInstance().animationHorizontalTime.getValue() != 1) {
            if (this.module.arrayListOffset > this.module.offset && Util.mc.field_71441_e != null) {
               var10000 = this.module;
               var10000.arrayListOffset -= this.module.offset;
               this.module.sliding = true;
            }
         } else if (this.module.isDisabled() && (Integer)HUD.getInstance().animationHorizontalTime.getValue() != 1) {
            if (this.module.arrayListOffset < (float)Module.this.renderer.getStringWidth(text) && Util.mc.field_71441_e != null) {
               var10000 = this.module;
               var10000.arrayListOffset += this.module.offset;
               this.module.sliding = true;
            } else {
               this.module.sliding = false;
            }
         }

      }

      public void start() {
         System.out.println("Starting animation thread for " + this.module.getName());
         this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
      }
   }

   public static enum Category {
      RENDER("Visual"),
      COMBAT("Combat"),
      PLAYER("Player"),
      MOVEMENT("Movement"),
      EXPLOIT("Exploit"),
      MISC("Miscellaneous"),
      CLIENT("Client"),
      HUD("Hud");

      private final String name;

      private Category(String name) {
         this.name = name;
      }

      public String getName() {
         return this.name;
      }
   }
}
