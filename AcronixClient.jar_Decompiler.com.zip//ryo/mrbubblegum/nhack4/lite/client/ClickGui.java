package ryo.mrbubblegum.nhack4.lite.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.gui.LiteGui;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;

public class ClickGui extends Module {
   private static ClickGui INSTANCE = new ClickGui();
   private final Setting<ClickGui.Settings> setting;
   public Setting<String> prefix;
   public Setting<Boolean> colorSync;
   public Setting<Boolean> rainbowRolling;
   public Setting<Integer> guiWidth;
   public Setting<Boolean> outline;
   public Setting<Boolean> outlineNew;
   public Setting<Float> outlineThickness;
   public Setting<Integer> o_red;
   public Setting<Integer> o_green;
   public Setting<Integer> o_blue;
   public Setting<Integer> o_alpha;
   public Setting<Boolean> sideSettings;
   public Setting<Integer> sideRed;
   public Setting<Integer> sideGreen;
   public Setting<Integer> sideBlue;
   public Setting<Integer> sideAlpha;
   public Setting<Boolean> snowing;
   public Setting<Boolean> enableSwitch;
   public Setting<Integer> sbRed;
   public Setting<Integer> sbGreen;
   public Setting<Integer> sbBlue;
   public Setting<Integer> sbAlpha;
   public Setting<Integer> seRed;
   public Setting<Integer> seGreen;
   public Setting<Integer> seBlue;
   public Setting<Integer> seAlpha;
   public Setting<Integer> sdRed;
   public Setting<Integer> sdGreen;
   public Setting<Integer> sdBlue;
   public Setting<Integer> sdAlpha;
   public Setting<Boolean> categoryDots;
   public Setting<Boolean> categoryTextCenter;
   public Setting<Boolean> buttonTextCenter;
   public Setting<Boolean> moduleDescription;
   public Setting<Boolean> blurEffect;
   public Setting<Boolean> guiBackground;
   public Setting<Integer> gbRed;
   public Setting<Integer> gbGreen;
   public Setting<Integer> gbBlue;
   public Setting<Integer> gbAlpha;
   public Setting<Boolean> moduleSeperate;
   public Setting<Integer> mosRed;
   public Setting<Integer> mosGreen;
   public Setting<Integer> mosBlue;
   public Setting<Integer> mosAlpha;
   public Setting<Boolean> moduleOutline;
   public Setting<Integer> moRed;
   public Setting<Integer> moGreen;
   public Setting<Integer> moBlue;
   public Setting<Integer> moAlpha;
   public Setting<Boolean> scroll;
   public Setting<Integer> scrollval;
   public Setting<Integer> red;
   public Setting<Integer> green;
   public Setting<Integer> blue;
   public Setting<Integer> hoverAlpha;
   public Setting<Integer> alpha;
   public Setting<Integer> b_red;
   public Setting<Integer> b_green;
   public Setting<Integer> b_blue;
   public Setting<Integer> b_alpha;
   public Setting<Integer> textRed;
   public Setting<Integer> textGreen;
   public Setting<Integer> textBlue;
   public Setting<Integer> textAlpha;
   public Setting<Integer> textRed2;
   public Setting<Integer> textGreen2;
   public Setting<Integer> textBlue2;
   public Setting<Integer> textAlpha2;
   public Setting<Boolean> customFov;
   public Setting<Float> fov;
   public Setting<Boolean> gear;
   public Setting<Boolean> openCloseChange;
   public Setting<String> open;
   public Setting<String> close;
   public Setting<String> moduleButton;
   public Setting<Integer> ocsRed;
   public Setting<Integer> ocsGreen;
   public Setting<Integer> ocsBlue;
   public Setting<Boolean> devSettings;
   public Setting<Integer> topRed;
   public Setting<Integer> topGreen;
   public Setting<Integer> topBlue;
   public Setting<Integer> topAlpha;
   public Setting<Boolean> frameSettings;
   public Setting<Integer> frameRed;
   public Setting<Integer> frameGreen;
   public Setting<Integer> frameBlue;
   public Setting<Integer> frameAlpha;
   public Setting<Boolean> gradiant;
   public Setting<Integer> gradiantRed;
   public Setting<Integer> gradiantGreen;
   public Setting<Integer> gradiantBlue;
   public Setting<Integer> gradiantAlpha;
   public Setting<Boolean> particles;
   public Setting<Integer> particleLength;
   public Setting<Integer> particlered;
   public Setting<Integer> particlegreen;
   public Setting<Integer> particleblue;
   public float hue;

   public ClickGui() {
      super("ClickGui", "graphical user interface", Module.Category.CLIENT, true, false, false);
      this.setting = this.register(new Setting("Page", ClickGui.Settings.Main));
      this.prefix = this.register((new Setting("Prefix", ".")).setRenderName(true));
      this.colorSync = this.register(new Setting("Sync", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.rainbowRolling = this.register(new Setting("RollingRainbow", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.colorSync.getValue() && (Boolean)Colors.INSTANCE.rainbow.getValue();
      }));
      this.guiWidth = this.register(new Setting("GuiWidth", 113, 90, 115, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Scaling;
      }));
      this.outline = this.register(new Setting("Outline", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines;
      }));
      this.outlineNew = this.register(new Setting("OutlineNew", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines;
      }));
      this.outlineThickness = this.register(new Setting("LineThickness", 2.5F, 0.5F, 5.0F, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.outlineNew.getValue();
      }));
      this.o_red = this.register(new Setting("OutlineRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.outlineNew.getValue();
      }));
      this.o_green = this.register(new Setting("OutlineGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.outlineNew.getValue();
      }));
      this.o_blue = this.register(new Setting("OutlineBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.outlineNew.getValue();
      }));
      this.o_alpha = this.register(new Setting("OutlineAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.outlineNew.getValue();
      }));
      this.sideSettings = this.register(new Setting("SideLine", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines;
      }));
      this.sideRed = this.register(new Setting("SideLineRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.sideSettings.getValue();
      }));
      this.sideGreen = this.register(new Setting("SideLineGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.sideSettings.getValue();
      }));
      this.sideBlue = this.register(new Setting("SideLineBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.sideSettings.getValue();
      }));
      this.sideAlpha = this.register(new Setting("SideLineAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.sideSettings.getValue();
      }));
      this.snowing = this.register(new Setting("Snowing", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background;
      }));
      this.enableSwitch = this.register(new Setting("Switch", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.sbRed = this.register(new Setting("SwitchBackgroundRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sbGreen = this.register(new Setting("SwitchBackgroundGreen", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sbBlue = this.register(new Setting("SwitchBackgroundBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sbAlpha = this.register(new Setting("SwitchBackgroundAlpha", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.seRed = this.register(new Setting("SwitchEnableRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.seGreen = this.register(new Setting("SwitchEnableGreen", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.seBlue = this.register(new Setting("SwitchEnabledBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.seAlpha = this.register(new Setting("SwitchEnableAlpha", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sdRed = this.register(new Setting("SwitchDisableRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sdGreen = this.register(new Setting("SwitchDisableGreen", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sdBlue = this.register(new Setting("SwitchDisableBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.sdAlpha = this.register(new Setting("SwitchDisableAlpha", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.enableSwitch.getValue();
      }));
      this.categoryDots = this.register(new Setting("CategoryArrow", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.categoryTextCenter = this.register(new Setting("CategoryTextCenter", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.buttonTextCenter = this.register(new Setting("ButtonTextCenter", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.moduleDescription = this.register(new Setting("Description", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.blurEffect = this.register(new Setting("Blur", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background;
      }));
      this.guiBackground = this.register(new Setting("GuiBackground", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background;
      }));
      this.gbRed = this.register(new Setting("GuiBackgroundRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.guiBackground.getValue();
      }));
      this.gbGreen = this.register(new Setting("GuiBackgroundGreen", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.guiBackground.getValue();
      }));
      this.gbBlue = this.register(new Setting("GuiBackgroundBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.guiBackground.getValue();
      }));
      this.gbAlpha = this.register(new Setting("GuiBackgroundAlpha", 150, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.guiBackground.getValue();
      }));
      this.moduleSeperate = this.register(new Setting("ModuleSeperateLine", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines;
      }));
      this.mosRed = this.register(new Setting("ModuleSeperateRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleSeperate.getValue();
      }));
      this.mosGreen = this.register(new Setting("ModuleSeperateGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleSeperate.getValue();
      }));
      this.mosBlue = this.register(new Setting("ModuleSeperateBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleSeperate.getValue();
      }));
      this.mosAlpha = this.register(new Setting("ModuleSeperateAlpha", 150, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleSeperate.getValue();
      }));
      this.moduleOutline = this.register(new Setting("ModuleOutline", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines;
      }));
      this.moRed = this.register(new Setting("ModuleOutlineRed", 21, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleOutline.getValue();
      }));
      this.moGreen = this.register(new Setting("ModuleOutlineGreen", 150, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleOutline.getValue();
      }));
      this.moBlue = this.register(new Setting("ModuleOutlineBlue", 21, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleOutline.getValue();
      }));
      this.moAlpha = this.register(new Setting("ModuleOutlineAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.moduleOutline.getValue();
      }));
      this.scroll = this.register(new Setting("Scroll", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.scrollval = this.register(new Setting("Scroll Speed", 10, 1, 30, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.scroll.getValue();
      }));
      this.red = this.register(new Setting("EnableButtonRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.green = this.register(new Setting("EnableButtonGreen", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.blue = this.register(new Setting("EnableButtonBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.hoverAlpha = this.register(new Setting("EnableAlpha", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.alpha = this.register(new Setting("HoverAlpha", 170, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.b_red = this.register(new Setting("ButtonBGRed", 23, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.b_green = this.register(new Setting("ButtonBGGreen", 35, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.b_blue = this.register(new Setting("ButtonBGBlue", 23, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.b_alpha = this.register(new Setting("ButtonBGAlpha", 180, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.textRed = this.register(new Setting("EnabledTextRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textGreen = this.register(new Setting("EnabledTextGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textBlue = this.register(new Setting("EnabledTextBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textAlpha = this.register(new Setting("EnabledTextAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textRed2 = this.register(new Setting("DisabledTextRed", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textGreen2 = this.register(new Setting("DisabledTextGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textBlue2 = this.register(new Setting("DisabledTextBlue", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.textAlpha2 = this.register(new Setting("DisabledTextAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.FontC;
      }));
      this.customFov = this.register(new Setting("CustomFov", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.fov = this.register(new Setting("Fov", 135.0F, -180.0F, 180.0F, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.customFov.getValue();
      }));
      this.gear = this.register(new Setting("Gears", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.openCloseChange = this.register(new Setting("Open/Close", false, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc;
      }));
      this.open = this.register((new Setting("Open:", "+", (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.openCloseChange.getValue();
      })).setRenderName(true));
      this.close = this.register((new Setting("Close:", "-", (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.openCloseChange.getValue();
      })).setRenderName(true));
      this.moduleButton = this.register((new Setting("Buttons:", "", (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && !(Boolean)this.openCloseChange.getValue();
      })).setRenderName(true));
      this.ocsRed = this.register(new Setting("SideStringRed", 192, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.openCloseChange.getValue() || (Boolean)this.gear.getValue();
      }));
      this.ocsGreen = this.register(new Setting("SideStringGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.openCloseChange.getValue() || (Boolean)this.gear.getValue();
      }));
      this.ocsBlue = this.register(new Setting("SideStringBlue", 192, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Misc && (Boolean)this.openCloseChange.getValue() || (Boolean)this.gear.getValue();
      }));
      this.devSettings = this.register(new Setting("TopColor", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main;
      }));
      this.topRed = this.register(new Setting("TopRed", 21, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main && (Boolean)this.devSettings.getValue();
      }));
      this.topGreen = this.register(new Setting("TopGreen", 45, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main && (Boolean)this.devSettings.getValue();
      }));
      this.topBlue = this.register(new Setting("TopBlue", 21, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main && (Boolean)this.devSettings.getValue();
      }));
      this.topAlpha = this.register(new Setting("TopAlpha", 170, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Main && (Boolean)this.devSettings.getValue();
      }));
      this.frameSettings = this.register(new Setting("FrameSetting", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines;
      }));
      this.frameRed = this.register(new Setting("FrameRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.frameSettings.getValue();
      }));
      this.frameGreen = this.register(new Setting("FrameGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.frameSettings.getValue();
      }));
      this.frameBlue = this.register(new Setting("FrameBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.frameSettings.getValue();
      }));
      this.frameAlpha = this.register(new Setting("FrameAlpha", 30, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Lines && (Boolean)this.frameSettings.getValue();
      }));
      this.gradiant = this.register(new Setting("Gradiant", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background;
      }));
      this.gradiantRed = this.register(new Setting("GradiantRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.gradiant.getValue();
      }));
      this.gradiantGreen = this.register(new Setting("GradiantGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.gradiant.getValue();
      }));
      this.gradiantBlue = this.register(new Setting("GradiantBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.gradiant.getValue();
      }));
      this.gradiantAlpha = this.register(new Setting("GradiantAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.gradiant.getValue();
      }));
      this.particles = this.register(new Setting("Particles", true, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background;
      }));
      this.particleLength = this.register(new Setting("ParticleLength", 103, 0, 300, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.particles.getValue();
      }));
      this.particlered = this.register(new Setting("ParticleRed", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.particles.getValue();
      }));
      this.particlegreen = this.register(new Setting("ParticleGreen", 255, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.particles.getValue();
      }));
      this.particleblue = this.register(new Setting("ParticleBlue", 0, 0, 255, (v) -> {
         return this.setting.getValue() == ClickGui.Settings.Background && (Boolean)this.particles.getValue();
      }));
      this.setInstance();
      this.setBind(54);
   }

   public static ClickGui getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new ClickGui();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onUpdate() {
      if ((Boolean)this.customFov.getValue()) {
         mc.field_71474_y.func_74304_a(Options.FOV, (Float)this.fov.getValue());
      }

   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
         if (event.getSetting().equals(this.prefix)) {
            Loader.commandManager.setPrefix((String)this.prefix.getPlannedValue());
            Command.sendMessage("Prefix set to §a" + Loader.commandManager.getPrefix());
         }

         Loader.colorManager.setColor((Integer)this.red.getPlannedValue(), (Integer)this.green.getPlannedValue(), (Integer)this.blue.getPlannedValue(), (Integer)this.hoverAlpha.getPlannedValue());
      }

   }

   public void onEnable() {
      Util.mc.func_147108_a(new LiteGui());
      if ((Boolean)this.blurEffect.getValue()) {
         mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
      }

   }

   public void onLoad() {
      if ((Boolean)this.colorSync.getValue()) {
         Loader.colorManager.setColor(Colors.INSTANCE.getCurrentColor().getRed(), Colors.INSTANCE.getCurrentColor().getGreen(), Colors.INSTANCE.getCurrentColor().getBlue(), (Integer)this.hoverAlpha.getValue());
      } else {
         Loader.colorManager.setColor((Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue(), (Integer)this.hoverAlpha.getValue());
      }

      Loader.commandManager.setPrefix((String)this.prefix.getValue());
   }

   public void onTick() {
      if (!(mc.field_71462_r instanceof LiteGui)) {
         this.disable();
         if (mc.field_71460_t.func_147706_e() != null) {
            mc.field_71460_t.func_147706_e().func_148021_a();
         }
      }

   }

   public void onDisable() {
      if (mc.field_71462_r instanceof LiteGui) {
         Util.mc.func_147108_a((GuiScreen)null);
      }

   }

   public static enum Settings {
      Main,
      Lines,
      Background,
      FontC,
      Scaling,
      Misc;
   }
}
