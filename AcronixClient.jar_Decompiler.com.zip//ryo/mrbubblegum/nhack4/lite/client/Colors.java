package ryo.mrbubblegum.nhack4.lite.client;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import ryo.mrbubblegum.nhack4.impl.util.ColorUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class Colors extends Module {
   public static Colors INSTANCE;
   public Setting<Boolean> rainbow = this.register(new Setting("Rainbow", false, "Rainbow colors."));
   public Setting<Integer> rainbowSpeed = this.register(new Setting("Speed", 20, 0, 100, (v) -> {
      return (Boolean)this.rainbow.getValue();
   }));
   public Setting<Integer> rainbowSaturation = this.register(new Setting("Saturation", 150, 0, 255, (v) -> {
      return (Boolean)this.rainbow.getValue();
   }));
   public Setting<Integer> rainbowBrightness = this.register(new Setting("Brightness", 150, 0, 255, (v) -> {
      return (Boolean)this.rainbow.getValue();
   }));
   public Setting<Integer> red = this.register(new Setting("Red", 255, 0, 255, (v) -> {
      return !(Boolean)this.rainbow.getValue();
   }));
   public Setting<Integer> green = this.register(new Setting("Green", 255, 0, 255, (v) -> {
      return !(Boolean)this.rainbow.getValue();
   }));
   public Setting<Integer> blue = this.register(new Setting("Blue", 255, 0, 255, (v) -> {
      return !(Boolean)this.rainbow.getValue();
   }));
   public Setting<Integer> alpha = this.register(new Setting("Alpha", 255, 0, 255, (v) -> {
      return !(Boolean)this.rainbow.getValue();
   }));
   public float hue;
   public Map<Integer, Integer> colorHeightMap = new HashMap();

   public Colors() {
      super("Colors", "sync colors across the client", Module.Category.CLIENT, true, false, true);
      INSTANCE = this;
   }

   public void onTick() {
      int colorSpeed = 101 - (Integer)this.rainbowSpeed.getValue();
      float tempHue = this.hue = (float)(System.currentTimeMillis() % (360L * (long)colorSpeed)) / (360.0F * (float)colorSpeed);

      for(int i = 0; i <= 510; ++i) {
         this.colorHeightMap.put(i, Color.HSBtoRGB(tempHue, (float)(Integer)this.rainbowSaturation.getValue() / 255.0F, (float)(Integer)this.rainbowBrightness.getValue() / 255.0F));
         tempHue += 0.0013071896F;
      }

      if ((Boolean)ClickGui.getInstance().colorSync.getValue()) {
         Loader.colorManager.setColor(INSTANCE.getCurrentColor().getRed(), INSTANCE.getCurrentColor().getGreen(), INSTANCE.getCurrentColor().getBlue(), (Integer)ClickGui.getInstance().hoverAlpha.getValue());
      }

   }

   public int getCurrentColorHex() {
      return (Boolean)this.rainbow.getValue() ? Color.HSBtoRGB(this.hue, (float)(Integer)this.rainbowSaturation.getValue() / 255.0F, (float)(Integer)this.rainbowBrightness.getValue() / 255.0F) : ColorUtil.toARGB((Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue(), (Integer)this.alpha.getValue());
   }

   public Color getCurrentColor() {
      return (Boolean)this.rainbow.getValue() ? Color.getHSBColor(this.hue, (float)(Integer)this.rainbowSaturation.getValue() / 255.0F, (float)(Integer)this.rainbowBrightness.getValue() / 255.0F) : new Color((Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue(), (Integer)this.alpha.getValue());
   }
}
