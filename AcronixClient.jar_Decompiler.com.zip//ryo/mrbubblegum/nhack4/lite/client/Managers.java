package ryo.mrbubblegum.nhack4.lite.client;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;

public class Managers extends Module {
   private static Managers INSTANCE = new Managers();
   public Setting<Boolean> betterFrames = this.register(new Setting("BetterMaxFPS", false));
   public Setting<Integer> betterFPS = this.register(new Setting("MaxFPS", 300, 30, 1000, (v) -> {
      return (Boolean)this.betterFrames.getValue();
   }));
   public Setting<Boolean> potions = this.register(new Setting("Potions", true));
   public Setting<Integer> textRadarUpdates = this.register(new Setting("TRUpdates", 500, 0, 1000));
   public Setting<Integer> respondTime = this.register(new Setting("SeverTime", 500, 0, 1000));
   public Setting<Integer> moduleListUpdates = this.register(new Setting("ALUpdates", 1000, 0, 1000));
   public Setting<Float> holeRange = this.register(new Setting("HoleRange", 6.0F, 1.0F, 256.0F));
   public Setting<Integer> holeUpdates = this.register(new Setting("HoleUpdates", 100, 0, 1000));
   public Setting<Integer> holeSync = this.register(new Setting("HoleSync", 10000, 1, 10000));
   public Setting<Boolean> safety = this.register(new Setting("SafetyPlayer", false));
   public Setting<Integer> safetyCheck = this.register(new Setting("SafetyCheck", 50, 1, 150));
   public Setting<Integer> safetySync = this.register(new Setting("SafetySync", 250, 1, 10000));
   public Setting<Managers.ThreadMode> holeThread;
   public Setting<Boolean> speed;
   public Setting<Boolean> oneDot15;
   public Setting<Boolean> tRadarInv;
   public Setting<Boolean> unfocusedCpu;
   public Setting<Integer> cpuFPS;
   public Setting<Integer> baritoneTimeOut;
   public Setting<Boolean> oneChunk;

   public Managers() {
      super("Management", "ClientManagement", Module.Category.CLIENT, false, false, true);
      this.holeThread = this.register(new Setting("HoleThread", Managers.ThreadMode.WHILE));
      this.speed = this.register(new Setting("Speed", true));
      this.oneDot15 = this.register(new Setting("1.15", false));
      this.tRadarInv = this.register(new Setting("TRadarInv", true));
      this.unfocusedCpu = this.register(new Setting("UnfocusedCPU", false));
      this.cpuFPS = this.register(new Setting("UnfocusedFPS", 60, 1, 60, (v) -> {
         return (Boolean)this.unfocusedCpu.getValue();
      }));
      this.baritoneTimeOut = this.register(new Setting("Baritone", 5, 1, 20));
      this.oneChunk = this.register(new Setting("OneChunk", false));
      this.setInstance();
   }

   public static Managers getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Managers();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2) {
         if ((Boolean)this.oneChunk.getPlannedValue()) {
            mc.field_71474_y.field_151451_c = 1;
         }

         if (event.getSetting() != null && this.equals(event.getSetting().getFeature()) && event.getSetting().equals(this.holeThread)) {
            Loader.holeManager.settingChanged();
         }
      }

   }

   public static enum ThreadMode {
      POOL,
      WHILE,
      NONE;
   }
}
