package ryo.mrbubblegum.nhack4.lite.client;

import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class NickHider extends Module {
   private static NickHider instance;
   public final Setting<Boolean> changeOwn = this.register(new Setting("MyName", true));
   public final Setting<String> ownName = this.register(new Setting("Name", "Name here...", (v) -> {
      return (Boolean)this.changeOwn.getValue();
   }));

   public NickHider() {
      super("NickChanger", "Helps with creating media", Module.Category.CLIENT, false, false, false);
      instance = this;
   }

   public static NickHider getInstance() {
      if (instance == null) {
         instance = new NickHider();
      }

      return instance;
   }

   public static String getPlayerName() {
      if (!fullNullCheck() && PingBypass.getInstance().isConnected()) {
         String name = PingBypass.getInstance().getPlayerName();
         return name != null && !name.isEmpty() ? name : Util.mc.func_110432_I().func_111285_a();
      } else {
         return Util.mc.func_110432_I().func_111285_a();
      }
   }
}
