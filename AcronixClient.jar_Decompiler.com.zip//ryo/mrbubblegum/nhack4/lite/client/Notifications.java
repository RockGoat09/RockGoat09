package ryo.mrbubblegum.nhack4.lite.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.manager.FileManager;
import ryo.mrbubblegum.nhack4.impl.util.TextUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.hud.ModuleTools;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;

public class Notifications extends Module {
   private static final String fileName = "nhack4/util/ModuleMessage_List.txt";
   private static final List<String> modules = new ArrayList();
   private static Notifications INSTANCE = new Notifications();
   private final Timer timer = new Timer();
   public Setting<Boolean> totemPops = this.register(new Setting("TotemPops", true));
   public Setting<Boolean> totemNoti;
   public Setting<Integer> delay;
   public Setting<Boolean> clearOnLogout;
   public Setting<Boolean> moduleMessage;
   private final Setting<Boolean> readfile;
   public Setting<Boolean> list;
   public Setting<Boolean> visualRange;
   public Setting<Boolean> VisualRangeSound;
   public Setting<Boolean> coords;
   public Setting<Boolean> leaving;
   public Setting<Boolean> pearls;
   public Setting<Boolean> crash;
   public Setting<Boolean> popUp;
   public Timer totemAnnounce;
   private List<EntityPlayer> knownPlayers;
   private boolean check;

   public Notifications() {
      super("Notifications", "notifications dawg", Module.Category.CLIENT, true, false, false);
      this.totemNoti = this.register(new Setting("TotemNoti", Boolean.FALSE, (v) -> {
         return (Boolean)this.totemPops.getValue();
      }));
      this.delay = this.register(new Setting("Delay", 200, 0, 5000, (v) -> {
         return (Boolean)this.totemPops.getValue();
      }, "Delays messages."));
      this.clearOnLogout = this.register(new Setting("LogoutClear", false));
      this.moduleMessage = this.register(new Setting("ModuleMessage", true));
      this.readfile = this.register(new Setting("LoadFile", Boolean.FALSE, (v) -> {
         return (Boolean)this.moduleMessage.getValue();
      }));
      this.list = this.register(new Setting("List", Boolean.FALSE, (v) -> {
         return (Boolean)this.moduleMessage.getValue();
      }));
      this.visualRange = this.register(new Setting("VisualRange", false));
      this.VisualRangeSound = this.register(new Setting("VisualRangeSound", false));
      this.coords = this.register(new Setting("Coords", Boolean.TRUE, (v) -> {
         return (Boolean)this.visualRange.getValue();
      }));
      this.leaving = this.register(new Setting("Leaving", Boolean.FALSE, (v) -> {
         return (Boolean)this.visualRange.getValue();
      }));
      this.pearls = this.register(new Setting("PearlNotifs", false));
      this.crash = this.register(new Setting("Crash", false));
      this.popUp = this.register(new Setting("PopUpVisualRange", false));
      this.totemAnnounce = new Timer();
      this.knownPlayers = new ArrayList();
      this.setInstance();
   }

   public static Notifications getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Notifications();
      }

      return INSTANCE;
   }

   public static void displayCrash(Exception e) {
      Command.sendMessage("§cException caught: " + e.getMessage());
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onLoad() {
      this.check = true;
      this.loadFile();
      this.check = false;
   }

   public void onEnable() {
      this.knownPlayers = new ArrayList();
      if (!this.check) {
         this.loadFile();
      }

   }

   public void onUpdate() {
      if ((Boolean)this.readfile.getValue()) {
         if (!this.check) {
            Command.sendMessage("Loading File...");
            this.timer.reset();
            this.loadFile();
         }

         this.check = true;
      }

      if (this.check && this.timer.passedMs(750L)) {
         this.readfile.setValue(false);
         this.check = false;
      }

      if ((Boolean)this.visualRange.getValue()) {
         ArrayList<EntityPlayer> tickPlayerList = new ArrayList(mc.field_71441_e.field_73010_i);
         Iterator var2;
         EntityPlayer player;
         if (tickPlayerList.size() > 0) {
            var2 = tickPlayerList.iterator();

            while(var2.hasNext()) {
               player = (EntityPlayer)var2.next();
               if (!player.func_70005_c_().equals(mc.field_71439_g.func_70005_c_()) && !this.knownPlayers.contains(player)) {
                  this.knownPlayers.add(player);
                  if (Loader.friendManager.isFriend(player)) {
                     Command.sendMessage("Player §a" + player.func_70005_c_() + "§r entered your visual range" + ((Boolean)this.coords.getValue() ? " at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!" : "!"), (Boolean)this.popUp.getValue());
                  } else {
                     Command.sendMessage("Player §c" + player.func_70005_c_() + "§r entered your visual range" + ((Boolean)this.coords.getValue() ? " at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!" : "!"), (Boolean)this.popUp.getValue());
                  }

                  if ((Boolean)this.VisualRangeSound.getValue()) {
                     mc.field_71439_g.func_184185_a(SoundEvents.field_187689_f, 1.0F, 1.0F);
                  }

                  return;
               }
            }
         }

         if (this.knownPlayers.size() > 0) {
            var2 = this.knownPlayers.iterator();

            while(var2.hasNext()) {
               player = (EntityPlayer)var2.next();
               if (!tickPlayerList.contains(player)) {
                  this.knownPlayers.remove(player);
                  if ((Boolean)this.leaving.getValue()) {
                     if (Loader.friendManager.isFriend(player)) {
                        Command.sendMessage("Player §a" + player.func_70005_c_() + "§r left your visual range" + ((Boolean)this.coords.getValue() ? " at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!" : "!"), (Boolean)this.popUp.getValue());
                     } else {
                        Command.sendMessage("Player §c" + player.func_70005_c_() + "§r left your visual range" + ((Boolean)this.coords.getValue() ? " at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!" : "!"), (Boolean)this.popUp.getValue());
                     }
                  }

                  return;
               }
            }
         }
      }

   }

   public void loadFile() {
      List<String> fileInput = FileManager.readTextFileAllLines("nhack4/util/ModuleMessage_List.txt");
      Iterator<String> i = fileInput.iterator();
      modules.clear();

      while(i.hasNext()) {
         String s = (String)i.next();
         if (!s.replaceAll("\\s", "").isEmpty()) {
            modules.add(s);
         }
      }

   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketSpawnObject && (Boolean)this.pearls.getValue()) {
         SPacketSpawnObject packet = (SPacketSpawnObject)event.getPacket();
         EntityPlayer player = mc.field_71441_e.func_184137_a(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e(), 1.0D, false);
         if (player == null) {
            return;
         }

         if (packet.func_149001_c() == 85) {
            Command.sendMessage("§cPearl thrown by " + player.func_70005_c_() + " at X:" + (int)packet.func_186880_c() + " Y:" + (int)packet.func_186882_d() + " Z:" + (int)packet.func_186881_e());
         }
      }

   }

   public TextComponentString getNotifierOn(Module module) {
      TextComponentString text;
      if (ModuleTools.getInstance().isEnabled()) {
         switch((ModuleTools.Notifier)ModuleTools.getInstance().notifier.getValue()) {
         case NHACK4:
            text = new TextComponentString(Loader.commandManager.getClientMessage() + " " + ChatFormatting.BOLD + module.getDisplayName() + ChatFormatting.RESET + ChatFormatting.GREEN + " enabled.");
            return text;
         case FUTURE:
            text = new TextComponentString(ChatFormatting.RED + "[Future] " + ChatFormatting.GRAY + module.getDisplayName() + " toggled " + ChatFormatting.GREEN + "on" + ChatFormatting.GRAY + ".");
            return text;
         case DOTGOD:
            text = new TextComponentString(ChatFormatting.DARK_PURPLE + "[" + ChatFormatting.LIGHT_PURPLE + "DotGod.CC" + ChatFormatting.DARK_PURPLE + "] " + ChatFormatting.DARK_AQUA + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + " was " + ChatFormatting.GREEN + "enabled.");
            return text;
         case SNOW:
            text = new TextComponentString(ChatFormatting.BLUE + "[" + ChatFormatting.AQUA + "Snow" + ChatFormatting.BLUE + "] [" + ChatFormatting.DARK_AQUA + module.getDisplayName() + ChatFormatting.BLUE + "] " + ChatFormatting.GREEN + "enabled");
            return text;
         case WEATHER:
            text = new TextComponentString(ChatFormatting.AQUA + "[" + ChatFormatting.AQUA + "Weather" + ChatFormatting.AQUA + "] " + ChatFormatting.DARK_AQUA + module.getDisplayName() + ChatFormatting.WHITE + " was toggled " + ChatFormatting.GREEN + "on.");
            return text;
         case CATALYST:
            text = new TextComponentString(ChatFormatting.DARK_GRAY + "[" + ChatFormatting.AQUA + "Catalyst" + ChatFormatting.DARK_GRAY + "] " + ChatFormatting.GRAY + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.GREEN + " ON");
            return text;
         case RUSHERHACK:
            text = new TextComponentString(ChatFormatting.WHITE + "[" + ChatFormatting.GREEN + "rusherhack" + ChatFormatting.WHITE + "] " + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.WHITE + " has been enabled");
            return text;
         case KONAS:
            text = new TextComponentString(ChatFormatting.DARK_GRAY + "[" + ChatFormatting.LIGHT_PURPLE + "Konas" + ChatFormatting.DARK_GRAY + "] " + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.WHITE + " has been enabled");
            return text;
         case LEGACY:
            text = new TextComponentString(ChatFormatting.WHITE + "[" + ChatFormatting.LIGHT_PURPLE + "Legacy" + ChatFormatting.WHITE + "] " + ChatFormatting.BOLD + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.GREEN + " enabled.");
            return text;
         case EUROPA:
            text = new TextComponentString(ChatFormatting.GRAY + "[" + ChatFormatting.RED + "Europa" + ChatFormatting.GRAY + "] " + ChatFormatting.RESET + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.GREEN + ChatFormatting.BOLD + " Enabled!");
            return text;
         case PYRO:
            text = new TextComponentString(ChatFormatting.DARK_RED + "[" + ChatFormatting.DARK_RED + "Pyro" + ChatFormatting.DARK_RED + "] " + ChatFormatting.GREEN + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.GREEN + " has been enabled.");
            return text;
         case MUFFIN:
            text = new TextComponentString(ChatFormatting.LIGHT_PURPLE + "[" + ChatFormatting.DARK_PURPLE + "Muffin" + ChatFormatting.LIGHT_PURPLE + "] " + ChatFormatting.LIGHT_PURPLE + module.getDisplayName() + ChatFormatting.DARK_PURPLE + " was " + ChatFormatting.GREEN + "enabled.");
            return text;
         case ABYSS:
            text = new TextComponentString(TextUtil.coloredString("[Abyss] ", (TextUtil.Color)ModuleTools.getInstance().abyssColor.getPlannedValue()) + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.GREEN + " ON");
            return text;
         case LUIGIHACK:
            text = new TextComponentString(ChatFormatting.GREEN + "[LuigiHack] " + ChatFormatting.GRAY + module.getDisplayName() + " toggled " + ChatFormatting.GREEN + "on" + ChatFormatting.GRAY + ".");
            return text;
         }
      }

      text = new TextComponentString(Loader.commandManager.getClientMessage() + " " + ChatFormatting.GREEN + module.getDisplayName() + " toggled on.");
      return text;
   }

   public TextComponentString getNotifierOff(Module module) {
      TextComponentString text;
      if (ModuleTools.getInstance().isEnabled()) {
         switch((ModuleTools.Notifier)ModuleTools.getInstance().notifier.getValue()) {
         case NHACK4:
            text = new TextComponentString(Loader.commandManager.getClientMessage() + " " + ChatFormatting.BOLD + module.getDisplayName() + ChatFormatting.RESET + ChatFormatting.RED + " disabled.");
            return text;
         case FUTURE:
            text = new TextComponentString(ChatFormatting.RED + "[Future] " + ChatFormatting.GRAY + module.getDisplayName() + " toggled " + ChatFormatting.RED + "off" + ChatFormatting.GRAY + ".");
            return text;
         case DOTGOD:
            text = new TextComponentString(ChatFormatting.DARK_PURPLE + "[" + ChatFormatting.LIGHT_PURPLE + "DotGod.CC" + ChatFormatting.DARK_PURPLE + "] " + ChatFormatting.DARK_AQUA + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + " was " + ChatFormatting.RED + "disabled.");
            return text;
         case SNOW:
            text = new TextComponentString(ChatFormatting.BLUE + "[" + ChatFormatting.AQUA + "Snow" + ChatFormatting.BLUE + "] [" + ChatFormatting.DARK_AQUA + module.getDisplayName() + ChatFormatting.BLUE + "] " + ChatFormatting.RED + "disabled");
            return text;
         case WEATHER:
            text = new TextComponentString(ChatFormatting.AQUA + "[" + ChatFormatting.AQUA + "Weather" + ChatFormatting.AQUA + "] " + ChatFormatting.DARK_AQUA + module.getDisplayName() + ChatFormatting.WHITE + " was toggled " + ChatFormatting.RED + "off.");
            return text;
         case CATALYST:
            text = new TextComponentString(ChatFormatting.DARK_GRAY + "[" + ChatFormatting.AQUA + "Catalyst" + ChatFormatting.DARK_GRAY + "] " + ChatFormatting.GRAY + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.RED + " OFF");
            return text;
         case RUSHERHACK:
            text = new TextComponentString(ChatFormatting.WHITE + "[" + ChatFormatting.GREEN + "rusherhack" + ChatFormatting.WHITE + "] " + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.WHITE + " has been disabled");
            return text;
         case KONAS:
            text = new TextComponentString(ChatFormatting.DARK_GRAY + "[" + ChatFormatting.LIGHT_PURPLE + "Konas" + ChatFormatting.DARK_GRAY + "] " + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.WHITE + " has been disabled");
            return text;
         case LEGACY:
            text = new TextComponentString(ChatFormatting.WHITE + "[" + ChatFormatting.LIGHT_PURPLE + "Legacy" + ChatFormatting.WHITE + "] " + ChatFormatting.BOLD + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.RED + " disabled.");
            return text;
         case EUROPA:
            text = new TextComponentString(ChatFormatting.GRAY + "[" + ChatFormatting.RED + "Europa" + ChatFormatting.GRAY + "] " + ChatFormatting.RESET + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.RED + ChatFormatting.BOLD + " Disabled!");
            return text;
         case PYRO:
            text = new TextComponentString(ChatFormatting.DARK_RED + "[" + ChatFormatting.DARK_RED + "Pyro" + ChatFormatting.DARK_RED + "] " + ChatFormatting.RED + module.getDisplayName() + ChatFormatting.LIGHT_PURPLE + "" + ChatFormatting.RED + " has been disabled.");
            return text;
         case MUFFIN:
            text = new TextComponentString(ChatFormatting.LIGHT_PURPLE + "[" + ChatFormatting.DARK_PURPLE + "Muffin" + ChatFormatting.LIGHT_PURPLE + "] " + ChatFormatting.LIGHT_PURPLE + module.getDisplayName() + ChatFormatting.DARK_PURPLE + " was " + ChatFormatting.RED + "disabled.");
            return text;
         case ABYSS:
            text = new TextComponentString(TextUtil.coloredString("[Abyss] ", (TextUtil.Color)ModuleTools.getInstance().abyssColor.getPlannedValue()) + ChatFormatting.WHITE + module.getDisplayName() + ChatFormatting.RED + " OFF");
            return text;
         case LUIGIHACK:
            text = new TextComponentString(ChatFormatting.GREEN + "[LuigiHack] " + ChatFormatting.GRAY + module.getDisplayName() + " toggled " + ChatFormatting.RED + "off" + ChatFormatting.GRAY + ".");
            return text;
         }
      }

      text = new TextComponentString(Loader.commandManager.getClientMessage() + " " + ChatFormatting.RED + module.getDisplayName() + " toggled off.");
      return text;
   }

   @SubscribeEvent
   public void onToggleModule(ClientEvent event) {
      if ((Boolean)this.moduleMessage.getValue()) {
         int moduleNumber;
         Module module;
         char[] var4;
         int var5;
         int var6;
         char character;
         if (event.getStage() == 0 && !(module = (Module)event.getFeature()).equals(this) && (modules.contains(module.getDisplayName()) || !(Boolean)this.list.getValue())) {
            moduleNumber = 0;
            var4 = module.getDisplayName().toCharArray();
            var5 = var4.length;

            for(var6 = 0; var6 < var5; ++var6) {
               character = var4[var6];
               moduleNumber += character;
               moduleNumber *= 10;
            }

            mc.field_71456_v.func_146158_b().func_146234_a(this.getNotifierOff(module), moduleNumber);
         }

         if (event.getStage() == 1 && (modules.contains((module = (Module)event.getFeature()).getDisplayName()) || !(Boolean)this.list.getValue())) {
            moduleNumber = 0;
            var4 = module.getDisplayName().toCharArray();
            var5 = var4.length;

            for(var6 = 0; var6 < var5; ++var6) {
               character = var4[var6];
               moduleNumber += character;
               moduleNumber *= 10;
            }

            mc.field_71456_v.func_146158_b().func_146234_a(this.getNotifierOn(module), moduleNumber);
         }

      }
   }
}
