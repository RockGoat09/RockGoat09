package ryo.mrbubblegum.nhack4.lite.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketKeepAlive;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.TextUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.injections.mixins.accessors.IC00Handshake;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;

public class PingBypass extends Module {
   private static PingBypass instance;
   private final AtomicBoolean connected = new AtomicBoolean(false);
   private final Timer pingTimer = new Timer();
   private final List<Long> pingList = new ArrayList();
   public Setting<String> ip = this.register(new Setting("IP", "0.0.0.0.0"));
   public Setting<String> port = this.register((new Setting("Port", "0")).setRenderName(true));
   public Setting<String> serverIP = this.register(new Setting("ServerIP", "crystalpvp.cc"));
   public Setting<Boolean> noFML = this.register(new Setting("RemoveFML", false));
   public Setting<Boolean> getName = this.register(new Setting("GetName", false));
   public Setting<Boolean> average = this.register(new Setting("Average", false));
   public Setting<Boolean> clear = this.register(new Setting("ClearPings", false));
   public Setting<Boolean> oneWay = this.register(new Setting("OneWay", false));
   public Setting<Integer> delay = this.register(new Setting("KeepAlives", 10, 1, 50));
   private long currentPing = 0L;
   private long serverPing = 0L;
   private StringBuffer name = null;
   private long averagePing = 0L;
   private String serverPrefix = "idk";

   public PingBypass() {
      super("PingBypass", "Manages Loader`s internal Server", Module.Category.CLIENT, false, false, true);
      instance = this;
   }

   public static PingBypass getInstance() {
      if (instance == null) {
         instance = new PingBypass();
      }

      return instance;
   }

   public String getPlayerName() {
      return this.name == null ? null : this.name.toString();
   }

   public String getServerPrefix() {
      return this.serverPrefix;
   }

   public void onLogout() {
      this.averagePing = 0L;
      this.currentPing = 0L;
      this.serverPing = 0L;
      this.pingList.clear();
      this.connected.set(false);
      this.name = null;
   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketChat) {
         SPacketChat packet = (SPacketChat)event.getPacket();
         if (packet.field_148919_a.func_150260_c().startsWith("@Clientprefix")) {
            this.serverPrefix = packet.field_148919_a.func_150254_d().replace("@Clientprefix", "");
         }
      }

   }

   public void onTick() {
      if (Util.mc.func_147114_u() != null && this.isConnected()) {
         if ((Boolean)this.getName.getValue()) {
            Util.mc.func_147114_u().func_147297_a(new CPacketChatMessage("@Servername"));
            this.getName.setValue(false);
         }

         if (this.serverPrefix.equalsIgnoreCase("idk") && mc.field_71441_e != null) {
            Util.mc.func_147114_u().func_147297_a(new CPacketChatMessage("@Servergetprefix"));
         }

         if (this.pingTimer.passedMs((long)((Integer)this.delay.getValue() * 1000))) {
            Util.mc.func_147114_u().func_147297_a(new CPacketKeepAlive(100L));
            this.pingTimer.reset();
         }

         if ((Boolean)this.clear.getValue()) {
            this.pingList.clear();
         }
      }

   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Receive event) {
      if (event.getPacket() instanceof SPacketChat) {
         SPacketChat packetChat = (SPacketChat)event.getPacket();
         if (packetChat.func_148915_c().func_150254_d().startsWith("@Client")) {
            this.name = new StringBuffer(TextUtil.stripColor(packetChat.func_148915_c().func_150254_d().replace("@Client", "")));
            event.setCanceled(true);
         }
      } else {
         SPacketKeepAlive alive;
         if (event.getPacket() instanceof SPacketKeepAlive && (alive = (SPacketKeepAlive)event.getPacket()).func_149134_c() > 0L && alive.func_149134_c() < 1000L) {
            this.serverPing = alive.func_149134_c();
            this.currentPing = (Boolean)this.oneWay.getValue() ? this.pingTimer.getPassedTimeMs() / 2L : this.pingTimer.getPassedTimeMs();
            this.pingList.add(this.currentPing);
            this.averagePing = this.getAveragePing();
         }
      }

   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      IC00Handshake packet;
      if (event.getPacket() instanceof C00Handshake && (packet = (IC00Handshake)event.getPacket()).getIp().equals(this.ip.getValue())) {
         packet.setIp((String)this.serverIP.getValue());
         System.out.println(packet.getIp());
         this.connected.set(true);
      }

   }

   public String getDisplayInfo() {
      return this.averagePing + "ms";
   }

   private long getAveragePing() {
      if ((Boolean)this.average.getValue() && !this.pingList.isEmpty()) {
         int full = 0;

         long i;
         for(Iterator var2 = this.pingList.iterator(); var2.hasNext(); full = (int)((long)full + i)) {
            i = (Long)var2.next();
         }

         return (long)(full / this.pingList.size());
      } else {
         return this.currentPing;
      }
   }

   public boolean isConnected() {
      return this.connected.get();
   }

   public int getPort() {
      try {
         int result = Integer.parseInt((String)this.port.getValue());
         return result;
      } catch (NumberFormatException var3) {
         return -1;
      }
   }

   public long getServerPing() {
      return this.serverPing;
   }
}
