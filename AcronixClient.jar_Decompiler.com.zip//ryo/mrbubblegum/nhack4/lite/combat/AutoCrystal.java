package ryo.mrbubblegum.nhack4.lite.combat;

import com.mojang.authlib.GameProfile;
import io.netty.util.internal.ConcurrentSet;
import java.awt.Color;
import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import ryo.mrbubblegum.nhack4.impl.gui.LiteGui;
import ryo.mrbubblegum.nhack4.impl.util.BlockUtil;
import ryo.mrbubblegum.nhack4.impl.util.ColorUtil;
import ryo.mrbubblegum.nhack4.impl.util.DamageUtil;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.misc.NoSoundLag;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Bind;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;
import ryo.mrbubblegum.nhack4.world.events.Render3DEvent;
import ryo.mrbubblegum.nhack4.world.events.UpdateWalkingPlayerEvent;

public class AutoCrystal extends Module {
   public static EntityPlayer target;
   public static Set<BlockPos> lowDmgPos = new ConcurrentSet();
   public static Set<BlockPos> placedPos = new HashSet();
   public static Set<BlockPos> brokenPos = new HashSet();
   private static AutoCrystal instance;
   public final Timer yawStepTimer = new Timer();
   private final Timer switchTimer = new Timer();
   private final Timer manualTimer = new Timer();
   private final Timer breakTimer = new Timer();
   private final Timer placeTimer = new Timer();
   private final Timer syncTimer = new Timer();
   private final Timer predictTimer = new Timer();
   private final Timer renderTimer = new Timer();
   private final AtomicBoolean shouldInterrupt = new AtomicBoolean(false);
   private final Timer syncroTimer = new Timer();
   private final Map<EntityPlayer, Timer> totemPops = new ConcurrentHashMap();
   private final Queue<CPacketUseEntity> packetUseEntities = new LinkedList();
   private final AtomicBoolean threadOngoing = new AtomicBoolean(false);
   private final List<AutoCrystal.RenderPos> positions = new ArrayList();
   private final Setting<AutoCrystal.Settings> setting;
   public final Setting<Boolean> attackOppositeHand;
   public final Setting<Boolean> removeAfterAttack;
   public final Setting<Boolean> antiBlock;
   private final Setting<Integer> eventMode;
   private final Setting<Integer> switchCooldown;
   public Setting<Boolean> place;
   public Setting<Integer> placeDelay;
   public Setting<Float> placeRange;
   public Setting<Float> minDamage;
   public Setting<Float> maxSelfPlace;
   public Setting<Integer> wasteAmount;
   public Setting<Boolean> wasteMinDmgCount;
   public Setting<Float> facePlace;
   public Setting<Boolean> antiSurround;
   public Setting<Boolean> limitFacePlace;
   public Setting<Boolean> oneDot15;
   public Setting<Boolean> doublePop;
   public Setting<Double> popHealth;
   public Setting<Float> popDamage;
   public Setting<Integer> popTime;
   public Setting<Float> minMinDmg;
   public Setting<Boolean> explode;
   public Setting<AutoCrystal.Switch> switchMode;
   public Setting<Integer> breakDelay;
   public Setting<AutoCrystal.AntiWeaknessMode> antiWeakness;
   public Setting<Float> breakRange;
   public Setting<Integer> packets;
   public Setting<Float> maxSelfBreak;
   public Setting<Boolean> instant;
   public Setting<AutoCrystal.PredictTimer> instantTimer;
   public Setting<Integer> predictDelay;
   public Setting<Boolean> resetBreakTimer;
   public Setting<Boolean> predictCalc;
   public Setting<Boolean> superSafe;
   public Setting<Boolean> antiCommit;
   public Setting<Boolean> manual;
   public Setting<Boolean> manualMinDmg;
   public Setting<Integer> manualBreak;
   public Setting<Boolean> sync;
   public Setting<Boolean> render;
   public Setting<Boolean> justRender;
   public Setting<Boolean> fakeSwing;
   public Setting<AutoCrystal.RenderMode> renderMode;
   public final Setting<Float> rainbowBrightness;
   public final Setting<Float> rainbowSaturation;
   private final Setting<Boolean> fadeFactor;
   private final Setting<Boolean> scaleFactor;
   private final Setting<Boolean> slabFactor;
   private final Setting<Boolean> onlyplaced;
   private final Setting<Float> duration;
   private final Setting<Integer> max;
   private final Setting<Float> slabHeight;
   private final Setting<Float> moveSpeed;
   private final Setting<Float> accel;
   public Setting<Boolean> colorSync;
   public Setting<Boolean> box;
   private final Setting<Integer> bRed;
   private final Setting<Integer> bGreen;
   private final Setting<Integer> bBlue;
   private final Setting<Integer> bAlpha;
   public Setting<Boolean> outline;
   private final Setting<Integer> oRed;
   private final Setting<Integer> oGreen;
   private final Setting<Integer> oBlue;
   private final Setting<Integer> oAlpha;
   private final Setting<Float> lineWidth;
   public Setting<Boolean> text;
   public Setting<Boolean> holdFacePlace;
   public Setting<Boolean> holdFaceBreak;
   public Setting<Boolean> slowFaceBreak;
   public Setting<Boolean> actualSlowBreak;
   public Setting<Integer> facePlaceSpeed;
   public Setting<Boolean> antiNaked;
   public Setting<AutoCrystal.Timing> timing;
   public Setting<Float> range;
   public Setting<AutoCrystal.Target> targetMode;
   public Setting<Boolean> doublePopOnDamage;
   public Setting<Boolean> webAttack;
   public Setting<Integer> minArmor;
   public Setting<AutoCrystal.AutoSwitch> autoSwitch;
   public Setting<Bind> switchBind;
   public Setting<Boolean> offhandSwitch;
   public Setting<Boolean> switchBack;
   public Setting<Boolean> lethalSwitch;
   public Setting<Boolean> mineSwitch;
   public Setting<AutoCrystal.Rotate> rotate;
   public Setting<Boolean> YawStep;
   public Setting<Integer> YawStepVal;
   public Setting<Integer> YawStepTicks;
   public Setting<Boolean> YawStepDebugMessages;
   public Setting<Boolean> rotateFirst;
   public Setting<Boolean> suicide;
   public Setting<Boolean> fullCalc;
   public Setting<Boolean> sound;
   public Setting<Float> soundRange;
   public Setting<Float> soundPlayer;
   public Setting<Boolean> soundConfirm;
   public Setting<Boolean> extraSelfCalc;
   public Setting<AutoCrystal.AntiFriendPop> antiFriendPop;
   public Setting<Boolean> noCount;
   public Setting<Boolean> calcEvenIfNoDamage;
   public Setting<Boolean> predictFriendDmg;
   public Setting<AutoCrystal.Raytrace> raytrace;
   public Setting<Float> placetrace;
   public Setting<Float> breaktrace;
   public Setting<Boolean> breakSwing;
   public Setting<Boolean> placeSwing;
   public Setting<Boolean> exactHand;
   public Setting<AutoCrystal.Logic> logic;
   public Setting<AutoCrystal.DamageSync> damageSync;
   public Setting<Integer> damageSyncTime;
   public Setting<Float> dropOff;
   public Setting<Integer> confirm;
   public Setting<Boolean> syncedFeetPlace;
   public Setting<Boolean> fullSync;
   public Setting<Boolean> syncCount;
   public Setting<Boolean> hyperSync;
   public Setting<Boolean> gigaSync;
   public Setting<Boolean> syncySync;
   public Setting<Boolean> enormousSync;
   public Setting<Boolean> holySync;
   public Setting<AutoCrystal.ThreadMode> threadMode;
   public Setting<Integer> threadDelay;
   public Setting<Boolean> syncThreadBool;
   public Setting<Integer> syncThreads;
   public Setting<Boolean> predictPos;
   public Setting<Integer> predictTicks;
   public Setting<Integer> rotations;
   public Setting<Boolean> predictRotate;
   public Setting<Float> predictOffset;
   public boolean rotating;
   private Queue<Entity> attackList;
   private Map<Entity, Float> crystalMap;
   private Entity efficientTarget;
   private double currentDamage;
   private double renderDamage;
   private double lastDamage;
   private boolean didRotation;
   private boolean switching;
   private BlockPos placePos;
   private BlockPos renderPos;
   private boolean mainHand;
   private boolean offHand;
   private int crystalCount;
   private int minDmgCount;
   private int lastSlot;
   private float yaw;
   private float pitch;
   private BlockPos webPos;
   private BlockPos lastPos;
   private boolean posConfirmed;
   private boolean foundDoublePop;
   private int rotationPacketsSpoofed;
   private ScheduledExecutorService executor;
   private Thread thread;
   private EntityPlayer currentSyncTarget;
   private BlockPos syncedPlayerPos;
   private BlockPos syncedCrystalPos;
   private AutoCrystal.PlaceInfo placeInfo;
   private boolean addTolowDmg;
   private boolean shouldSilent;
   private BlockPos lastRenderPos;
   private AxisAlignedBB renderBB;
   private float timePassed;

   public AutoCrystal() {
      super("AutoCrystal", "places crystals nerd", Module.Category.COMBAT, true, false, false);
      this.setting = this.register(new Setting("Settings", AutoCrystal.Settings.PLACE));
      this.attackOppositeHand = this.register(new Setting("OppositeHand", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.removeAfterAttack = this.register(new Setting("AttackRemove", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.antiBlock = this.register(new Setting("AntiFeetPlace", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.eventMode = this.register(new Setting("Updates", 3, 1, 3, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.switchCooldown = this.register(new Setting("Cooldown", 500, 0, 1000, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.place = this.register(new Setting("Place", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE;
      }));
      this.placeDelay = this.register(new Setting("PlaceDelay", 25, 0, 500, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.placeRange = this.register(new Setting("PlaceRange", 6.0F, 0.0F, 10.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.minDamage = this.register(new Setting("MinDamage", 7.0F, 0.1F, 20.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.maxSelfPlace = this.register(new Setting("MaxSelfPlace", 5.0F, 0.1F, 36.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.wasteAmount = this.register(new Setting("WasteAmount", 2, 1, 5, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.wasteMinDmgCount = this.register(new Setting("CountMinDmg", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.facePlace = this.register(new Setting("FacePlace", 10.0F, 0.1F, 36.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.antiSurround = this.register(new Setting("AntiSurround", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.limitFacePlace = this.register(new Setting("LimitFacePlace", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.oneDot15 = this.register(new Setting("1.15", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.doublePop = this.register(new Setting("AntiTotem", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue();
      }));
      this.popHealth = this.register(new Setting("PopHealth", 1.0D, 0.0D, 3.0D, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue() && (Boolean)this.doublePop.getValue();
      }));
      this.popDamage = this.register(new Setting("PopDamage", 4.0F, 0.0F, 6.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue() && (Boolean)this.doublePop.getValue();
      }));
      this.popTime = this.register(new Setting("PopTime", 500, 0, 1000, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue() && (Boolean)this.doublePop.getValue();
      }));
      this.minMinDmg = this.register(new Setting("MinMinDmg", 0.0F, 0.0F, 3.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && (Boolean)this.place.getValue();
      }));
      this.explode = this.register(new Setting("Break", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK;
      }));
      this.switchMode = this.register(new Setting("Attack", AutoCrystal.Switch.BREAKSLOT, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue();
      }));
      this.breakDelay = this.register(new Setting("BreakDelay", 50, 0, 500, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue();
      }));
      this.antiWeakness = this.register(new Setting("Anti Weakness", AutoCrystal.AntiWeaknessMode.Silent, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue();
      }));
      this.breakRange = this.register(new Setting("BreakRange", 6.0F, 0.0F, 10.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue();
      }));
      this.packets = this.register(new Setting("Packets", 1, 1, 6, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue();
      }));
      this.maxSelfBreak = this.register(new Setting("MaxSelfBreak", 10.0F, 0.1F, 36.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue();
      }));
      this.instant = this.register(new Setting("Predict", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue();
      }));
      this.instantTimer = this.register(new Setting("PredictTimer", AutoCrystal.PredictTimer.NONE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue() && (Boolean)this.instant.getValue();
      }));
      this.predictDelay = this.register(new Setting("PredictDelay", 12, 0, 500, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue() && (Boolean)this.instant.getValue() && this.instantTimer.getValue() == AutoCrystal.PredictTimer.PREDICT;
      }));
      this.resetBreakTimer = this.register(new Setting("ResetBreakTimer", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue() && (Boolean)this.instant.getValue();
      }));
      this.predictCalc = this.register(new Setting("PredictCalc", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue() && (Boolean)this.instant.getValue();
      }));
      this.superSafe = this.register(new Setting("SuperSafe", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue() && (Boolean)this.instant.getValue();
      }));
      this.antiCommit = this.register(new Setting("AntiOverCommit", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && (Boolean)this.place.getValue() && (Boolean)this.instant.getValue();
      }));
      this.manual = this.register(new Setting("Manual", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK;
      }));
      this.manualMinDmg = this.register(new Setting("ManMinDmg", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.manual.getValue();
      }));
      this.manualBreak = this.register(new Setting("ManualDelay", 500, 0, 500, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.manual.getValue();
      }));
      this.sync = this.register(new Setting("Sync", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && ((Boolean)this.explode.getValue() || (Boolean)this.manual.getValue());
      }));
      this.render = this.register(new Setting("Render", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER;
      }));
      this.justRender = this.register(new Setting("JustRender", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue();
      }));
      this.fakeSwing = this.register(new Setting("FakeSwing", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && (Boolean)this.justRender.getValue();
      }));
      this.renderMode = this.register(new Setting("Mode", AutoCrystal.RenderMode.STATIC, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue();
      }));
      this.rainbowBrightness = this.register(new Setting("Brightness", 150.0F, 1.0F, 255.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.GRADIENTRAINBOW;
      }));
      this.rainbowSaturation = this.register(new Setting("Saturation", 150.0F, 1.0F, 255.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.GRADIENTRAINBOW;
      }));
      this.fadeFactor = this.register(new Setting("Fade", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.FADE && (Boolean)this.render.getValue();
      }));
      this.scaleFactor = this.register(new Setting("Shrink", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.FADE && (Boolean)this.render.getValue();
      }));
      this.slabFactor = this.register(new Setting("Slab", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.FADE && (Boolean)this.render.getValue();
      }));
      this.onlyplaced = this.register(new Setting("OnlyPlaced", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.FADE && (Boolean)this.render.getValue();
      }));
      this.duration = this.register(new Setting("Duration", 1500.0F, 0.0F, 5000.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.FADE && (Boolean)this.render.getValue();
      }));
      this.max = this.register(new Setting("MaxPositions", 15, 1, 30, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.FADE && (Boolean)this.render.getValue();
      }));
      this.slabHeight = this.register(new Setting("SlabDepth", 1.0F, 0.1F, 1.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (this.renderMode.getValue() == AutoCrystal.RenderMode.STATIC || this.renderMode.getValue() == AutoCrystal.RenderMode.GLIDE) && (Boolean)this.render.getValue();
      }));
      this.moveSpeed = this.register(new Setting("Speed", 900.0F, 0.0F, 1500.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.GLIDE && (Boolean)this.render.getValue();
      }));
      this.accel = this.register(new Setting("Deceleration", 0.8F, 0.0F, 1.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && this.renderMode.getValue() == AutoCrystal.RenderMode.GLIDE && (Boolean)this.render.getValue();
      }));
      this.colorSync = this.register(new Setting("CSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue();
      }));
      this.box = this.register(new Setting("Box", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue();
      }));
      this.bRed = this.register(new Setting("BoxRed", 125, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.box.getValue();
      }));
      this.bGreen = this.register(new Setting("BoxGreen", 125, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.box.getValue();
      }));
      this.bBlue = this.register(new Setting("BoxBlue", 255, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.box.getValue();
      }));
      this.bAlpha = this.register(new Setting("BoxAlpha", 40, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.box.getValue();
      }));
      this.outline = this.register(new Setting("Outline", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue();
      }));
      this.oRed = this.register(new Setting("OutlineRed", 125, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.outline.getValue();
      }));
      this.oGreen = this.register(new Setting("OutlineGreen", 125, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.outline.getValue();
      }));
      this.oBlue = this.register(new Setting("OutlineBlue", 255, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.outline.getValue();
      }));
      this.oAlpha = this.register(new Setting("OutlineAlpha", 255, 0, 255, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.outline.getValue();
      }));
      this.lineWidth = this.register(new Setting("LineWidth", 1.5F, 0.1F, 5.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue() && (Boolean)this.outline.getValue();
      }));
      this.text = this.register(new Setting("Text", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.RENDER && (Boolean)this.render.getValue();
      }));
      this.holdFacePlace = this.register(new Setting("HoldFacePlace", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.holdFaceBreak = this.register(new Setting("HoldSlowBreak", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && (Boolean)this.holdFacePlace.getValue();
      }));
      this.slowFaceBreak = this.register(new Setting("SlowFaceBreak", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.actualSlowBreak = this.register(new Setting("ActuallySlow", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.facePlaceSpeed = this.register(new Setting("FaceSpeed", 500, 0, 500, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.antiNaked = this.register(new Setting("AntiNaked", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.timing = this.register(new Setting("Timing", AutoCrystal.Timing.Sequential, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.range = this.register(new Setting("Range", 12.0F, 0.1F, 20.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.targetMode = this.register(new Setting("Target", AutoCrystal.Target.CLOSEST, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.doublePopOnDamage = this.register(new Setting("DamagePop", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue() && (Boolean)this.doublePop.getValue() && this.targetMode.getValue() == AutoCrystal.Target.DAMAGE;
      }));
      this.webAttack = this.register(new Setting("WebAttack", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.targetMode.getValue() != AutoCrystal.Target.DAMAGE;
      }));
      this.minArmor = this.register(new Setting("MinArmor", 5, 0, 125, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.autoSwitch = this.register(new Setting("Switch", AutoCrystal.AutoSwitch.TOGGLE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.switchBind = this.register(new Setting("SwitchBind", new Bind(-1), (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.autoSwitch.getValue() == AutoCrystal.AutoSwitch.TOGGLE;
      }));
      this.offhandSwitch = this.register(new Setting("Offhand", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.NONE && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.SILENT;
      }));
      this.switchBack = this.register(new Setting("Switchback", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.NONE && (Boolean)this.offhandSwitch.getValue() && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.SILENT;
      }));
      this.lethalSwitch = this.register(new Setting("LethalSwitch", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.NONE && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.SILENT;
      }));
      this.mineSwitch = this.register(new Setting("MineSwitch", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.NONE && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.SILENT;
      }));
      this.rotate = this.register(new Setting("Rotate", AutoCrystal.Rotate.OFF, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.YawStep = this.register(new Setting("YawStep", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.rotate.getValue() != AutoCrystal.Rotate.OFF;
      }));
      this.YawStepVal = this.register(new Setting("YawStepValue", 45, 0, 180, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.rotate.getValue() != AutoCrystal.Rotate.OFF && (Boolean)this.YawStep.getValue();
      }));
      this.YawStepTicks = this.register(new Setting("YawStepTicks", 1, 1, 20, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.rotate.getValue() != AutoCrystal.Rotate.OFF && (Boolean)this.YawStep.getValue();
      }));
      this.YawStepDebugMessages = this.register(new Setting("YawStep Debug", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && this.rotate.getValue() != AutoCrystal.Rotate.OFF && (Boolean)this.YawStep.getValue();
      }));
      this.rotateFirst = this.register(new Setting("FirstRotation", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.rotate.getValue() != AutoCrystal.Rotate.OFF && (Integer)this.eventMode.getValue() == 2;
      }));
      this.suicide = this.register(new Setting("SelfDMG", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.fullCalc = this.register(new Setting("ExtraCalc", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.sound = this.register(new Setting("Sound", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.soundRange = this.register(new Setting("SoundRange", 12.0F, 0.0F, 12.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.soundPlayer = this.register(new Setting("SoundPlayer", 6.0F, 0.0F, 12.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.soundConfirm = this.register(new Setting("SoundConfirm", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.extraSelfCalc = this.register(new Setting("MinSelfDmg", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.antiFriendPop = this.register(new Setting("AntiFriendPop", AutoCrystal.AntiFriendPop.NONE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.noCount = this.register(new Setting("AntiCount", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && (this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.ALL || this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.BREAK);
      }));
      this.calcEvenIfNoDamage = this.register(new Setting("BigFriendCalc", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && (this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.ALL || this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.BREAK) && this.targetMode.getValue() != AutoCrystal.Target.DAMAGE;
      }));
      this.predictFriendDmg = this.register(new Setting("PredictFriend", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC && (this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.ALL || this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.BREAK) && (Boolean)this.instant.getValue();
      }));
      this.raytrace = this.register(new Setting("Raytrace", AutoCrystal.Raytrace.NONE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.MISC;
      }));
      this.placetrace = this.register(new Setting("Placetrace", 4.5F, 0.0F, 10.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.PLACE && (Boolean)this.place.getValue() && this.raytrace.getValue() != AutoCrystal.Raytrace.NONE && this.raytrace.getValue() != AutoCrystal.Raytrace.BREAK;
      }));
      this.breaktrace = this.register(new Setting("Breaktrace", 4.5F, 0.0F, 10.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.BREAK && (Boolean)this.explode.getValue() && this.raytrace.getValue() != AutoCrystal.Raytrace.NONE && this.raytrace.getValue() != AutoCrystal.Raytrace.PLACE;
      }));
      this.breakSwing = this.register(new Setting("BreakSwing", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.placeSwing = this.register(new Setting("PlaceSwing", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.exactHand = this.register(new Setting("ExactHand", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && (Boolean)this.placeSwing.getValue();
      }));
      this.logic = this.register(new Setting("Logic", AutoCrystal.Logic.BREAKPLACE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.damageSync = this.register(new Setting("DamageSync", AutoCrystal.DamageSync.NONE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.damageSyncTime = this.register(new Setting("SyncDelay", 500, 0, 500, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE;
      }));
      this.dropOff = this.register(new Setting("DropOff", 5.0F, 0.0F, 10.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() == AutoCrystal.DamageSync.BREAK;
      }));
      this.confirm = this.register(new Setting("Confirm", 0, 0, 1000, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE;
      }));
      this.syncedFeetPlace = this.register(new Setting("FeetSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE;
      }));
      this.fullSync = this.register(new Setting("FullSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.syncCount = this.register(new Setting("SyncCount", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.hyperSync = this.register(new Setting("HyperSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.gigaSync = this.register(new Setting("GigaSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.syncySync = this.register(new Setting("SyncySync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.enormousSync = this.register(new Setting("EnormousSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.holySync = this.register(new Setting("UnbelievableSync", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && (Boolean)this.syncedFeetPlace.getValue();
      }));
      this.threadMode = this.register(new Setting("Thread", AutoCrystal.ThreadMode.NONE, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.threadDelay = this.register(new Setting("ThreadDelay", 50, 1, 1000, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE;
      }));
      this.syncThreadBool = this.register(new Setting("ThreadSync", true, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE;
      }));
      this.syncThreads = this.register(new Setting("SyncThreads", 1000, 1, 10000, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE && (Boolean)this.syncThreadBool.getValue();
      }));
      this.predictPos = this.register(new Setting("PredictPos", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.predictTicks = this.register(new Setting("ExtrapolationTicks", 2, 1, 20, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV && (Boolean)this.predictPos.getValue();
      }));
      this.rotations = this.register(new Setting("Spoofs", 1, 1, 20, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.predictRotate = this.register(new Setting("PredictRotate", false, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.predictOffset = this.register(new Setting("PredictOffset", 0.0F, 0.0F, 4.0F, (v) -> {
         return this.setting.getValue() == AutoCrystal.Settings.DEV;
      }));
      this.attackList = new ConcurrentLinkedQueue();
      this.crystalMap = new HashMap();
      this.lastSlot = -1;
      instance = this;
   }

   public static AutoCrystal getInstance() {
      if (instance == null) {
         instance = new AutoCrystal();
      }

      return instance;
   }

   public void onTick() {
      if (this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE && (Integer)this.eventMode.getValue() == 3) {
         this.doAutoCrystal();
      }

   }

   @SubscribeEvent
   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
      if (event.getStage() == 1) {
         this.postProcessing();
      }

      if (event.getStage() == 0) {
         if ((Integer)this.eventMode.getValue() == 2) {
            this.doAutoCrystal();
         }

      }
   }

   public void postTick() {
      if (this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE) {
         this.processMultiThreading();
      }

   }

   public void onUpdate() {
      if (this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE && (Integer)this.eventMode.getValue() == 1) {
         this.doAutoCrystal();
      }

   }

   public void onToggle() {
      brokenPos.clear();
      placedPos.clear();
      this.totemPops.clear();
      this.rotating = false;
   }

   public void onDisable() {
      this.positions.clear();
      this.lastRenderPos = null;
      if (this.thread != null) {
         this.shouldInterrupt.set(true);
      }

      if (this.executor != null) {
         this.executor.shutdown();
      }

   }

   public void onEnable() {
      if (this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE) {
         this.processMultiThreading();
      }

   }

   public String getDisplayInfo() {
      if (this.switching) {
         return "§aSwitch";
      } else {
         return target != null ? target.func_70005_c_() : null;
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (event.getStage() == 0 && this.rotate.getValue() != AutoCrystal.Rotate.OFF && this.rotating && (Integer)this.eventMode.getValue() != 2 && event.getPacket() instanceof CPacketPlayer) {
         CPacketPlayer packet2 = (CPacketPlayer)event.getPacket();
         packet2.field_149476_e = this.yaw;
         packet2.field_149473_f = this.pitch;
         ++this.rotationPacketsSpoofed;
         if (this.rotationPacketsSpoofed >= (Integer)this.rotations.getValue()) {
            this.rotating = false;
            this.rotationPacketsSpoofed = 0;
         }
      }

      BlockPos pos = null;
      CPacketUseEntity packet;
      if (event.getStage() == 0 && event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == Action.ATTACK && packet.func_149564_a(mc.field_71441_e) instanceof EntityEnderCrystal) {
         pos = ((Entity)Objects.requireNonNull(packet.func_149564_a(mc.field_71441_e))).func_180425_c();
         if ((Boolean)this.removeAfterAttack.getValue()) {
            ((Entity)Objects.requireNonNull(packet.func_149564_a(mc.field_71441_e))).func_70106_y();
            mc.field_71441_e.func_73028_b(packet.field_149567_a);
         }
      }

      if (event.getStage() == 0 && event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == Action.ATTACK && packet.func_149564_a(mc.field_71441_e) instanceof EntityEnderCrystal) {
         EntityEnderCrystal crystal = (EntityEnderCrystal)packet.func_149564_a(mc.field_71441_e);
         if ((Boolean)this.antiBlock.getValue() && EntityUtil.isCrystalAtFeet(crystal, (double)(Float)this.range.getValue()) && pos != null) {
            this.rotateToPos(pos);
            BlockUtil.placeCrystalOnBlock(this.placePos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, (Boolean)this.placeSwing.getValue(), (Boolean)this.exactHand.getValue(), this.shouldSilent);
         }
      }

   }

   @SubscribeEvent(
      priority = EventPriority.HIGH,
      receiveCanceled = true
   )
   public void onSoundPacket(PacketEvent.Receive event) {
      if (!fullNullCheck()) {
         SPacketSoundEffect packet2;
         if (event.getPacket() instanceof SPacketSoundEffect && this.timing.getValue() == AutoCrystal.Timing.Sequential && (packet2 = (SPacketSoundEffect)event.getPacket()).func_186977_b() == SoundCategory.BLOCKS && packet2.func_186978_a() == SoundEvents.field_187539_bB) {
            ArrayList entities = new ArrayList(mc.field_71441_e.field_72996_f);
            int size = entities.size();

            for(int i = 0; i < size; ++i) {
               Entity entity = (Entity)entities.get(i);
               if (entity instanceof EntityEnderCrystal && entity.func_70092_e(packet2.func_149207_d(), packet2.func_149211_e(), packet2.func_149210_f()) < 36.0D) {
                  entity.func_70106_y();
               }
            }
         }

      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH,
      receiveCanceled = true
   )
   public void onPacketReceive(PacketEvent.Receive event) {
      if (!fullNullCheck()) {
         BlockPos pos;
         if ((Boolean)this.justRender.getValue() || !this.switchTimer.passedMs((long)(Integer)this.switchCooldown.getValue()) || !(Boolean)this.explode.getValue() || !(Boolean)this.instant.getValue() || !(event.getPacket() instanceof SPacketSpawnObject) || this.syncedCrystalPos != null && (Boolean)this.syncedFeetPlace.getValue() && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE) {
            if (!(Boolean)this.soundConfirm.getValue() && event.getPacket() instanceof SPacketExplosion) {
               SPacketExplosion packet3 = (SPacketExplosion)event.getPacket();
               BlockPos pos = (new BlockPos(packet3.func_149148_f(), packet3.func_149143_g(), packet3.func_149145_h())).func_177977_b();
               this.removePos(pos);
            } else if (event.getPacket() instanceof SPacketDestroyEntities) {
               SPacketDestroyEntities packet4 = (SPacketDestroyEntities)event.getPacket();
               int[] var12 = packet4.func_149098_c();
               int var16 = var12.length;

               for(int var17 = 0; var17 < var16; ++var17) {
                  int id = var12[var17];
                  Entity entity = mc.field_71441_e.func_73045_a(id);
                  if (entity instanceof EntityEnderCrystal) {
                     brokenPos.remove((new BlockPos(entity.func_174791_d())).func_177977_b());
                     placedPos.remove((new BlockPos(entity.func_174791_d())).func_177977_b());
                  }
               }
            } else if (event.getPacket() instanceof SPacketEntityStatus) {
               SPacketEntityStatus packet5 = (SPacketEntityStatus)event.getPacket();
               if (packet5.func_149160_c() == 35 && packet5.func_149161_a(mc.field_71441_e) instanceof EntityPlayer) {
                  this.totemPops.put((EntityPlayer)packet5.func_149161_a(mc.field_71441_e), (new Timer()).reset());
               }
            } else {
               SPacketSoundEffect packet;
               if (event.getPacket() instanceof SPacketSoundEffect && (packet = (SPacketSoundEffect)event.getPacket()).func_186977_b() == SoundCategory.BLOCKS && packet.func_186978_a() == SoundEvents.field_187539_bB) {
                  pos = new BlockPos(packet.func_149207_d(), packet.func_149211_e(), packet.func_149210_f());
                  if ((Boolean)this.sound.getValue() || this.threadMode.getValue() == AutoCrystal.ThreadMode.SOUND) {
                     if (fullNullCheck()) {
                        return;
                     }

                     NoSoundLag.removeEntities(packet, (Float)this.soundRange.getValue());
                  }

                  if ((Boolean)this.soundConfirm.getValue()) {
                     this.removePos(pos);
                  }

                  if (this.threadMode.getValue() == AutoCrystal.ThreadMode.SOUND && this.isRightThread() && mc.field_71439_g != null && mc.field_71439_g.func_174818_b(pos) < MathUtil.square((Float)this.soundPlayer.getValue())) {
                     this.handlePool(true);
                  }
               }
            }
         } else {
            SPacketSpawnObject packet2 = (SPacketSpawnObject)event.getPacket();
            if (packet2.func_148993_l() == 51 && mc.field_71439_g.func_174818_b(pos = new BlockPos(packet2.func_186880_c(), packet2.func_186882_d(), packet2.func_186881_e())) + (double)(Float)this.predictOffset.getValue() <= MathUtil.square((Float)this.breakRange.getValue()) && (this.instantTimer.getValue() == AutoCrystal.PredictTimer.NONE || this.instantTimer.getValue() == AutoCrystal.PredictTimer.BREAK && this.breakTimer.passedMs((long)(Integer)this.breakDelay.getValue()) || this.instantTimer.getValue() == AutoCrystal.PredictTimer.PREDICT && this.predictTimer.passedMs((long)(Integer)this.predictDelay.getValue()))) {
               if (this.predictSlowBreak(pos.func_177977_b())) {
                  return;
               }

               if ((Boolean)this.predictFriendDmg.getValue() && (this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.BREAK || this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.ALL) && this.isRightThread()) {
                  Iterator var5 = mc.field_71441_e.field_73010_i.iterator();

                  while(var5.hasNext()) {
                     EntityPlayer friend = (EntityPlayer)var5.next();
                     if (friend != null && !mc.field_71439_g.equals(friend) && !(friend.func_174818_b(pos) > MathUtil.square((Float)this.range.getValue() + (Float)this.placeRange.getValue())) && Loader.friendManager.isFriend(friend) && (double)DamageUtil.calculateDamage((BlockPos)pos, friend) > (double)EntityUtil.getHealth(friend) + 0.5D) {
                        return;
                     }
                  }
               }

               float selfDamage;
               if (!placedPos.contains(pos.func_177977_b())) {
                  if ((Boolean)this.predictCalc.getValue() && this.isRightThread()) {
                     selfDamage = -1.0F;
                     if (DamageUtil.canTakeDamage((Boolean)this.suicide.getValue())) {
                        selfDamage = DamageUtil.calculateDamage((BlockPos)pos, mc.field_71439_g);
                     }

                     if ((double)selfDamage + 0.5D < (double)EntityUtil.getHealth(mc.field_71439_g) && selfDamage <= (Float)this.maxSelfBreak.getValue()) {
                        Iterator var15 = mc.field_71441_e.field_73010_i.iterator();

                        EntityPlayer player;
                        float damage;
                        do {
                           do {
                              do {
                                 do {
                                    if (!var15.hasNext()) {
                                       return;
                                    }

                                    player = (EntityPlayer)var15.next();
                                 } while(!(player.func_174818_b(pos) <= MathUtil.square((Float)this.range.getValue())));
                              } while(!EntityUtil.isValid(player, (double)((Float)this.range.getValue() + (Float)this.breakRange.getValue())));
                           } while((Boolean)this.antiNaked.getValue() && DamageUtil.isNaked(player));
                        } while(!((damage = DamageUtil.calculateDamage((BlockPos)pos, player)) > selfDamage) && (!(damage > (Float)this.minDamage.getValue()) || DamageUtil.canTakeDamage((Boolean)this.suicide.getValue())) && !(damage > EntityUtil.getHealth(player)));

                        if ((Boolean)this.predictRotate.getValue() && (Integer)this.eventMode.getValue() != 2 && (this.rotate.getValue() == AutoCrystal.Rotate.BREAK || this.rotate.getValue() == AutoCrystal.Rotate.ALL)) {
                           this.rotateToPos(pos);
                        }

                        this.attackCrystalPredict(packet2.func_149001_c(), pos);
                     }
                  }
               } else {
                  if (this.isRightThread() && (Boolean)this.superSafe.getValue()) {
                     if (DamageUtil.canTakeDamage((Boolean)this.suicide.getValue()) && ((double)(selfDamage = DamageUtil.calculateDamage((BlockPos)pos, mc.field_71439_g)) - 0.5D > (double)EntityUtil.getHealth(mc.field_71439_g) || selfDamage > (Float)this.maxSelfBreak.getValue())) {
                        return;
                     }
                  } else if ((Boolean)this.superSafe.getValue()) {
                     return;
                  }

                  this.attackCrystalPredict(packet2.func_149001_c(), pos);
                  return;
               }
            }
         }

      }
   }

   private boolean predictSlowBreak(BlockPos pos) {
      return (Boolean)this.antiCommit.getValue() && lowDmgPos.remove(pos) ? this.shouldSlowBreak(false) : false;
   }

   private boolean isRightThread() {
      return Util.mc.func_152345_ab() || !Loader.eventManager.ticksOngoing() && !this.threadOngoing.get();
   }

   private void attackCrystalPredict(int entityID, BlockPos pos) {
      if ((Boolean)this.predictRotate.getValue() && ((Integer)this.eventMode.getValue() != 2 || this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE) && (this.rotate.getValue() == AutoCrystal.Rotate.BREAK || this.rotate.getValue() == AutoCrystal.Rotate.ALL)) {
         this.rotateToPos(pos);
      }

      CPacketUseEntity attackPacket = new CPacketUseEntity();
      attackPacket.field_149567_a = entityID;
      attackPacket.field_149566_b = Action.ATTACK;
      mc.field_71439_g.field_71174_a.func_147297_a(attackPacket);
      if ((Boolean)this.breakSwing.getValue()) {
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketAnimation(EnumHand.MAIN_HAND));
      }

      if ((Boolean)this.resetBreakTimer.getValue()) {
         this.breakTimer.reset();
      }

      this.predictTimer.reset();
   }

   private void removePos(BlockPos pos) {
      if (this.damageSync.getValue() == AutoCrystal.DamageSync.PLACE) {
         if (placedPos.remove(pos)) {
            this.posConfirmed = true;
         }
      } else if (this.damageSync.getValue() == AutoCrystal.DamageSync.BREAK && brokenPos.remove(pos)) {
         this.posConfirmed = true;
      }

   }

   public void onRender3D(Render3DEvent event) {
      if ((Boolean)this.render.getValue()) {
         Color boxC = new Color((Integer)this.bRed.getValue(), (Integer)this.bGreen.getValue(), (Integer)this.bBlue.getValue(), (Integer)this.bAlpha.getValue());
         Color outlineC = new Color((Integer)this.oRed.getValue(), (Integer)this.oGreen.getValue(), (Integer)this.oBlue.getValue(), (Integer)this.oAlpha.getValue());
         if ((this.offHand || this.mainHand || this.switchMode.getValue() == AutoCrystal.Switch.CALC) && this.renderPos != null && ((Boolean)this.box.getValue() || (Boolean)this.outline.getValue())) {
            if (this.renderMode.getValue() == AutoCrystal.RenderMode.FADE) {
               this.positions.removeIf((pos) -> {
                  return pos.getPos().equals(this.renderPos);
               });
               this.positions.add(new AutoCrystal.RenderPos(this.renderPos, 0.0F));
            }

            if (this.renderMode.getValue() == AutoCrystal.RenderMode.STATIC) {
               RenderUtil.drawSexyBox(new AxisAlignedBB(this.renderPos), boxC, outlineC, (Float)this.lineWidth.getValue(), (Boolean)this.outline.getValue(), (Boolean)this.box.getValue(), (Boolean)this.colorSync.getValue(), 1.0F, 1.0F, (Float)this.slabHeight.getValue());
            }

            if (this.renderMode.getValue() == AutoCrystal.RenderMode.GRADIENTRAINBOW) {
               AxisAlignedBB axisAlignedBB = mc.field_71441_e.func_180495_p(this.renderPos).func_185918_c(mc.field_71441_e, this.renderPos);
               Vec3d vec3d = EntityUtil.interpolateEntity(RenderUtil.mc.field_71439_g, Util.mc.func_184121_ak());
               EnumFacing[] var6 = EnumFacing.values();
               int var7 = var6.length;

               for(int var8 = 0; var8 < var7; ++var8) {
                  EnumFacing enumFacing = var6[var8];
                  RenderUtil.drawGradientPlaneBB(axisAlignedBB.func_186662_g(0.0020000000949949026D).func_72317_d(-vec3d.field_72450_a, -vec3d.field_72448_b, -vec3d.field_72449_c), enumFacing, new Color(ColorUtil.gradientRainbow(50).getRed(), ColorUtil.gradientRainbow(50).getGreen(), ColorUtil.gradientRainbow(50).getBlue(), 127), ColorUtil.invert(new Color(ColorUtil.gradientRainbow(50).getRed(), ColorUtil.gradientRainbow(50).getGreen(), ColorUtil.gradientRainbow(50).getBlue(), 127)), 2.0D);
               }

               RenderUtil.drawGradientBlockOutline(axisAlignedBB.func_186662_g(0.0020000000949949026D).func_72317_d(-vec3d.field_72450_a, -vec3d.field_72448_b, -vec3d.field_72449_c), ColorUtil.invert(new Color(ColorUtil.gradientRainbow(50).getRed(), ColorUtil.gradientRainbow(50).getGreen(), ColorUtil.gradientRainbow(50).getBlue(), 255)), new Color(ColorUtil.gradientRainbow(50).getRed(), ColorUtil.gradientRainbow(50).getGreen(), ColorUtil.gradientRainbow(50).getBlue(), 255), 2.0F);
            }

            if (this.renderMode.getValue() == AutoCrystal.RenderMode.GLIDE) {
               if (this.lastRenderPos == null || mc.field_71439_g.func_70011_f(this.renderBB.field_72340_a, this.renderBB.field_72338_b, this.renderBB.field_72339_c) > (double)(Float)this.range.getValue()) {
                  this.lastRenderPos = this.renderPos;
                  this.renderBB = new AxisAlignedBB(this.renderPos);
                  this.timePassed = 0.0F;
               }

               if (!this.lastRenderPos.equals(this.renderPos)) {
                  this.lastRenderPos = this.renderPos;
                  this.timePassed = 0.0F;
               }

               double xDiff = (double)this.renderPos.func_177958_n() - this.renderBB.field_72340_a;
               double yDiff = (double)this.renderPos.func_177956_o() - this.renderBB.field_72338_b;
               double zDiff = (double)this.renderPos.func_177952_p() - this.renderBB.field_72339_c;
               float multiplier = this.timePassed / (Float)this.moveSpeed.getValue() * (Float)this.accel.getValue();
               if (multiplier > 1.0F) {
                  multiplier = 1.0F;
               }

               this.renderBB = this.renderBB.func_72317_d(xDiff * (double)multiplier, yDiff * (double)multiplier, zDiff * (double)multiplier);
               RenderUtil.drawSexyBox(this.renderBB, boxC, outlineC, (Float)this.lineWidth.getValue(), (Boolean)this.outline.getValue(), (Boolean)this.box.getValue(), (Boolean)this.colorSync.getValue(), 1.0F, 1.0F, (Float)this.slabHeight.getValue());
               if ((Boolean)this.text.getValue()) {
                  RenderUtil.drawText(this.renderBB.func_72317_d(0.0D, (double)(1.0F - (Float)this.slabHeight.getValue() / 2.0F) - 0.4D, 0.0D), (Math.floor(this.renderDamage) == this.renderDamage ? (int)this.renderDamage : String.format("%.1f", this.renderDamage)) + "");
               }

               float var11 = this.timePassed = this.renderBB.equals(new AxisAlignedBB(this.renderPos)) ? 0.0F : (this.timePassed += 50.0F);
            }
         }

         if (this.renderMode.getValue() == AutoCrystal.RenderMode.FADE) {
            this.positions.forEach((pos) -> {
               float factor = ((Float)this.duration.getValue() - pos.getRenderTime()) / (Float)this.duration.getValue();
               RenderUtil.drawSexyBox(new AxisAlignedBB(pos.getPos()), boxC, outlineC, (Float)this.lineWidth.getValue(), (Boolean)this.outline.getValue(), (Boolean)this.box.getValue(), (Boolean)this.colorSync.getValue(), (Boolean)this.fadeFactor.getValue() ? factor : 1.0F, (Boolean)this.scaleFactor.getValue() ? factor : 1.0F, (Boolean)this.slabFactor.getValue() ? factor : 1.0F);
               pos.setRenderTime(pos.getRenderTime() + 50.0F);
            });
            this.positions.removeIf((pos) -> {
               return pos.getRenderTime() >= (Float)this.duration.getValue() || mc.field_71441_e.func_175623_d(pos.getPos()) || !mc.field_71441_e.func_175623_d(pos.getPos().func_177972_a(EnumFacing.UP));
            });
            if (this.positions.size() > (Integer)this.max.getValue()) {
               this.positions.remove(0);
            }
         }

         if ((this.offHand || this.mainHand || this.switchMode.getValue() == AutoCrystal.Switch.CALC) && this.renderPos != null && (Boolean)this.text.getValue() && this.renderMode.getValue() != AutoCrystal.RenderMode.GLIDE) {
            RenderUtil.drawText((new AxisAlignedBB(this.renderPos)).func_72317_d(0.0D, this.renderMode.getValue() != AutoCrystal.RenderMode.FADE ? (double)(1.0F - (Float)this.slabHeight.getValue() / 2.0F) - 0.4D : 0.1D, 0.0D), (Math.floor(this.renderDamage) == this.renderDamage ? (int)this.renderDamage : String.format("%.1f", this.renderDamage)) + "");
         }

      }
   }

   @SubscribeEvent
   public void onKeyInput(KeyInputEvent event) {
      if (Keyboard.getEventKeyState() && !(mc.field_71462_r instanceof LiteGui) && ((Bind)this.switchBind.getValue()).getKey() == Keyboard.getEventKey()) {
         if ((Boolean)this.switchBack.getValue() && (Boolean)this.offhandSwitch.getValue() && this.offHand) {
            Offhand module = (Offhand)Loader.moduleManager.getModuleByClass(Offhand.class);
            if (module.isOff()) {
               Command.sendMessage("<" + this.getDisplayName() + "> §cSwitch failed. Enable the Offhand module.");
            } else if (module.type.getValue() == Offhand.Type.NEW) {
               module.setSwapToTotem(true);
               module.doOffhand();
            } else {
               module.setMode(Offhand.Mode2.TOTEMS);
               module.doSwitch();
            }

            return;
         }

         this.switching = !this.switching;
      }

   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2 && event.getSetting() != null && event.getSetting().getFeature() != null && event.getSetting().getFeature().equals(this) && this.isEnabled() && (event.getSetting().equals(this.threadDelay) || event.getSetting().equals(this.threadMode))) {
         if (this.executor != null) {
            this.executor.shutdown();
         }

         if (this.thread != null) {
            this.shouldInterrupt.set(true);
         }
      }

   }

   private void postProcessing() {
      if (this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE && (Integer)this.eventMode.getValue() == 2 && this.rotate.getValue() != AutoCrystal.Rotate.OFF && (Boolean)this.rotateFirst.getValue()) {
         switch((AutoCrystal.Logic)this.logic.getValue()) {
         case BREAKPLACE:
            this.postProcessBreak();
            this.postProcessPlace();
            break;
         case PLACEBREAK:
            this.postProcessPlace();
            this.postProcessBreak();
         }

      }
   }

   private void postProcessBreak() {
      for(; !this.packetUseEntities.isEmpty(); this.breakTimer.reset()) {
         CPacketUseEntity packet = (CPacketUseEntity)this.packetUseEntities.poll();
         mc.field_71439_g.field_71174_a.func_147297_a(packet);
         if ((Boolean)this.breakSwing.getValue()) {
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
         }
      }

   }

   private void postProcessPlace() {
      if (this.placeInfo != null) {
         this.placeInfo.runPlace();
         this.placeTimer.reset();
         this.placeInfo = null;
      }

   }

   private void processMultiThreading() {
      if (!this.isOff()) {
         if (this.threadMode.getValue() == AutoCrystal.ThreadMode.WHILE) {
            this.handleWhile();
         } else if (this.threadMode.getValue() != AutoCrystal.ThreadMode.NONE) {
            this.handlePool(false);
         }

      }
   }

   private void handlePool(boolean justDoIt) {
      if (justDoIt || this.executor == null || this.executor.isTerminated() || this.executor.isShutdown() || this.syncroTimer.passedMs((long)(Integer)this.syncThreads.getValue()) && (Boolean)this.syncThreadBool.getValue()) {
         if (this.executor != null) {
            this.executor.shutdown();
         }

         this.executor = this.getExecutor();
         this.syncroTimer.reset();
      }

   }

   private void handleWhile() {
      if (this.thread == null || this.thread.isInterrupted() || !this.thread.isAlive() || this.syncroTimer.passedMs((long)(Integer)this.syncThreads.getValue()) && (Boolean)this.syncThreadBool.getValue()) {
         if (this.thread == null) {
            this.thread = new Thread(AutoCrystal.RAutoCrystal.getInstance(this));
         } else if (this.syncroTimer.passedMs((long)(Integer)this.syncThreads.getValue()) && !this.shouldInterrupt.get() && (Boolean)this.syncThreadBool.getValue()) {
            this.shouldInterrupt.set(true);
            this.syncroTimer.reset();
            return;
         }

         if (this.thread != null && (this.thread.isInterrupted() || !this.thread.isAlive())) {
            this.thread = new Thread(AutoCrystal.RAutoCrystal.getInstance(this));
         }

         if (this.thread != null && this.thread.getState() == State.NEW) {
            try {
               this.thread.start();
            } catch (Exception var2) {
               var2.printStackTrace();
            }

            this.syncroTimer.reset();
         }
      }

   }

   private ScheduledExecutorService getExecutor() {
      ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
      service.scheduleAtFixedRate(AutoCrystal.RAutoCrystal.getInstance(this), 0L, (long)(Integer)this.threadDelay.getValue(), TimeUnit.MILLISECONDS);
      return service;
   }

   public void doAutoCrystal() {
      if (this.check()) {
         switch((AutoCrystal.Logic)this.logic.getValue()) {
         case BREAKPLACE:
            this.breakCrystal();
            this.placeCrystal();
            break;
         case PLACEBREAK:
            this.placeCrystal();
            this.breakCrystal();
         }

         this.manualBreaker();
      }

   }

   private boolean check() {
      if (fullNullCheck()) {
         return false;
      } else {
         if (this.syncTimer.passedMs((long)(Integer)this.damageSyncTime.getValue())) {
            this.currentSyncTarget = null;
            this.syncedCrystalPos = null;
            this.syncedPlayerPos = null;
         } else if ((Boolean)this.syncySync.getValue() && this.syncedCrystalPos != null) {
            this.posConfirmed = true;
         }

         this.foundDoublePop = false;
         if (this.renderTimer.passedMs(500L)) {
            this.renderPos = null;
            this.renderTimer.reset();
         }

         this.mainHand = mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP;
         boolean bl = this.mainHand;
         if (this.autoSwitch.getValue() == AutoCrystal.AutoSwitch.SILENT && InventoryUtil.getItemHotbar(Items.field_185158_cP) != -1) {
            this.mainHand = true;
            this.shouldSilent = true;
         } else {
            this.shouldSilent = false;
         }

         this.offHand = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP;
         this.currentDamage = 0.0D;
         this.placePos = null;
         if (this.lastSlot != mc.field_71439_g.field_71071_by.field_70461_c || AutoTrap.isPlacing || Surround.isPlacing) {
            this.lastSlot = mc.field_71439_g.field_71071_by.field_70461_c;
            this.switchTimer.reset();
         }

         if (!this.offHand && !this.mainHand) {
            this.placeInfo = null;
            this.packetUseEntities.clear();
         }

         if (this.offHand || this.mainHand) {
            this.switching = false;
         }

         if ((this.offHand || this.mainHand || this.switchMode.getValue() != AutoCrystal.Switch.BREAKSLOT || this.switching) && DamageUtil.canBreakWeakness(mc.field_71439_g) && this.switchTimer.passedMs((long)(Integer)this.switchCooldown.getValue())) {
            if ((Boolean)this.mineSwitch.getValue() && Mouse.isButtonDown(0) && (this.switching || this.autoSwitch.getValue() == AutoCrystal.AutoSwitch.ALWAYS) && Mouse.isButtonDown(1) && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemPickaxe) {
               this.switchItem();
            }

            this.mapCrystals();
            if (!this.posConfirmed && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && this.syncTimer.passedMs((long)(Integer)this.confirm.getValue())) {
               this.syncTimer.setMs((long)((Integer)this.damageSyncTime.getValue() + 1));
            }

            return true;
         } else {
            this.renderPos = null;
            target = null;
            this.rotating = false;
            return false;
         }
      }
   }

   private void mapCrystals() {
      this.efficientTarget = null;
      if ((Integer)this.packets.getValue() != 1) {
         this.attackList = new ConcurrentLinkedQueue();
         this.crystalMap = new HashMap();
      }

      this.crystalCount = 0;
      this.minDmgCount = 0;
      Entity maxCrystal = null;
      float maxDamage = 0.5F;
      Iterator var3 = mc.field_71441_e.field_72996_f.iterator();

      Entity entity;
      while(var3.hasNext()) {
         entity = (Entity)var3.next();
         if (!entity.field_70128_L && entity instanceof EntityEnderCrystal && this.isValid(entity)) {
            if ((Boolean)this.syncedFeetPlace.getValue() && entity.func_180425_c().func_177977_b().equals(this.syncedCrystalPos) && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE) {
               ++this.minDmgCount;
               ++this.crystalCount;
               if ((Boolean)this.syncCount.getValue()) {
                  this.minDmgCount = (Integer)this.wasteAmount.getValue() + 1;
                  this.crystalCount = (Integer)this.wasteAmount.getValue() + 1;
               }

               if ((Boolean)this.hyperSync.getValue()) {
                  maxCrystal = null;
                  break;
               }
            } else {
               boolean count = false;
               boolean countMin = false;
               float selfDamage = -1.0F;
               if (DamageUtil.canTakeDamage((Boolean)this.suicide.getValue())) {
                  selfDamage = DamageUtil.calculateDamage((Entity)entity, mc.field_71439_g);
               }

               if ((double)selfDamage + 0.5D < (double)EntityUtil.getHealth(mc.field_71439_g) && selfDamage <= (Float)this.maxSelfBreak.getValue()) {
                  Iterator var10 = mc.field_71441_e.field_73010_i.iterator();

                  label218:
                  while(true) {
                     while(true) {
                        EntityPlayer player;
                        float damage;
                        do {
                           label193:
                           do {
                              do {
                                 do {
                                    if (!var10.hasNext()) {
                                       break label218;
                                    }

                                    player = (EntityPlayer)var10.next();
                                 } while(!(player.func_70068_e(entity) <= MathUtil.square((Float)this.range.getValue())));

                                 if (EntityUtil.isValid(player, (double)((Float)this.range.getValue() + (Float)this.breakRange.getValue()))) {
                                    continue label193;
                                 }
                              } while(this.antiFriendPop.getValue() != AutoCrystal.AntiFriendPop.BREAK && this.antiFriendPop.getValue() != AutoCrystal.AntiFriendPop.ALL || !Loader.friendManager.isFriend(player.func_70005_c_()) || !((double)DamageUtil.calculateDamage((Entity)entity, player) > (double)EntityUtil.getHealth(player) + 0.5D));

                              maxCrystal = maxCrystal;
                              maxDamage = maxDamage;
                              this.crystalMap.remove(entity);
                              if ((Boolean)this.noCount.getValue()) {
                                 count = false;
                                 countMin = false;
                              }
                              break label218;
                           } while((Boolean)this.antiNaked.getValue() && DamageUtil.isNaked(player));
                        } while(!((damage = DamageUtil.calculateDamage((Entity)entity, player)) > selfDamage) && (!(damage > (Float)this.minDamage.getValue()) || DamageUtil.canTakeDamage((Boolean)this.suicide.getValue())) && !(damage > EntityUtil.getHealth(player)));

                        if (damage > maxDamage) {
                           maxDamage = damage;
                           maxCrystal = entity;
                        }

                        if ((Integer)this.packets.getValue() == 1) {
                           if (damage >= (Float)this.minDamage.getValue() || !(Boolean)this.wasteMinDmgCount.getValue()) {
                              count = true;
                           }

                           countMin = true;
                        } else if (this.crystalMap.get(entity) == null || (Float)this.crystalMap.get(entity) < damage) {
                           this.crystalMap.put(entity, damage);
                        }
                     }
                  }
               }

               if (countMin) {
                  ++this.minDmgCount;
                  if (count) {
                     ++this.crystalCount;
                  }
               }
            }
         }
      }

      if (this.damageSync.getValue() == AutoCrystal.DamageSync.BREAK && ((double)maxDamage > this.lastDamage || this.syncTimer.passedMs((long)(Integer)this.damageSyncTime.getValue()) || this.damageSync.getValue() == AutoCrystal.DamageSync.NONE)) {
         this.lastDamage = (double)maxDamage;
      }

      if ((Boolean)this.enormousSync.getValue() && (Boolean)this.syncedFeetPlace.getValue() && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE && this.syncedCrystalPos != null) {
         if ((Boolean)this.syncCount.getValue()) {
            this.minDmgCount = (Integer)this.wasteAmount.getValue() + 1;
            this.crystalCount = (Integer)this.wasteAmount.getValue() + 1;
         }

      } else {
         if ((Boolean)this.webAttack.getValue() && this.webPos != null) {
            if (mc.field_71439_g.func_174818_b(this.webPos.func_177984_a()) > MathUtil.square((Float)this.breakRange.getValue())) {
               this.webPos = null;
            } else {
               var3 = mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(this.webPos.func_177984_a())).iterator();

               while(var3.hasNext()) {
                  entity = (Entity)var3.next();
                  if (entity instanceof EntityEnderCrystal) {
                     this.attackList.add(entity);
                     this.efficientTarget = entity;
                     this.webPos = null;
                     this.lastDamage = 0.5D;
                     return;
                  }
               }
            }
         }

         if (!this.shouldSlowBreak(true) || !(maxDamage < (Float)this.minDamage.getValue()) || target != null && EntityUtil.getHealth(target) <= (Float)this.facePlace.getValue() && (this.breakTimer.passedMs((long)(Integer)this.facePlaceSpeed.getValue()) || !(Boolean)this.slowFaceBreak.getValue() || !Mouse.isButtonDown(0) || !(Boolean)this.holdFacePlace.getValue() || !(Boolean)this.holdFaceBreak.getValue())) {
            if ((Integer)this.packets.getValue() == 1) {
               this.efficientTarget = maxCrystal;
            } else {
               this.crystalMap = MathUtil.sortByValue(this.crystalMap, true);

               for(var3 = this.crystalMap.entrySet().iterator(); var3.hasNext(); ++this.minDmgCount) {
                  Entry entry = (Entry)var3.next();
                  Entity crystal = (Entity)entry.getKey();
                  float damage = (Float)entry.getValue();
                  if (damage >= (Float)this.minDamage.getValue() || !(Boolean)this.wasteMinDmgCount.getValue()) {
                     ++this.crystalCount;
                  }

                  this.attackList.add(crystal);
               }
            }

         } else {
            this.efficientTarget = null;
         }
      }
   }

   private boolean shouldSlowBreak(boolean withManual) {
      return withManual && (Boolean)this.manual.getValue() && (Boolean)this.manualMinDmg.getValue() && Mouse.isButtonDown(1) && (!Mouse.isButtonDown(0) || !(Boolean)this.holdFacePlace.getValue()) || (Boolean)this.holdFacePlace.getValue() && (Boolean)this.holdFaceBreak.getValue() && Mouse.isButtonDown(0) && !this.breakTimer.passedMs((long)(Integer)this.facePlaceSpeed.getValue()) || (Boolean)this.slowFaceBreak.getValue() && !this.breakTimer.passedMs((long)(Integer)this.facePlaceSpeed.getValue());
   }

   private void placeCrystal() {
      int crystalLimit = (Integer)this.wasteAmount.getValue();
      if (this.placeTimer.passedMs((long)(Integer)this.placeDelay.getValue()) && (Boolean)this.place.getValue() && (this.offHand || this.mainHand || this.switchMode.getValue() == AutoCrystal.Switch.CALC || this.switchMode.getValue() == AutoCrystal.Switch.BREAKSLOT && this.switching)) {
         if ((this.offHand || this.mainHand || this.switchMode.getValue() != AutoCrystal.Switch.ALWAYS && !this.switching) && this.crystalCount >= crystalLimit && (!(Boolean)this.antiSurround.getValue() || this.lastPos == null || !this.lastPos.equals(this.placePos))) {
            return;
         }

         this.calculateDamage(this.getTarget(this.targetMode.getValue() == AutoCrystal.Target.UNSAFE));
         if (target != null && this.placePos != null) {
            if (!this.offHand && !this.mainHand && this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.NONE && (this.currentDamage > (double)(Float)this.minDamage.getValue() || (Boolean)this.lethalSwitch.getValue() && EntityUtil.getHealth(target) <= (Float)this.facePlace.getValue()) && !this.switchItem()) {
               return;
            }

            if (this.currentDamage < (double)(Float)this.minDamage.getValue() && (Boolean)this.limitFacePlace.getValue()) {
               crystalLimit = 1;
            }

            if (this.currentDamage >= (double)(Float)this.minMinDmg.getValue() && (this.offHand || this.mainHand || this.autoSwitch.getValue() != AutoCrystal.AutoSwitch.NONE) && (this.crystalCount < crystalLimit || (Boolean)this.antiSurround.getValue() && this.lastPos != null && this.lastPos.equals(this.placePos)) && (this.currentDamage > (double)(Float)this.minDamage.getValue() || this.minDmgCount < crystalLimit) && this.currentDamage >= 1.0D && (DamageUtil.isArmorLow(target, (Integer)this.minArmor.getValue()) || EntityUtil.getHealth(target) <= (Float)this.facePlace.getValue() || this.currentDamage > (double)(Float)this.minDamage.getValue() || this.shouldHoldFacePlace())) {
               float damageOffset = this.damageSync.getValue() == AutoCrystal.DamageSync.BREAK ? (Float)this.dropOff.getValue() - 5.0F : 0.0F;
               boolean syncflag = false;
               if ((Boolean)this.syncedFeetPlace.getValue() && this.placePos.equals(this.lastPos) && this.isEligableForFeetSync(target, this.placePos) && !this.syncTimer.passedMs((long)(Integer)this.damageSyncTime.getValue()) && target.equals(this.currentSyncTarget) && target.func_180425_c().equals(this.syncedPlayerPos) && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE) {
                  this.syncedCrystalPos = this.placePos;
                  this.lastDamage = this.currentDamage;
                  if ((Boolean)this.fullSync.getValue()) {
                     this.lastDamage = 100.0D;
                  }

                  syncflag = true;
               }

               if (syncflag || this.currentDamage - (double)damageOffset > this.lastDamage || this.syncTimer.passedMs((long)(Integer)this.damageSyncTime.getValue()) || this.damageSync.getValue() == AutoCrystal.DamageSync.NONE) {
                  if (!syncflag && this.damageSync.getValue() != AutoCrystal.DamageSync.BREAK) {
                     this.lastDamage = this.currentDamage;
                  }

                  if (!(Boolean)this.onlyplaced.getValue()) {
                     this.renderPos = this.placePos;
                  }

                  this.renderDamage = this.currentDamage;
                  if (this.switchItem()) {
                     this.currentSyncTarget = target;
                     this.syncedPlayerPos = target.func_180425_c();
                     if (this.foundDoublePop) {
                        this.totemPops.put(target, (new Timer()).reset());
                     }

                     this.rotateToPos(this.placePos);
                     if (this.addTolowDmg || (Boolean)this.actualSlowBreak.getValue() && this.currentDamage < (double)(Float)this.minDamage.getValue()) {
                        lowDmgPos.add(this.placePos);
                     }

                     placedPos.add(this.placePos);
                     if (!(Boolean)this.justRender.getValue()) {
                        if ((Integer)this.eventMode.getValue() == 2 && this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE && (Boolean)this.rotateFirst.getValue() && this.rotate.getValue() != AutoCrystal.Rotate.OFF) {
                           this.placeInfo = new AutoCrystal.PlaceInfo(this.placePos, this.offHand, (Boolean)this.placeSwing.getValue(), (Boolean)this.exactHand.getValue(), this.shouldSilent);
                        } else {
                           BlockUtil.placeCrystalOnBlock(this.placePos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, (Boolean)this.placeSwing.getValue(), (Boolean)this.exactHand.getValue(), this.shouldSilent);
                        }
                     }

                     this.lastPos = this.placePos;
                     this.placeTimer.reset();
                     this.posConfirmed = false;
                     if (this.syncTimer.passedMs((long)(Integer)this.damageSyncTime.getValue())) {
                        this.syncedCrystalPos = null;
                        this.syncTimer.reset();
                     }
                  }
               }
            }
         } else {
            this.renderPos = null;
         }
      }

   }

   private boolean shouldHoldFacePlace() {
      this.addTolowDmg = false;
      if ((Boolean)this.holdFacePlace.getValue() && Mouse.isButtonDown(0)) {
         this.addTolowDmg = true;
         return true;
      } else {
         return false;
      }
   }

   private boolean switchItem() {
      if (!this.offHand && !this.mainHand) {
         switch((AutoCrystal.AutoSwitch)this.autoSwitch.getValue()) {
         case NONE:
            return false;
         case TOGGLE:
            if (!this.switching) {
               return false;
            }
         case ALWAYS:
            if (this.doSwitch()) {
               return true;
            }
         default:
            return false;
         }
      } else {
         return true;
      }
   }

   private boolean doSwitch() {
      if ((Boolean)this.offhandSwitch.getValue()) {
         Offhand module = (Offhand)Loader.moduleManager.getModuleByClass(Offhand.class);
         if (module.isOff()) {
            Command.sendMessage("<" + this.getDisplayName() + "> §cSwitch failed. Enable the Offhand module.");
            this.switching = false;
            return false;
         } else {
            if (module.type.getValue() == Offhand.Type.NEW) {
               module.setSwapToTotem(false);
               module.setMode(Offhand.Mode.CRYSTALS);
               module.doOffhand();
            } else {
               module.setMode(Offhand.Mode2.CRYSTALS);
               module.doSwitch();
            }

            this.switching = false;
            return true;
         }
      } else {
         if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            this.mainHand = false;
         } else {
            InventoryUtil.switchToHotbarSlot(ItemEndCrystal.class, false);
            this.mainHand = true;
         }

         this.switching = false;
         return true;
      }
   }

   private void calculateDamage(EntityPlayer targettedPlayer) {
      if (targettedPlayer != null || this.targetMode.getValue() == AutoCrystal.Target.DAMAGE || (Boolean)this.fullCalc.getValue()) {
         float maxDamage = 0.5F;
         EntityPlayer currentTarget = null;
         BlockPos currentPos = null;
         float maxSelfDamage = 0.0F;
         this.foundDoublePop = false;
         BlockPos setToAir = null;
         IBlockState state = null;
         BlockPos playerPos;
         if ((Boolean)this.webAttack.getValue() && targettedPlayer != null && mc.field_71441_e.func_180495_p(playerPos = new BlockPos(targettedPlayer.func_174791_d())).func_177230_c() == Blocks.field_150321_G) {
            setToAir = playerPos;
            state = mc.field_71441_e.func_180495_p(playerPos);
            mc.field_71441_e.func_175698_g(playerPos);
         }

         Iterator var9 = BlockUtil.possiblePlacePositions((Float)this.placeRange.getValue(), (Boolean)this.antiSurround.getValue(), (Boolean)this.oneDot15.getValue()).iterator();

         while(true) {
            while(true) {
               BlockPos pos;
               float selfDamage;
               float playerDamage;
               boolean friendPop;
               label204:
               do {
                  label179:
                  while(true) {
                     do {
                        do {
                           do {
                              if (!var9.hasNext()) {
                                 if (setToAir != null) {
                                    mc.field_71441_e.func_175656_a(setToAir, state);
                                    this.webPos = currentPos;
                                 }

                                 target = currentTarget;
                                 this.currentDamage = (double)maxDamage;
                                 this.placePos = currentPos;
                                 return;
                              }

                              pos = (BlockPos)var9.next();
                           } while(!BlockUtil.rayTracePlaceCheck(pos, (this.raytrace.getValue() == AutoCrystal.Raytrace.PLACE || this.raytrace.getValue() == AutoCrystal.Raytrace.FULL) && mc.field_71439_g.func_174818_b(pos) > MathUtil.square((Float)this.placetrace.getValue()), 1.0F));

                           selfDamage = -1.0F;
                           if (DamageUtil.canTakeDamage((Boolean)this.suicide.getValue())) {
                              selfDamage = DamageUtil.calculateDamage((BlockPos)pos, mc.field_71439_g);
                           }
                        } while(!((double)selfDamage + 0.5D < (double)EntityUtil.getHealth(mc.field_71439_g)));
                     } while(!(selfDamage <= (Float)this.maxSelfPlace.getValue()));

                     if (targettedPlayer != null) {
                        playerDamage = DamageUtil.calculateDamage((BlockPos)pos, targettedPlayer);
                        if (!(Boolean)this.calcEvenIfNoDamage.getValue() || this.antiFriendPop.getValue() != AutoCrystal.AntiFriendPop.ALL && this.antiFriendPop.getValue() != AutoCrystal.AntiFriendPop.PLACE) {
                           break label204;
                        }

                        friendPop = false;
                        Iterator var14 = mc.field_71441_e.field_73010_i.iterator();

                        while(var14.hasNext()) {
                           EntityPlayer friend = (EntityPlayer)var14.next();
                           if (friend != null && !mc.field_71439_g.equals(friend) && !(friend.func_174818_b(pos) > MathUtil.square((Float)this.range.getValue() + (Float)this.placeRange.getValue())) && Loader.friendManager.isFriend(friend) && (double)DamageUtil.calculateDamage((BlockPos)pos, friend) > (double)EntityUtil.getHealth(friend) + 0.5D) {
                              friendPop = true;
                              continue label204;
                           }
                        }
                        break;
                     }

                     Iterator var16 = mc.field_71441_e.field_73010_i.iterator();

                     while(true) {
                        while(true) {
                           EntityPlayer player;
                           label150:
                           do {
                              do {
                                 if (!var16.hasNext()) {
                                    continue label179;
                                 }

                                 player = (EntityPlayer)var16.next();
                                 if (EntityUtil.isValid(player, (double)((Float)this.placeRange.getValue() + (Float)this.range.getValue()))) {
                                    continue label150;
                                 }
                              } while(this.antiFriendPop.getValue() != AutoCrystal.AntiFriendPop.ALL && this.antiFriendPop.getValue() != AutoCrystal.AntiFriendPop.PLACE || player == null || !(player.func_174818_b(pos) <= MathUtil.square((Float)this.range.getValue() + (Float)this.placeRange.getValue())) || !Loader.friendManager.isFriend(player) || !((double)DamageUtil.calculateDamage((BlockPos)pos, player) > (double)EntityUtil.getHealth(player) + 0.5D));

                              maxDamage = maxDamage;
                              currentTarget = currentTarget;
                              currentPos = currentPos;
                              maxSelfDamage = maxSelfDamage;
                              continue label179;
                           } while((Boolean)this.antiNaked.getValue() && DamageUtil.isNaked(player));

                           float playerDamage = DamageUtil.calculateDamage((BlockPos)pos, player);
                           if ((Boolean)this.doublePopOnDamage.getValue() && this.isDoublePoppable(player, playerDamage) && (currentPos == null || player.func_174818_b(pos) < player.func_174818_b(currentPos))) {
                              currentTarget = player;
                              maxDamage = playerDamage;
                              currentPos = pos;
                              maxSelfDamage = selfDamage;
                              this.foundDoublePop = true;
                              if (this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.BREAK || this.antiFriendPop.getValue() == AutoCrystal.AntiFriendPop.PLACE) {
                                 continue label179;
                              }
                           } else if (!this.foundDoublePop && (playerDamage > maxDamage || (Boolean)this.extraSelfCalc.getValue() && playerDamage >= maxDamage && selfDamage < maxSelfDamage) && (playerDamage > selfDamage || playerDamage > (Float)this.minDamage.getValue() && !DamageUtil.canTakeDamage((Boolean)this.suicide.getValue()) || playerDamage > EntityUtil.getHealth(player))) {
                              maxDamage = playerDamage;
                              currentTarget = player;
                              currentPos = pos;
                              maxSelfDamage = selfDamage;
                           }
                        }
                     }
                  }
               } while(friendPop);

               if (this.isDoublePoppable(targettedPlayer, playerDamage) && (currentPos == null || targettedPlayer.func_174818_b(pos) < targettedPlayer.func_174818_b(currentPos))) {
                  currentTarget = targettedPlayer;
                  maxDamage = playerDamage;
                  currentPos = pos;
                  this.foundDoublePop = true;
               } else if (!this.foundDoublePop && (playerDamage > maxDamage || (Boolean)this.extraSelfCalc.getValue() && playerDamage >= maxDamage && selfDamage < maxSelfDamage) && (playerDamage > selfDamage || playerDamage > (Float)this.minDamage.getValue() && !DamageUtil.canTakeDamage((Boolean)this.suicide.getValue()) || playerDamage > EntityUtil.getHealth(targettedPlayer))) {
                  maxDamage = playerDamage;
                  currentTarget = targettedPlayer;
                  currentPos = pos;
                  maxSelfDamage = selfDamage;
               }
            }
         }
      }
   }

   private EntityPlayer getTarget(boolean unsafe) {
      if (this.targetMode.getValue() == AutoCrystal.Target.DAMAGE) {
         return null;
      } else {
         EntityPlayer currentTarget = null;
         Iterator var3 = mc.field_71441_e.field_73010_i.iterator();

         while(var3.hasNext()) {
            EntityPlayer player = (EntityPlayer)var3.next();
            if (!EntityUtil.isntValid(player, (double)((Float)this.placeRange.getValue() + (Float)this.range.getValue())) && (!(Boolean)this.antiNaked.getValue() || !DamageUtil.isNaked(player)) && (!unsafe || !EntityUtil.isSafe(player))) {
               if ((Integer)this.minArmor.getValue() > 0 && DamageUtil.isArmorLow(player, (Integer)this.minArmor.getValue())) {
                  currentTarget = player;
                  break;
               }

               if (currentTarget == null) {
                  currentTarget = player;
               } else if (mc.field_71439_g.func_70068_e(player) < mc.field_71439_g.func_70068_e((Entity)currentTarget)) {
                  currentTarget = player;
               }
            }
         }

         if (unsafe && currentTarget == null) {
            return this.getTarget(false);
         } else {
            if ((Boolean)this.predictPos.getValue() && currentTarget != null) {
               ((EntityPlayer)currentTarget).func_110124_au();
               GameProfile profile = new GameProfile(((EntityPlayer)currentTarget).func_110124_au(), ((EntityPlayer)currentTarget).func_70005_c_());
               EntityOtherPlayerMP newTarget = new EntityOtherPlayerMP(mc.field_71441_e, profile);
               Vec3d extrapolatePosition = MathUtil.extrapolatePlayerPosition((EntityPlayer)currentTarget, (Integer)this.predictTicks.getValue());
               newTarget.func_82149_j((Entity)currentTarget);
               newTarget.field_70165_t = extrapolatePosition.field_72450_a;
               newTarget.field_70163_u = extrapolatePosition.field_72448_b;
               newTarget.field_70161_v = extrapolatePosition.field_72449_c;
               newTarget.func_70606_j(EntityUtil.getHealth((Entity)currentTarget));
               newTarget.field_71071_by.func_70455_b(((EntityPlayer)currentTarget).field_71071_by);
               currentTarget = newTarget;
            }

            return (EntityPlayer)currentTarget;
         }
      }
   }

   private void breakCrystal() {
      int swordSlot = InventoryUtil.findHotbarBlock(ItemSword.class);
      int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      if ((Boolean)this.explode.getValue() && this.breakTimer.passedMs((long)(Integer)this.breakDelay.getValue()) && (this.switchMode.getValue() == AutoCrystal.Switch.ALWAYS || this.mainHand || this.offHand)) {
         if ((Integer)this.packets.getValue() == 1 && this.efficientTarget != null) {
            if ((Boolean)this.justRender.getValue()) {
               this.doFakeSwing();
               return;
            }

            if ((Boolean)this.syncedFeetPlace.getValue() && (Boolean)this.gigaSync.getValue() && this.syncedCrystalPos != null && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE) {
               return;
            }

            this.rotateTo(this.efficientTarget);
            if (!this.offHand && !this.mainHand && this.switchMode.getValue() == AutoCrystal.Switch.BREAKSLOT && !this.switching || !DamageUtil.canBreakWeakness(mc.field_71439_g) || !this.switchTimer.passedMs((long)(Integer)this.switchCooldown.getValue()) && this.antiWeakness.getValue() != AutoCrystal.AntiWeaknessMode.None) {
               if (this.antiWeakness.getValue() == AutoCrystal.AntiWeaknessMode.Silent) {
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(swordSlot));
                  this.attackEntity(this.efficientTarget);
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(oldSlot));
               }

               if (this.antiWeakness.getValue() == AutoCrystal.AntiWeaknessMode.Normal) {
                  InventoryUtil.switchToHotbarSlot(swordSlot, false);
                  this.attackEntity(this.efficientTarget);
                  InventoryUtil.switchToHotbarSlot(oldSlot, false);
               }
            } else {
               this.attackEntity(this.efficientTarget);
            }

            this.breakTimer.reset();
         } else if (!this.attackList.isEmpty()) {
            if ((Boolean)this.justRender.getValue()) {
               this.doFakeSwing();
               return;
            }

            if ((Boolean)this.syncedFeetPlace.getValue() && (Boolean)this.gigaSync.getValue() && this.syncedCrystalPos != null && this.damageSync.getValue() != AutoCrystal.DamageSync.NONE) {
               return;
            }

            for(int i = 0; i < (Integer)this.packets.getValue(); ++i) {
               Entity entity = (Entity)this.attackList.poll();
               if (entity != null) {
                  this.rotateTo(entity);
                  this.attackEntity(entity);
               }
            }

            this.breakTimer.reset();
         }
      }

   }

   private void attackEntity(Entity entity) {
      if (entity != null) {
         if ((Integer)this.eventMode.getValue() == 2 && this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE && (Boolean)this.rotateFirst.getValue() && this.rotate.getValue() != AutoCrystal.Rotate.OFF) {
            this.packetUseEntities.add(new CPacketUseEntity(entity));
         } else {
            EntityUtil.attackEntity(entity, (Boolean)this.sync.getValue(), (Boolean)this.breakSwing.getValue());
            EntityUtil.OffhandAttack(entity, (Boolean)this.attackOppositeHand.getValue(), (Boolean)this.attackOppositeHand.getValue());
            brokenPos.add((new BlockPos(entity.func_174791_d())).func_177977_b());
         }
      }

   }

   private void doFakeSwing() {
      if ((Boolean)this.fakeSwing.getValue()) {
         EntityUtil.swingArmNoPacket(EnumHand.MAIN_HAND, mc.field_71439_g);
      }

   }

   private void manualBreaker() {
      if (this.rotate.getValue() != AutoCrystal.Rotate.OFF && (Integer)this.eventMode.getValue() != 2 && this.rotating) {
         if (this.didRotation) {
            mc.field_71439_g.field_70125_A = (float)((double)mc.field_71439_g.field_70125_A + 4.0E-4D);
            this.didRotation = false;
         } else {
            mc.field_71439_g.field_70125_A = (float)((double)mc.field_71439_g.field_70125_A - 4.0E-4D);
            this.didRotation = true;
         }
      }

      RayTraceResult result;
      if ((this.offHand || this.mainHand) && (Boolean)this.manual.getValue() && this.manualTimer.passedMs((long)(Integer)this.manualBreak.getValue()) && Mouse.isButtonDown(1) && mc.field_71439_g.func_184592_cb().func_77973_b() != Items.field_151153_ao && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151153_ao && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151031_f && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151062_by && (result = mc.field_71476_x) != null) {
         switch(result.field_72313_a) {
         case ENTITY:
            Entity entity = result.field_72308_g;
            if (entity instanceof EntityEnderCrystal) {
               EntityUtil.attackEntity(entity, (Boolean)this.sync.getValue(), (Boolean)this.breakSwing.getValue());
               EntityUtil.OffhandAttack(entity, (Boolean)this.attackOppositeHand.getValue(), (Boolean)this.attackOppositeHand.getValue());
               this.manualTimer.reset();
            }
            break;
         case BLOCK:
            BlockPos mousePos = mc.field_71476_x.func_178782_a().func_177984_a();
            Iterator var3 = mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(mousePos)).iterator();

            while(var3.hasNext()) {
               Entity target = (Entity)var3.next();
               if (target instanceof EntityEnderCrystal) {
                  EntityUtil.attackEntity(target, (Boolean)this.sync.getValue(), (Boolean)this.breakSwing.getValue());
                  EntityUtil.OffhandAttack(target, (Boolean)this.attackOppositeHand.getValue(), (Boolean)this.attackOppositeHand.getValue());
                  this.manualTimer.reset();
               }
            }
         }
      }

   }

   private void rotateTo(Entity entity) {
      switch((AutoCrystal.Rotate)this.rotate.getValue()) {
      case OFF:
         this.rotating = false;
      case PLACE:
      default:
         break;
      case BREAK:
      case ALL:
         float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(Util.mc.func_184121_ak()), entity.func_174791_d());
         if ((Integer)this.eventMode.getValue() == 2 && this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE) {
            if ((Boolean)this.YawStep.getValue()) {
               float f = Loader.rotationManager.getYaw();

               while(f < angle[1]) {
                  if (mc.field_71439_g.field_70173_aa % (Integer)this.YawStepTicks.getValue() == 0) {
                     Loader.rotationManager.setPlayerRotations(f += (float)(Integer)this.YawStepVal.getValue(), angle[1]);
                     if ((Boolean)this.YawStepDebugMessages.getValue()) {
                        Command.sendMessage("Yaw " + Loader.rotationManager.getYaw());
                     }
                  }
               }
            } else {
               Loader.rotationManager.setPlayerRotations(angle[0], angle[1]);
            }
         } else {
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.rotating = true;
         }
      }

   }

   private void rotateToPos(BlockPos pos) {
      switch((AutoCrystal.Rotate)this.rotate.getValue()) {
      case OFF:
         this.rotating = false;
         break;
      case PLACE:
      case ALL:
         float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(Util.mc.func_184121_ak()), new Vec3d((double)((float)pos.func_177958_n() + 0.5F), (double)((float)pos.func_177956_o() - 0.5F), (double)((float)pos.func_177952_p() + 0.5F)));
         if ((Integer)this.eventMode.getValue() == 2 && this.threadMode.getValue() == AutoCrystal.ThreadMode.NONE) {
            if ((Boolean)this.YawStep.getValue()) {
               float f = Loader.rotationManager.getYaw();

               while(f < angle[1]) {
                  if (mc.field_71439_g.field_70173_aa % (Integer)this.YawStepTicks.getValue() == 0) {
                     Loader.rotationManager.setPlayerRotations(f += (float)(Integer)this.YawStepVal.getValue(), angle[1]);
                     this.yawStepTimer.reset();
                     if ((Boolean)this.YawStepDebugMessages.getValue()) {
                        Command.sendMessage("Yaw" + Loader.rotationManager.getYaw());
                     }
                  }
               }
            } else {
               Loader.rotationManager.setPlayerRotations(angle[0], angle[1]);
            }
         } else {
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.rotating = true;
         }
      case BREAK:
      }

   }

   private boolean isDoublePoppable(EntityPlayer player, float damage) {
      if ((Boolean)this.doublePop.getValue()) {
         float health = EntityUtil.getHealth(player);
         if ((double)health <= (Double)this.popHealth.getValue() && (double)damage > (double)health + 0.5D && damage <= (Float)this.popDamage.getValue()) {
            Timer timer = (Timer)this.totemPops.get(player);
            return timer == null || timer.passedMs((long)(Integer)this.popTime.getValue());
         }
      }

      return false;
   }

   private boolean isValid(Entity entity) {
      return entity != null && mc.field_71439_g.func_70068_e(entity) <= MathUtil.square((Float)this.breakRange.getValue()) && (this.raytrace.getValue() == AutoCrystal.Raytrace.NONE || this.raytrace.getValue() == AutoCrystal.Raytrace.PLACE || mc.field_71439_g.func_70685_l(entity) || !mc.field_71439_g.func_70685_l(entity) && mc.field_71439_g.func_70068_e(entity) <= MathUtil.square((Float)this.breaktrace.getValue()));
   }

   private boolean isEligableForFeetSync(EntityPlayer player, BlockPos pos) {
      if ((Boolean)this.holySync.getValue()) {
         BlockPos playerPos = new BlockPos(player.func_174791_d());
         EnumFacing[] var4 = EnumFacing.values();
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            EnumFacing facing = var4[var6];
            if (facing != EnumFacing.DOWN && facing != EnumFacing.UP && pos.equals(playerPos.func_177977_b().func_177972_a(facing))) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private class RenderPos {
      private BlockPos renderPos;
      private float renderTime;

      public RenderPos(BlockPos pos, float time) {
         this.renderPos = pos;
         this.renderTime = time;
      }

      public BlockPos getPos() {
         return this.renderPos;
      }

      public void setPos(BlockPos pos) {
         this.renderPos = pos;
      }

      public float getRenderTime() {
         return this.renderTime;
      }

      public void setRenderTime(float time) {
         this.renderTime = time;
      }
   }

   private static class RAutoCrystal implements Runnable {
      private static AutoCrystal.RAutoCrystal instance;
      private AutoCrystal autoCrystal;

      public static AutoCrystal.RAutoCrystal getInstance(AutoCrystal autoCrystal) {
         if (instance == null) {
            instance = new AutoCrystal.RAutoCrystal();
            instance.autoCrystal = autoCrystal;
         }

         return instance;
      }

      public void run() {
         if (this.autoCrystal.threadMode.getValue() != AutoCrystal.ThreadMode.WHILE) {
            if (this.autoCrystal.threadMode.getValue() != AutoCrystal.ThreadMode.NONE && this.autoCrystal.isOn()) {
               while(true) {
                  if (!Loader.eventManager.ticksOngoing()) {
                     this.autoCrystal.threadOngoing.set(true);
                     Loader.safetyManager.doSafetyCheck();
                     this.autoCrystal.doAutoCrystal();
                     this.autoCrystal.threadOngoing.set(false);
                     break;
                  }
               }
            }
         } else {
            while(this.autoCrystal.isOn() && this.autoCrystal.threadMode.getValue() == AutoCrystal.ThreadMode.WHILE) {
               while(Loader.eventManager.ticksOngoing()) {
               }

               if (this.autoCrystal.shouldInterrupt.get()) {
                  this.autoCrystal.shouldInterrupt.set(false);
                  this.autoCrystal.syncroTimer.reset();
                  this.autoCrystal.thread.interrupt();
                  break;
               }

               this.autoCrystal.threadOngoing.set(true);
               Loader.safetyManager.doSafetyCheck();
               this.autoCrystal.doAutoCrystal();
               this.autoCrystal.threadOngoing.set(false);

               try {
                  Thread.sleep((long)(Integer)this.autoCrystal.threadDelay.getValue());
               } catch (InterruptedException var2) {
                  this.autoCrystal.thread.interrupt();
                  var2.printStackTrace();
               }
            }
         }

      }
   }

   public static class PlaceInfo {
      private final BlockPos pos;
      private final boolean offhand;
      private final boolean placeSwing;
      private final boolean exactHand;
      private final boolean silent;

      public PlaceInfo(BlockPos pos, boolean offhand, boolean placeSwing, boolean exactHand, boolean silent) {
         this.pos = pos;
         this.offhand = offhand;
         this.placeSwing = placeSwing;
         this.exactHand = exactHand;
         this.silent = silent;
      }

      public void runPlace() {
         BlockUtil.placeCrystalOnBlock(this.pos, this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.placeSwing, this.exactHand, this.silent);
      }
   }

   public static enum AntiWeaknessMode {
      Normal,
      Silent,
      None;
   }

   public static enum Timing {
      Sequential,
      None;
   }

   public static enum RenderMode {
      STATIC,
      FADE,
      GLIDE,
      GRADIENTRAINBOW;
   }

   public static enum Settings {
      PLACE,
      BREAK,
      RENDER,
      MISC,
      DEV;
   }

   public static enum DamageSync {
      NONE,
      PLACE,
      BREAK;
   }

   public static enum Rotate {
      OFF,
      PLACE,
      BREAK,
      ALL;
   }

   public static enum Target {
      CLOSEST,
      UNSAFE,
      DAMAGE;
   }

   public static enum Logic {
      BREAKPLACE,
      PLACEBREAK;
   }

   public static enum Switch {
      ALWAYS,
      BREAKSLOT,
      CALC;
   }

   public static enum Raytrace {
      NONE,
      PLACE,
      BREAK,
      FULL;
   }

   public static enum AutoSwitch {
      NONE,
      TOGGLE,
      ALWAYS,
      SILENT;
   }

   public static enum ThreadMode {
      NONE,
      POOL,
      SOUND,
      WHILE;
   }

   public static enum AntiFriendPop {
      NONE,
      PLACE,
      BREAK,
      ALL;
   }

   public static enum PredictTimer {
      NONE,
      BREAK,
      PREDICT;
   }
}
