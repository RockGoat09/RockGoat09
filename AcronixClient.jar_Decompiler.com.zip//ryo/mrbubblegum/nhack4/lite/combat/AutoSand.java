package ryo.mrbubblegum.nhack4.lite.combat;

import java.util.Comparator;
import net.minecraft.block.BlockSand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import ryo.mrbubblegum.nhack4.impl.util.BlockUtil;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.lite.Module;

public class AutoSand extends Module {
   EntityPlayer entityPlayer;

   public AutoSand() {
      super("AutoSand", "Automatically places sand on players.", Module.Category.COMBAT, true, false, false);
   }

   public void onEnable() {
      this.placeSand();
      this.disable();
   }

   public void placeSand() {
      this.entityPlayer = (EntityPlayer)mc.field_71441_e.field_73010_i.stream().filter((p) -> {
         return p.func_145782_y() != mc.field_71439_g.func_145782_y();
      }).min(Comparator.comparing((p) -> {
         return p.func_70032_d(mc.field_71439_g);
      })).orElse((Object)null);
      if (this.entityPlayer != null) {
         BlockPos sandPlacePos = new BlockPos(Math.floor(this.entityPlayer.field_70165_t), Math.floor(this.entityPlayer.field_70163_u + 2.0D), Math.floor(this.entityPlayer.field_70161_v));
         BlockPos playerPos = new BlockPos(Math.floor(this.entityPlayer.field_70165_t), Math.floor(this.entityPlayer.field_70163_u), Math.floor(this.entityPlayer.field_70161_v));
         int sand = InventoryUtil.findHotbarBlock(BlockSand.class);
         int previousSlot = mc.field_71439_g.field_71071_by.field_70461_c;
         int canPlace = BlockUtil.isPositionPlaceable(sandPlacePos, false, true);
         if (canPlace != -1 && this.entityPlayer != null && sand != -1 && sandPlacePos != null && mc.field_71441_e.func_180495_p(playerPos).func_177230_c() == Blocks.field_150350_a) {
            mc.field_71439_g.field_71071_by.field_70461_c = sand;
            mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(sandPlacePos, EnumHand.MAIN_HAND, false, true, false);
            mc.field_71439_g.field_71071_by.field_70461_c = previousSlot;
         } else {
            this.disable();
         }
      }

   }
}
