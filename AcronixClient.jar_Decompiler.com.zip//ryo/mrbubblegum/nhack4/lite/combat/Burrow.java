package ryo.mrbubblegum.nhack4.lite.combat;

import java.util.Iterator;
import net.minecraft.block.BlockBeacon;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockSkull;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import ryo.mrbubblegum.nhack4.impl.util.BurrowUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class Burrow extends Module {
   private final Setting<Integer> offset = this.register(new Setting("Offset", 3, -5, 5));
   private final Setting<Boolean> ground = this.register(new Setting("GroundCheck", true));
   private final Setting<Boolean> rotate = this.register(new Setting("Rotate", false));
   private final Setting<Boolean> center = this.register(new Setting("Center", true));
   private final Setting<Boolean> echest = this.register(new Setting("UseEchest", false));
   private final Setting<Boolean> anvil = this.register(new Setting("Beacon", false));
   private final Setting<Boolean> web = this.register(new Setting("Chest", false));
   private final Setting<Boolean> skull = this.register(new Setting("UseSkull", false));
   private BlockPos originalPos;
   private int oldSlot = -1;

   public Burrow() {
      super("SelfBlock", "no skill require", Module.Category.COMBAT, true, false, false);
   }

   public void onEnable() {
      super.onEnable();
      this.originalPos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
      if (!mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v)).func_177230_c().equals(Blocks.field_150343_Z) && !this.intersectsWithEntity(this.originalPos)) {
         if ((Boolean)this.center.getValue()) {
            double x = mc.field_71439_g.field_70165_t - Math.floor(mc.field_71439_g.field_70165_t);
            double z = mc.field_71439_g.field_70161_v - Math.floor(mc.field_71439_g.field_70161_v);
            if (x <= 0.3D || x >= 0.7D) {
               x = x > 0.5D ? 0.69D : 0.31D;
            }

            if (z < 0.3D || z > 0.7D) {
               z = z > 0.5D ? 0.69D : 0.31D;
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new Position(Math.floor(mc.field_71439_g.field_70165_t) + x, mc.field_71439_g.field_70163_u, Math.floor(mc.field_71439_g.field_70161_v) + z, mc.field_71439_g.field_70122_E));
            mc.field_71439_g.func_70107_b(Math.floor(mc.field_71439_g.field_70165_t) + x, mc.field_71439_g.field_70163_u, Math.floor(mc.field_71439_g.field_70161_v) + z);
         }

         this.oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
      } else {
         this.toggle();
      }
   }

   public void onUpdate() {
      if ((Boolean)this.ground.getValue() && !mc.field_71439_g.field_70122_E) {
         this.toggle();
      } else {
         label92: {
            if ((Boolean)this.anvil.getValue() && BurrowUtil.findHotbarBlock(BlockBeacon.class) != -1) {
               BurrowUtil.switchToSlot(BurrowUtil.findHotbarBlock(BlockBeacon.class));
            } else {
               label91: {
                  label82: {
                     if ((Boolean)this.echest.getValue()) {
                        if (BurrowUtil.findHotbarBlock(BlockEnderChest.class) != -1) {
                           break label82;
                        }
                     } else if (BurrowUtil.findHotbarBlock(BlockObsidian.class) != -1) {
                        break label82;
                     }

                     label83: {
                        if ((Boolean)this.echest.getValue()) {
                           if (BurrowUtil.findHotbarBlock(BlockEnderChest.class) == -1) {
                              break label83;
                           }
                        } else if (BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1) {
                           break label83;
                        }

                        BurrowUtil.switchToSlot((Boolean)this.echest.getValue() ? BurrowUtil.findHotbarBlock(BlockEnderChest.class) : BurrowUtil.findHotbarBlock(BlockObsidian.class));
                        if ((Boolean)this.skull.getValue() && BurrowUtil.findHotbarBlock(BlockSkull.class) != -1) {
                           BurrowUtil.switchToSlot(BurrowUtil.findHotbarBlock(BlockSkull.class));
                        }
                        break label91;
                     }

                     if ((Boolean)this.echest.getValue()) {
                        if (BurrowUtil.findHotbarBlock(BlockEnderChest.class) == -1) {
                           break label92;
                        }
                     } else if (BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1) {
                        break label92;
                     }

                     BurrowUtil.switchToSlot((Boolean)this.echest.getValue() ? BurrowUtil.findHotbarBlock(BlockEnderChest.class) : BurrowUtil.findHotbarBlock(BlockObsidian.class));
                     break label91;
                  }

                  BurrowUtil.switchToSlot((Boolean)this.echest.getValue() ? BurrowUtil.findHotbarBlock(BlockEnderChest.class) : BurrowUtil.findHotbarBlock(BlockObsidian.class));
                  if ((Boolean)this.web.getValue() && BurrowUtil.findHotbarBlock(BlockChest.class) != -1) {
                  }

                  BurrowUtil.switchToSlot(BurrowUtil.findHotbarBlock(BlockChest.class));
               }
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.41999998688698D, mc.field_71439_g.field_70161_v, true));
            mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.7531999805211997D, mc.field_71439_g.field_70161_v, true));
            mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.00133597911214D, mc.field_71439_g.field_70161_v, true));
            mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.16610926093821D, mc.field_71439_g.field_70161_v, true));
            BurrowUtil.placeBlock(this.originalPos, EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), true, false);
            mc.field_71439_g.field_71174_a.func_147297_a(new Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)(Integer)this.offset.getValue(), mc.field_71439_g.field_70161_v, false));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.STOP_SNEAKING));
            mc.field_71439_g.func_70095_a(false);
            BurrowUtil.switchToSlot(this.oldSlot);
            this.toggle();
            return;
         }

         Command.sendMessage("Unable to place burrow block (anvil, ec or oby)");
         this.toggle();
      }
   }

   private boolean intersectsWithEntity(BlockPos pos) {
      Iterator var2 = mc.field_71441_e.field_72996_f.iterator();

      Entity entity;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         entity = (Entity)var2.next();
      } while(entity.equals(mc.field_71439_g) || entity instanceof EntityItem || !(new AxisAlignedBB(pos)).func_72326_a(entity.func_174813_aQ()));

      return true;
   }
}
