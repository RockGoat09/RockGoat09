package ryo.mrbubblegum.nhack4.lite.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import ryo.mrbubblegum.nhack4.impl.util.BlockUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class CevBreaker extends Module {
   private List<BlockPos> placeList = new ArrayList();
   private boolean placing = false;
   private boolean placedCrystal = false;
   private boolean breaking = false;
   private boolean broke = false;
   private EntityPlayer _target = null;
   private BlockPos b_crystal = null;
   private BlockPos breakPos = null;
   private int attempts = 0;
   private final Setting<CevBreaker.type> targetType;
   private final Setting<CevBreaker.mode> breakMode;
   private final Setting<Boolean> rotate;
   private final Setting<Integer> startDelay;
   private final Setting<Integer> breakDelay;
   private final Setting<Integer> crystalDelay;
   private final Setting<Integer> hitDelay;
   private final Setting<Integer> tinpoDelay;
   private int timer;

   public CevBreaker() {
      super("OverCrystal", "cev breaker shit yk yk", Module.Category.COMBAT, true, false, false);
      this.targetType = this.register(new Setting("Target", CevBreaker.type.NEAREST));
      this.breakMode = this.register(new Setting("Break Mode", CevBreaker.mode.Vanilla));
      this.rotate = this.register(new Setting("Rotate", true));
      this.startDelay = this.register(new Setting("Start Delay", 1, 0, 10));
      this.breakDelay = this.register(new Setting("Break Delay", 1, 0, 10));
      this.crystalDelay = this.register(new Setting("Crystal Delay", 1, 0, 10));
      this.hitDelay = this.register(new Setting("Hit Delay", 3, 0, 10));
      this.tinpoDelay = this.register(new Setting("Tinpo Delay", 3, 0, 10));
      this.timer = 0;
   }

   public void onEnable() {
      this.init();
   }

   private void init() {
      this.placeList = new ArrayList();
      this._target = null;
      this.b_crystal = null;
      this.placedCrystal = false;
      this.placing = false;
      this.breaking = false;
      this.broke = false;
      this.timer = 0;
      this.attempts = 0;
   }

   public void onTick() {
      int pix = this.findItem(Items.field_151046_w);
      int crystal = this.findItem(Items.field_185158_cP);
      int obby = this.findMaterials(Blocks.field_150343_Z);
      if (pix != -1 && crystal != -1 && obby != -1) {
         if (this._target == null) {
            if (this.targetType.getValue() == CevBreaker.type.NEAREST) {
               this._target = (EntityPlayer)mc.field_71441_e.field_73010_i.stream().filter((p) -> {
                  return p.func_145782_y() != mc.field_71439_g.func_145782_y();
               }).min(Comparator.comparing((p) -> {
                  return p.func_70032_d(mc.field_71439_g);
               })).orElse((Object)null);
            }

            if (this._target == null) {
               this.disable();
               return;
            }
         }

         if (this.placeList.size() == 0 && !this.placing) {
            this.searchSpace();
            if (this.placeList.size() == 0) {
               this.disable();
               return;
            }
         }

         if (!this.placedCrystal) {
            if (this.timer < (Integer)this.startDelay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            this.doPlace(obby, crystal);
         } else if (!this.breaking) {
            if (this.timer < (Integer)this.breakDelay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            if (this.breakMode.getValue() == CevBreaker.mode.Vanilla) {
               mc.field_71439_g.field_71071_by.field_70461_c = pix;
               mc.field_71442_b.func_78765_e();
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               mc.field_71442_b.func_180512_c(this.breakPos, EnumFacing.DOWN);
            } else {
               mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, this.breakPos, EnumFacing.DOWN));
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, this.breakPos, EnumFacing.DOWN));
            }

            this.breaking = true;
         } else if (this.breaking && !this.broke) {
            if (this.getBlock(this.breakPos) == Blocks.field_150350_a) {
               this.broke = true;
            }
         } else if (this.broke) {
            if (this.timer < (Integer)this.crystalDelay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            Entity bcrystal = (Entity)mc.field_71441_e.field_72996_f.stream().filter((e) -> {
               return e instanceof EntityEnderCrystal;
            }).min(Comparator.comparing((c) -> {
               return c.func_70032_d(this._target);
            })).orElse((Object)null);
            if (bcrystal == null) {
               if (this.attempts < (Integer)this.hitDelay.getValue()) {
                  ++this.attempts;
                  return;
               }

               if (this.attempts < (Integer)this.tinpoDelay.getValue()) {
                  ++this.attempts;
                  return;
               }

               this.placedCrystal = false;
               this.placeList.add(this.breakPos);
               this.breaking = false;
               this.broke = false;
               this.attempts = 0;
            } else {
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(bcrystal));
               this.placedCrystal = false;
               this.placeList.add(this.breakPos);
               this.breaking = false;
               this.broke = false;
               this.attempts = 0;
            }
         }

      } else {
         this.disable();
      }
   }

   private void doPlace(int obby, int crystal) {
      this.placing = true;
      int oldslot;
      if (this.placeList.size() != 0) {
         oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
         mc.field_71439_g.field_71071_by.field_70461_c = obby;
         mc.field_71442_b.func_78765_e();
         BlockUtil.placeBlock((BlockPos)this.placeList.get(0), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), false, false);
         this.placeList.remove(0);
         mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
      } else if (!this.placedCrystal) {
         oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
         if (crystal != 999) {
            mc.field_71439_g.field_71071_by.field_70461_c = crystal;
         }

         mc.field_71442_b.func_78765_e();
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(this.b_crystal, EnumFacing.UP, mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
         mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
         this.placedCrystal = true;
      }

   }

   private void searchSpace() {
      BlockPos ppos = mc.field_71439_g.func_180425_c();
      BlockPos tpos = new BlockPos(this._target.field_70165_t, this._target.field_70163_u, this._target.field_70161_v);
      this.placeList = new ArrayList();
      BlockPos[] offset = new BlockPos[]{new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)};
      if (this.getBlock(new BlockPos(tpos.func_177958_n(), tpos.func_177956_o() + 3, tpos.func_177952_p())) == Blocks.field_150350_a && this.getBlock(new BlockPos(tpos.func_177958_n(), tpos.func_177956_o() + 4, tpos.func_177952_p())) == Blocks.field_150350_a) {
         ArrayList<BlockPos> posList = new ArrayList();

         for(int i = 0; i < offset.length; ++i) {
            BlockPos offsetPos = tpos.func_177971_a(offset[i]);
            Block block = this.getBlock(offsetPos);
            if (block != Blocks.field_150350_a && !(block instanceof BlockLiquid)) {
               posList.add(offsetPos);
            }
         }

         BlockPos base = (BlockPos)posList.stream().max(Comparator.comparing((b) -> {
            return this._target.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p());
         })).orElse((Object)null);
         if (base != null) {
            this.placeList.add(base);
            this.placeList.add(base.func_177982_a(0, 1, 0));
            this.placeList.add(base.func_177982_a(0, 2, 0));
            this.placeList.add(tpos.func_177982_a(0, 2, 0));
            this.breakPos = tpos.func_177982_a(0, 2, 0);
            this.b_crystal = tpos.func_177982_a(0, 2, 0);
         }
      }
   }

   private int findMaterials(Block b) {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).func_179223_d() == b) {
            return i;
         }
      }

      return -1;
   }

   private int findItem(Item item) {
      if (item == Items.field_185158_cP && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
         return 999;
      } else {
         for(int i = 0; i < 9; ++i) {
            if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == item) {
               return i;
            }
         }

         return -1;
      }
   }

   private Block getBlock(BlockPos b) {
      return mc.field_71441_e.func_180495_p(b).func_177230_c();
   }

   public static enum type {
      NEAREST,
      LOOKING;
   }

   public static enum mode {
      Vanilla,
      Packet;
   }
}
