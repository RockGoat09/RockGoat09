package ryo.mrbubblegum.nhack4.lite.combat;

import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockWeb;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import ryo.mrbubblegum.nhack4.impl.gui.LiteGui;
import ryo.mrbubblegum.nhack4.impl.util.DamageUtil;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.Feature;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.client.Notifications;
import ryo.mrbubblegum.nhack4.lite.client.PingBypass;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Bind;
import ryo.mrbubblegum.nhack4.system.setting.EnumConverter;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;
import ryo.mrbubblegum.nhack4.world.events.ProcessRightClickBlockEvent;

public class OffhandRewrite extends Module {
   private static OffhandRewrite instance;
   private final Queue<InventoryUtil.Task> taskList;
   private final Timer timer;
   private final Timer secondTimer;
   private final Timer thirdtimer;
   public OffhandRewrite.Mode2 currentMode;
   public int switchval;
   public int totems;
   public int crystals;
   public int gapples;
   public int lastTotemSlot;
   public int lastGappleSlot;
   public int lastCrystalSlot;
   public int lastObbySlot;
   public int lastWebSlot;
   public boolean holdingCrystal;
   public boolean holdingTotem;
   public boolean holdingGapple;
   public boolean didSwitchThisTick;
   public Setting<OffhandRewrite.page> pageSetting;
   public Setting<OffhandRewrite.Mode2> offhandmode;
   public Setting<Boolean> rightGap;
   public Setting<Boolean> swordgap;
   public Setting<Integer> maxSwitch;
   public Setting<Boolean> switchmode;
   public Setting<Bind> SwitchBind;
   public Setting<Float> switchHp;
   public Setting<Float> holeHP;
   public Setting<Boolean> armorCheck;
   public Setting<Integer> actions;
   public Setting<Boolean> crystalCheck;
   public Setting<Boolean> totemElytra;
   public Setting<Boolean> notfromhotbar;
   public Setting<Boolean> fallcheck;
   public Setting<Integer> falldistance;
   public Setting<Boolean> antiPing;
   public Setting<Integer> pingvalue;
   public Setting<Boolean> lagSwitch;
   public Setting<Boolean> debug;
   String s;
   private boolean second;
   private boolean switchedForHealthReason;

   public OffhandRewrite() {
      super("Offhand", "offhand module", Module.Category.COMBAT, true, false, false);
      this.pageSetting = this.register(new Setting("Page", OffhandRewrite.page.MAIN));
      this.offhandmode = this.register(new Setting("Offhand", OffhandRewrite.Mode2.TOTEMS, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.rightGap = this.register(new Setting("Right Click Gap", true, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.swordgap = this.register(new Setting("Sword Gap", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.maxSwitch = this.register(new Setting("Max Switch", 10, 0, 10, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.switchmode = this.register(new Setting("KeyMode", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.SwitchBind = this.register(new Setting("SwitchKey", new Bind(-1), (v) -> {
         return (Boolean)this.switchmode.getValue() && this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.switchHp = this.register(new Setting("SwitchHP", 16.5F, 0.1F, 36.0F, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.holeHP = this.register(new Setting("HoleHP", 8.0F, 0.1F, 36.0F, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.armorCheck = this.register(new Setting("ArmorCheck", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.actions = this.register(new Setting("Packets", 4, 1, 4, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.crystalCheck = this.register(new Setting("Crystal-Check", true, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MAIN;
      }));
      this.totemElytra = this.register(new Setting("TotemElytra", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.notfromhotbar = this.register(new Setting("NoHotbar", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.fallcheck = this.register(new Setting("FallCheck", true, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.falldistance = this.register(new Setting("FallDistance", 100, 1, 100, (v) -> {
         return (Boolean)this.fallcheck.getValue() && this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.antiPing = this.register(new Setting("Ping Predict", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.pingvalue = this.register(new Setting("Ping Value", 200, 0, 1000, (v) -> {
         return (Boolean)this.antiPing.getValue() && this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.lagSwitch = this.register(new Setting("Anti Lag", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.debug = this.register(new Setting("Messages", false, (v) -> {
         return this.pageSetting.getValue() == OffhandRewrite.page.MISC;
      }));
      this.s = "Offhand";
      instance = this;
      this.taskList = new ConcurrentLinkedQueue();
      this.timer = new Timer();
      this.secondTimer = new Timer();
      this.thirdtimer = new Timer();
      this.currentMode = OffhandRewrite.Mode2.TOTEMS;
      this.switchval = (Integer)this.maxSwitch.getValue();
      this.totems = 0;
      this.crystals = 0;
      this.gapples = 0;
      this.lastTotemSlot = -1;
      this.lastGappleSlot = -1;
      this.lastCrystalSlot = -1;
      this.lastObbySlot = -1;
      this.lastWebSlot = -1;
      this.holdingCrystal = false;
      this.holdingTotem = false;
      this.holdingGapple = false;
      this.didSwitchThisTick = false;
      this.second = false;
      this.switchedForHealthReason = false;
   }

   public static OffhandRewrite getInstance() {
      if (instance == null) {
         instance = new OffhandRewrite();
      }

      return instance;
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayer(ProcessRightClickBlockEvent event) {
      if (event.hand == EnumHand.MAIN_HAND && event.stack.func_77973_b() == Items.field_185158_cP && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71476_x != null && event.pos == mc.field_71476_x.func_178782_a()) {
         event.setCanceled(true);
         mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
         mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, EnumHand.OFF_HAND);
      }

   }

   @SubscribeEvent(
      priority = EventPriority.NORMAL,
      receiveCanceled = true
   )
   public void onKeyInput(KeyInputEvent event) {
      if (Keyboard.getEventKeyState() && (Boolean)this.switchmode.getValue() && ((Bind)this.SwitchBind.getValue()).getKey() == Keyboard.getEventKey()) {
         if (this.switchval < (Integer)this.maxSwitch.getValue()) {
            OffhandRewrite.Mode2 newMode = (OffhandRewrite.Mode2)EnumConverter.increaseEnum(this.currentMode);
            this.offhandmode.setValue(newMode);
            this.setMode(newMode);
            if ((Boolean)this.debug.getValue()) {
               TextComponentString textComponentString = new TextComponentString(Loader.commandManager.getClientMessage() + " §r§aSwitched offhand to " + newMode.toString());
               Notifications.mc.field_71456_v.func_146158_b().func_146234_a(textComponentString, this.s.length() * 10);
            }

            this.doSwitch();
         }

         if ((Boolean)this.debug.getValue()) {
            new TextComponentString(Loader.commandManager.getClientMessage() + " §r§aReached switch limit interval");
         }
      }

   }

   public void onUpdate() {
      if (this.timer.passedMs(50L)) {
         if (mc.field_71439_g != null && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && Mouse.isButtonDown(1)) {
            mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
            mc.field_71474_y.field_74313_G.field_74513_e = Mouse.isButtonDown(1);
         }

         this.switchval = 0;
      } else if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP) {
         mc.field_71474_y.field_74313_G.field_74513_e = false;
      }

      if (!nullCheck()) {
         this.doOffhand();
         if (this.secondTimer.passedMs(50L) && this.second) {
            this.second = false;
            this.timer.reset();
         }

         if (this.thirdtimer.passedDms(1000.0D)) {
            this.switchval = 0;
         }

      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (!Feature.fullNullCheck() && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && mc.field_71474_y.field_74313_G.func_151470_d()) {
         if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            CPacketPlayerTryUseItemOnBlock packet2 = (CPacketPlayerTryUseItemOnBlock)event.getPacket();
            if (packet2.func_187022_c() == EnumHand.MAIN_HAND) {
               if (this.timer.passedMs(50L)) {
                  mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
                  mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
               }

               event.setCanceled(true);
            }
         } else if (event.getPacket() instanceof CPacketPlayerTryUseItem && ((CPacketPlayerTryUseItem)event.getPacket()).func_187028_a() == EnumHand.OFF_HAND && !this.timer.passedMs(50L)) {
            event.setCanceled(true);
         }
      }

   }

   public String getDisplayInfo() {
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
         return "Crystal";
      } else if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
         return "Totem";
      } else {
         return mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao ? "Gapple" : null;
      }
   }

   public void doOffhand() {
      this.didSwitchThisTick = false;
      this.holdingCrystal = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP;
      this.holdingTotem = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY;
      this.holdingGapple = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao;
      this.totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_190929_cY;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (this.holdingTotem) {
         this.totems += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter((itemStack) -> {
            return itemStack.func_77973_b() == Items.field_190929_cY;
         }).mapToInt(ItemStack::func_190916_E).sum();
      }

      this.crystals = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_185158_cP;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (this.holdingCrystal) {
         this.crystals += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter((itemStack) -> {
            return itemStack.func_77973_b() == Items.field_185158_cP;
         }).mapToInt(ItemStack::func_190916_E).sum();
      }

      this.gapples = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_151153_ao;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (this.holdingGapple) {
         this.gapples += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter((itemStack) -> {
            return itemStack.func_77973_b() == Items.field_151153_ao;
         }).mapToInt(ItemStack::func_190916_E).sum();
      }

      ++this.switchval;
      if (this.switchval < 6) {
         this.doSwitch();
      }

   }

   public void doSwitch() {
      this.currentMode = OffhandRewrite.Mode2.TOTEMS;
      if ((Boolean)this.swordgap.getValue() && mc.field_71439_g.func_110143_aJ() > (Float)this.switchHp.getValue() && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword) {
         this.currentMode = OffhandRewrite.Mode2.GAPPLES;
      } else if ((Boolean)this.rightGap.getValue() && mc.field_71439_g.func_110143_aJ() > (Float)this.switchHp.getValue() && mc.field_71474_y.field_74313_G.func_151470_d() && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword && !(mc.field_71462_r instanceof GuiContainer) && !(mc.field_71462_r instanceof GuiChat) && !(mc.field_71462_r instanceof LiteGui)) {
         this.currentMode = OffhandRewrite.Mode2.GAPPLES;
      } else if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS || this.offhandmode.getValue() != OffhandRewrite.Mode2.CRYSTALS || (!EntityUtil.isSafe(mc.field_71439_g) || !(EntityUtil.getHealth(mc.field_71439_g, true) > (Float)this.holeHP.getValue())) && !(EntityUtil.getHealth(mc.field_71439_g, true) > (Float)this.switchHp.getValue())) {
         if (this.currentMode != OffhandRewrite.Mode2.GAPPLES && this.offhandmode.getValue() == OffhandRewrite.Mode2.GAPPLES && (EntityUtil.isSafe(mc.field_71439_g) && EntityUtil.getHealth(mc.field_71439_g, true) > (Float)this.holeHP.getValue() || EntityUtil.getHealth(mc.field_71439_g, true) > (Float)this.switchHp.getValue())) {
            this.currentMode = OffhandRewrite.Mode2.GAPPLES;
         }
      } else {
         this.currentMode = OffhandRewrite.Mode2.CRYSTALS;
      }

      if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS && this.crystals == 0) {
         if (this.gapples != 0) {
            this.setMode(OffhandRewrite.Mode2.GAPPLES);
         }

         this.setMode(OffhandRewrite.Mode2.TOTEMS);
      }

      if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS && (!EntityUtil.isSafe(mc.field_71439_g) && EntityUtil.getHealth(mc.field_71439_g, true) <= (Float)this.switchHp.getValue() || EntityUtil.getHealth(mc.field_71439_g, true) <= (Float)this.holeHP.getValue())) {
         if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS) {
            this.switchedForHealthReason = true;
         }

         this.setMode(OffhandRewrite.Mode2.TOTEMS);
      }

      if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS && (!EntityUtil.isSafe(mc.field_71439_g) && EntityUtil.getHealth(mc.field_71439_g, true) <= (Float)this.switchHp.getValue() || EntityUtil.getHealth(mc.field_71439_g, true) <= (Float)this.holeHP.getValue())) {
         if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS) {
            this.switchedForHealthReason = true;
         }

         this.setMode(OffhandRewrite.Mode2.TOTEMS);
      }

      if (mc.field_71439_g.field_70160_al && (Boolean)this.totemElytra.getValue() && mc.field_71439_g.func_184613_cA() && mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_185160_cR) {
         this.setMode(OffhandRewrite.Mode2.TOTEMS);
      }

      if (mc.field_71439_g.field_70143_R > (float)(Integer)this.falldistance.getValue() && (Boolean)this.fallcheck.getValue()) {
         this.setMode(OffhandRewrite.Mode2.TOTEMS);
      }

      if (this.switchedForHealthReason && (EntityUtil.isSafe(mc.field_71439_g) && EntityUtil.getHealth(mc.field_71439_g, true) > (Float)this.holeHP.getValue() || EntityUtil.getHealth(mc.field_71439_g, true) > (Float)this.switchHp.getValue())) {
         this.setMode(this.currentMode);
         this.switchedForHealthReason = false;
      }

      if (this.currentMode == OffhandRewrite.Mode2.CRYSTALS && (Boolean)this.armorCheck.getValue() && (mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_190931_a || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() == Items.field_190931_a || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() == Items.field_190931_a || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() == Items.field_190931_a)) {
         this.setMode(this.currentMode);
      }

      if ((Boolean)this.crystalCheck.getValue() && this.calcCrystal()) {
         if ((Boolean)this.debug.getValue()) {
            TextComponentString textComponentString = new TextComponentString(Loader.commandManager.getClientMessage() + " §r§aSwitched to totem because lethal crystal");
            Notifications.mc.field_71456_v.func_146158_b().func_146234_a(textComponentString, this.s.length() * 10);
         }

         this.switchedForHealthReason = true;
         this.currentMode = OffhandRewrite.Mode2.TOTEMS;
      }

      if (!(mc.field_71462_r instanceof GuiContainer) || mc.field_71462_r instanceof GuiInventory) {
         if ((Boolean)this.antiPing.getValue() && (PingBypass.getInstance().isConnected() ? PingBypass.getInstance().getServerPing() : (long)Loader.serverManager.getPing()) > (long)(Integer)this.pingvalue.getValue()) {
            this.setMode(OffhandRewrite.Mode2.TOTEMS);
         }

         if ((Boolean)this.lagSwitch.getValue() && Loader.serverManager.isServerNotResponding()) {
            this.setMode(OffhandRewrite.Mode2.TOTEMS);
         }

         Item currentOffhandItem = mc.field_71439_g.func_184592_cb().func_77973_b();
         int i;
         switch(this.currentMode) {
         case TOTEMS:
            if (this.totems > 0 && !this.holdingTotem) {
               this.lastTotemSlot = InventoryUtil.findItemInventorySlot(Items.field_190929_cY, false);
               i = this.getLastSlot(currentOffhandItem, this.lastTotemSlot);
               this.putItemInOffhand(this.lastTotemSlot, i);
            }
            break;
         case GAPPLES:
            if (this.gapples > 0 && !this.holdingGapple) {
               this.lastGappleSlot = InventoryUtil.findItemInventorySlot(Items.field_151153_ao, false);
               i = this.getLastSlot(currentOffhandItem, this.lastGappleSlot);
               this.putItemInOffhand(this.lastGappleSlot, i);
            }
            break;
         default:
            if (this.crystals > 0 && !this.holdingCrystal) {
               this.lastCrystalSlot = InventoryUtil.findItemInventorySlot(Items.field_185158_cP, false);
               i = this.getLastSlot(currentOffhandItem, this.lastCrystalSlot);
               this.putItemInOffhand(this.lastCrystalSlot, i);
            }
         }

         for(i = 0; i < (Integer)this.actions.getValue(); ++i) {
            InventoryUtil.Task task = (InventoryUtil.Task)this.taskList.poll();
            if (task != null) {
               task.run();
               if (task.isSwitching()) {
                  this.didSwitchThisTick = true;
               }
            }
         }

      }
   }

   private int getLastSlot(Item item, int slotIn) {
      if (item == Items.field_185158_cP) {
         return this.lastCrystalSlot;
      } else if (item == Items.field_151153_ao) {
         return this.lastGappleSlot;
      } else if (item == Items.field_190929_cY) {
         return this.lastTotemSlot;
      } else if (InventoryUtil.isBlock(item, BlockObsidian.class)) {
         return this.lastObbySlot;
      } else if (InventoryUtil.isBlock(item, BlockWeb.class)) {
         return this.lastWebSlot;
      } else {
         return item == Items.field_190931_a ? -1 : slotIn;
      }
   }

   private void putItemInOffhand(int slotIn, int slotOut) {
      if (slotIn != -1 && this.taskList.isEmpty()) {
         this.taskList.add(new InventoryUtil.Task(slotIn));
         this.taskList.add(new InventoryUtil.Task(45));
         this.taskList.add(new InventoryUtil.Task(slotOut));
         this.taskList.add(new InventoryUtil.Task());
      }

   }

   public void setMode(OffhandRewrite.Mode2 mode) {
      this.currentMode = this.currentMode == mode ? OffhandRewrite.Mode2.TOTEMS : mode;
   }

   public boolean calcCrystal() {
      Iterator var1 = mc.field_71441_e.field_72996_f.iterator();

      Entity t;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         t = (Entity)var1.next();
      } while(!(t instanceof EntityEnderCrystal) || !(mc.field_71439_g.func_174818_b(t.func_180425_c()) <= 36.0D) || !(DamageUtil.calculateDamage((Entity)t, mc.field_71439_g) >= mc.field_71439_g.func_110143_aJ()));

      return true;
   }

   public static enum Mode2 {
      TOTEMS,
      GAPPLES,
      CRYSTALS;
   }

   public static enum page {
      MAIN,
      MISC;
   }
}
