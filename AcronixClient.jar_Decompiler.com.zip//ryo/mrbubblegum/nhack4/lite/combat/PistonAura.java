package ryo.mrbubblegum.nhack4.lite.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import ryo.mrbubblegum.nhack4.impl.util.BlockUtil;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class PistonAura extends Module {
   public EntityPlayer target = null;
   private final Setting<PistonAura.redstone> redstoneType;
   private final Setting<Integer> start_delay;
   private final Setting<Integer> place_delay;
   private final Setting<Integer> crystal_delay;
   private final Setting<Integer> break_delay;
   private final Setting<Integer> break_attempts;
   private final Setting<PistonAura.types> target_type;
   private final Setting<Integer> MaxY;
   private final Setting<Float> range;
   private final Setting<PistonAura.mode> trap;
   private final Setting<Boolean> packetPlace;
   private final Setting<PistonAura.arm> swingArm;
   private final Setting<Boolean> antiweakness;
   private final Setting<Boolean> toggle;
   private final Setting<Boolean> debug;
   private boolean r_redstone;
   private int b_stage;
   private BlockPos b_crystal;
   private BlockPos b_piston;
   private BlockPos b_redStone;
   private boolean p_crystal;
   private boolean p_piston;
   private boolean p_redstone;
   private final boolean s_crystal;
   private boolean u_crystal;
   private int attempts;
   private int crystalId;
   private int trapprogress;
   private int timer;
   private boolean autoGG;
   private int debug_stage;
   private List<BlockPos> c_crystal;
   private List<BlockPos> c_piston;
   private List<BlockPos> c_redStone;
   private boolean isTorch;

   public PistonAura() {
      super("PistonCrystal", "no need to explain", Module.Category.COMBAT, true, false, false);
      this.redstoneType = this.register(new Setting("Redstone", PistonAura.redstone.Torch, " redstone type"));
      this.start_delay = this.register(new Setting("StartDelay", 1, 0, 10));
      this.place_delay = this.register(new Setting("PlaceDelay", 1, 0, 10));
      this.crystal_delay = this.register(new Setting("CrystalDelay", 1, 0, 10));
      this.break_delay = this.register(new Setting("BreakDelay", 1, 0, 10));
      this.break_attempts = this.register(new Setting("BreakAttempts", 2, 1, 10));
      this.target_type = this.register(new Setting("Target", PistonAura.types.Looking));
      this.MaxY = this.register(new Setting("MaxY", 2, 1, 5));
      this.range = this.register(new Setting("Range", 5.2F, 1.0F, 15.0F));
      this.trap = this.register(new Setting("TrapMode", PistonAura.mode.Smart));
      this.packetPlace = this.register(new Setting("PacketPlace", false));
      this.swingArm = this.register(new Setting("SwingArm", PistonAura.arm.MainHand));
      this.antiweakness = this.register(new Setting("AntiWeakness", false));
      this.toggle = this.register(new Setting("Toggle", true));
      this.debug = this.register(new Setting("Debug", true));
      this.r_redstone = false;
      this.b_stage = 0;
      this.b_crystal = null;
      this.b_piston = null;
      this.b_redStone = null;
      this.p_crystal = false;
      this.p_piston = false;
      this.p_redstone = false;
      this.s_crystal = false;
      this.u_crystal = false;
      this.attempts = 0;
      this.crystalId = 0;
      this.trapprogress = 0;
      this.timer = 0;
      this.autoGG = false;
      this.debug_stage = -1;
      this.c_crystal = null;
      this.c_piston = null;
      this.c_redStone = null;
      this.isTorch = false;
   }

   public void onEnable() {
      this.Init();
      this.autoGG = false;
   }

   public void onTick() {
      try {
         int oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
         int pickaxe = this.findItem(Items.field_151046_w);
         int crystal = this.findItem(Items.field_185158_cP);
         int piston = this.findMaterials(Blocks.field_150331_J);
         if (piston == -1) {
            piston = this.findMaterials(Blocks.field_150320_F);
         }

         int redstone2 = this.findMaterials(Blocks.field_150429_aA);
         this.isTorch = true;
         if (this.redstoneType.getValue() == PistonAura.redstone.Block || this.redstoneType.getValue() == PistonAura.redstone.Both && redstone2 == -1) {
            redstone2 = this.findMaterials(Blocks.field_150451_bX);
            this.isTorch = false;
         }

         int obsidian = this.findMaterials(Blocks.field_150343_Z);
         int sword = this.findItem(Items.field_151048_u);
         if ((Boolean)this.antiweakness.getValue() && sword == -1) {
            sword = pickaxe;
         }

         label301: {
            if (pickaxe != -1 && crystal != -1 && piston != -1 && redstone2 != -1 && obsidian != -1) {
               this.debug_stage = 0;
               if (this.target == null) {
                  if (this.target_type.getValue() == PistonAura.types.Nearest) {
                     this.target = (EntityPlayer)mc.field_71441_e.field_73010_i.stream().filter((p) -> {
                        return p.field_145783_c != mc.field_71439_g.field_145783_c;
                     }).min(Comparator.comparing((p) -> {
                        return mc.field_71439_g.func_70032_d(p);
                     })).orElse((Object)null);
                  }

                  if (this.target_type.getValue() == PistonAura.types.Looking) {
                  }

                  if (this.target == null) {
                     this.disable();
                     return;
                  }
               }

               this.debug_stage = 1;
               if (this.b_crystal != null && this.b_piston != null && this.b_redStone != null) {
                  break label301;
               }

               this.searchSpace();
               if (this.b_crystal != null && this.b_piston != null && this.b_redStone != null) {
                  break label301;
               }

               if ((Boolean)this.toggle.getValue()) {
                  if ((Boolean)this.debug.getValue()) {
                     Command.sendMessage("Not found space! disabling...");
                  }

                  this.disable();
               }

               return;
            }

            if ((Boolean)this.debug.getValue()) {
               Command.sendMessage("Missing Materials! disabling...");
            }

            this.disable();
            return;
         }

         this.debug_stage = 2;
         if (this.getRange(this.b_crystal) > (Float)this.range.getValue() || this.getRange(this.b_piston) > (Float)this.range.getValue() || this.getRange(this.b_redStone) > (Float)this.range.getValue()) {
            if ((Boolean)this.debug.getValue()) {
               Command.sendMessage("Out of range! disabling...");
            }

            if ((Boolean)this.toggle.getValue()) {
               this.disable();
            }

            return;
         }

         this.debug_stage = 3;
         boolean doTrap = this.trap.getValue() == PistonAura.mode.Force || this.trap.getValue() == PistonAura.mode.Smart && Loader.holeManager.isSafe(mc.field_71439_g.func_180425_c()) && this.b_piston.func_177956_o() == mc.field_71439_g.func_180425_c().func_177956_o() + 1;
         if (doTrap && mc.field_71441_e.func_180495_p(new BlockPos(this.target.field_70165_t, this.target.field_70163_u + 2.0D, this.target.field_70161_v)).func_177230_c() == Blocks.field_150350_a) {
            if (this.timer < (Integer)this.place_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            mc.field_71439_g.field_71071_by.field_70461_c = obsidian;
            mc.field_71442_b.func_78765_e();
            BlockPos first = new BlockPos(Math.floor(this.target.field_70165_t) - (double)this.b_crystal.func_177958_n() + this.target.field_70165_t, (double)this.b_piston.func_177956_o(), Math.floor(this.target.field_70161_v) - (double)this.b_crystal.func_177952_p() + this.target.field_70161_v);
            if (this.trapprogress != 0 && this.trapprogress != 1) {
               BlockUtil.placeBlock(new BlockPos(this.target.field_70165_t, this.target.field_70163_u + 2.0D, this.target.field_70161_v), EnumHand.MAIN_HAND, true, (Boolean)this.packetPlace.getValue(), false);
            } else {
               BlockPos pos = first;
               if (this.trapprogress == 1) {
                  pos = new BlockPos(first.func_177958_n(), first.func_177956_o() + 1, first.func_177952_p());
               }

               BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, true, (Boolean)this.packetPlace.getValue(), false);
            }

            ++this.trapprogress;
            return;
         }

         this.debug_stage = 4;
         this.debug_stage = 5;
         if (this.getBlock(this.b_piston.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150350_a) {
            mc.field_71439_g.field_71071_by.field_70461_c = obsidian;
            mc.field_71442_b.func_78765_e();
            if (this.timer < (Integer)this.place_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            BlockUtil.placeBlock(this.b_piston.func_177982_a(0, -1, 0), EnumHand.MAIN_HAND, true, (Boolean)this.packetPlace.getValue(), false);
            return;
         }

         if (this.getBlock(this.b_redStone.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150350_a && this.isTorch) {
            mc.field_71439_g.field_71071_by.field_70461_c = obsidian;
            mc.field_71442_b.func_78765_e();
            if (this.timer < (Integer)this.place_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            BlockUtil.placeBlock(this.b_redStone.func_177982_a(0, -1, 0), EnumHand.MAIN_HAND, true, (Boolean)this.packetPlace.getValue(), false);
            return;
         }

         this.debug_stage = 6;
         if (this.r_redstone) {
            if (this.getBlock(this.b_redStone).func_177230_c() == Blocks.field_150350_a) {
               this.r_redstone = false;
               this.b_stage = 0;
               this.p_crystal = false;
               this.p_redstone = false;
               return;
            }

            mc.field_71439_g.field_71071_by.field_70461_c = pickaxe;
            mc.field_71442_b.func_78765_e();
            if (this.b_stage == 0) {
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, this.b_redStone, EnumFacing.DOWN));
               this.b_stage = 1;
            } else if (this.b_stage == 1) {
               mc.field_71442_b.func_180512_c(this.b_redStone, EnumFacing.DOWN);
            }

            return;
         }

         this.debug_stage = 7;
         if (!this.p_piston) {
            if (this.timer < (Integer)this.place_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            mc.field_71439_g.field_71071_by.field_70461_c = piston;
            mc.field_71442_b.func_78765_e();
            float[] angle = MathUtil.calcAngle(new Vec3d(this.b_piston), new Vec3d(this.b_crystal));
            mc.field_71439_g.field_71174_a.func_147297_a(new Rotation(angle[0] + 180.0F, angle[1], true));
            BlockUtil.placeBlock(this.b_piston, EnumHand.MAIN_HAND, false, (Boolean)this.packetPlace.getValue(), false);
            this.p_piston = true;
         }

         this.debug_stage = 8;
         if (!this.p_crystal) {
            if (this.timer < (Integer)this.crystal_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            if (crystal != 999) {
               mc.field_71439_g.field_71071_by.field_70461_c = crystal;
            }

            mc.field_71442_b.func_78765_e();
            AutoCrystal.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(this.b_crystal, EnumFacing.UP, mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
            this.p_crystal = true;
         }

         this.debug_stage = 9;
         if (!this.p_redstone) {
            if (this.timer < (Integer)this.place_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            mc.field_71439_g.field_71071_by.field_70461_c = redstone2;
            mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(this.b_redStone, EnumHand.MAIN_HAND, true, (Boolean)this.packetPlace.getValue(), false);
            this.p_redstone = true;
         }

         this.debug_stage = 10;
         if (this.p_crystal && this.p_piston && this.p_redstone && !this.u_crystal) {
            if (this.timer < (Integer)this.break_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            Entity t_crystal = (Entity)mc.field_71441_e.field_72996_f.stream().filter((p) -> {
               return p instanceof EntityEnderCrystal;
            }).min(Comparator.comparing((c) -> {
               return this.target.func_70032_d(c);
            })).orElse((Object)null);
            if (t_crystal == null) {
               if (this.attempts < (Integer)this.break_attempts.getValue()) {
                  ++this.attempts;
                  return;
               }

               this.attempts = 0;
               if ((Boolean)this.debug.getValue()) {
                  Command.sendMessage("Not found crystal! retrying...");
               }

               this.r_redstone = true;
               this.b_stage = 0;
               return;
            }

            this.crystalId = t_crystal.field_145783_c;
            if ((Boolean)this.antiweakness.getValue()) {
               mc.field_71439_g.field_71071_by.field_70461_c = sword;
               mc.field_71442_b.func_78765_e();
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(t_crystal));
            if (this.swingArm.getValue() != PistonAura.arm.None) {
               mc.field_71439_g.func_184609_a(this.swingArm.getValue() == PistonAura.arm.MainHand ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND);
            }

            this.u_crystal = true;
         }

         this.debug_stage = 11;
         if (this.u_crystal) {
            if (this.timer < (Integer)this.break_delay.getValue()) {
               ++this.timer;
               return;
            }

            this.timer = 0;
            this.Init();
            return;
         }

         mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
         mc.field_71442_b.func_78765_e();
      } catch (Exception var12) {
         if ((Boolean)this.debug.getValue()) {
            Command.sendMessage("Has Error! : " + var12);
            Command.sendMessage("Stage : " + this.debug_stage);
            Command.sendMessage("Trying to init...");
         }

         this.Init();
      }

   }

   private int findMaterials(Block b) {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock && ((ItemBlock)mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).func_179223_d() == b) {
            return i;
         }
      }

      return -1;
   }

   private int findItem(Item item) {
      if (item == Items.field_185158_cP && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
         return 999;
      } else {
         for(int i = 0; i < 9; ++i) {
            if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == item) {
               return i;
            }
         }

         return -1;
      }
   }

   private void searchSpace() {
      BlockPos floored_pos = new BlockPos(this.target.field_70165_t, this.target.field_70163_u, this.target.field_70161_v);
      BlockPos[] offset = new BlockPos[]{new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)};
      this.debug_stage = -2;

      for(int y = 0; y < (Integer)this.MaxY.getValue() + 1; ++y) {
         for(int i = 0; i < offset.length; ++i) {
            this.sp(offset[i], y, floored_pos);
         }
      }

      this.debug_stage = -3;
      this.b_crystal = (BlockPos)this.c_crystal.stream().min(Comparator.comparing((b) -> {
         return mc.field_71439_g.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p());
      })).orElse((Object)null);
      this.b_piston = (BlockPos)this.c_piston.stream().min(Comparator.comparing((b) -> {
         return this.b_crystal.func_177951_i(b);
      })).orElse((Object)null);
      if (this.b_piston != null) {
         this.b_redStone = (BlockPos)this.c_redStone.stream().filter((b) -> {
            return this.b_piston.func_185332_f(b.func_177958_n(), b.func_177956_o(), b.func_177952_p()) < 2.0D;
         }).min(Comparator.comparing((b) -> {
            return this.b_crystal.func_177951_i(b);
         })).orElse((Object)null);
      }

      this.debug_stage = -4;
      if (this.b_crystal != null) {
         if (this.getBlock(this.b_crystal.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150332_K && this.getBlock(this.b_redStone).func_177230_c() == this.getRedStoneBlock()) {
            this.r_redstone = true;
            this.b_stage = 0;
         }

         this.debug_stage = -5;
      }
   }

   private void sp(BlockPos offset, int offset_y, BlockPos enemy_pos) {
      BlockPos mypos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
      boolean v_crystal = false;
      boolean v_piston = false;
      boolean v_redstone = false;
      BlockPos pre_crystal = new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n(), enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y, enemy_pos.func_177952_p() + offset.func_177952_p());
      BlockPos pre_piston = new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 2, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 1, enemy_pos.func_177952_p() + offset.func_177952_p() * 2);
      BlockPos pre_redstone = new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 1, enemy_pos.func_177952_p() + offset.func_177952_p() * 3);
      if (this.checkBlock(this.getBlock(pre_crystal).func_177230_c()) && this.isAir(this.getBlock(pre_crystal.func_177982_a(0, 1, 0)).func_177230_c()) && this.isAir(this.getBlock(pre_crystal.func_177982_a(0, 2, 0)).func_177230_c())) {
         v_crystal = true;
      }

      if (this.isAir(this.getBlock(pre_piston).func_177230_c())) {
         v_piston = true;
      }

      if (this.isTorch) {
         BlockPos[] t_offset = new BlockPos[]{new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)};
         ArrayList<BlockPos> pre_redstone_place = new ArrayList();
         Object tmp = null;

         for(int o = 0; o < t_offset.length; ++o) {
            BlockPos pre_redstone_offset = pre_piston.func_177971_a(t_offset[o]);
            if (this.isAir(this.getBlock(pre_redstone_offset).func_177230_c()) && (pre_redstone_offset.func_177958_n() != mypos.func_177958_n() || pre_redstone_offset.func_177956_o() != mypos.func_177956_o() && pre_redstone_offset.func_177956_o() != mypos.func_177956_o() + 1 || pre_redstone_offset.func_177952_p() != mypos.func_177952_p()) && pre_crystal.func_185332_f(pre_redstone_offset.func_177958_n(), pre_redstone_offset.func_177956_o(), pre_redstone_offset.func_177952_p()) > 1.0D) {
               pre_redstone_place.add(pre_redstone_offset);
            }
         }

         if (this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 3)).func_177230_c() == Blocks.field_150350_a && this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 1, enemy_pos.func_177952_p() + offset.func_177952_p() * 3)).func_177230_c() == Blocks.field_150343_Z) {
            pre_redstone_place.add(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 3));
         }

         if (this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 2, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 3)).func_177230_c() == Blocks.field_150343_Z) {
            pre_redstone_place.add(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 2, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 2));
         }

         if ((pre_redstone = (BlockPos)pre_redstone_place.stream().min(Comparator.comparing((b) -> {
            return mc.field_71439_g.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p());
         })).orElse((Object)null)) != null) {
            v_redstone = true;
         }
      } else if (this.isAir(this.getBlock(pre_redstone).func_177230_c())) {
         v_redstone = true;
      }

      if (pre_piston.func_177958_n() == mypos.func_177958_n() && (pre_piston.func_177956_o() == mypos.func_177956_o() || pre_piston.func_177956_o() == mypos.func_177956_o() + 1) && pre_piston.func_177952_p() == mypos.func_177952_p()) {
         v_piston = false;
      }

      if (pre_redstone != null && pre_redstone.func_177958_n() == mypos.func_177958_n() && (pre_redstone.func_177956_o() == mypos.func_177956_o() || pre_redstone.func_177956_o() == mypos.func_177956_o() + 1) && pre_redstone.func_177952_p() == mypos.func_177952_p()) {
         v_redstone = false;
      }

      if (mypos.func_185332_f(pre_piston.func_177958_n(), mypos.func_177956_o(), pre_piston.func_177952_p()) < 3.1D && pre_piston.func_177956_o() > mypos.func_177956_o() + 1) {
         v_piston = false;
      }

      if (this.getBlock(pre_crystal.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150332_K && (this.getBlock(pre_redstone).func_177230_c() == Blocks.field_150451_bX || this.getBlock(pre_redstone).func_177230_c() == Blocks.field_150429_aA)) {
         v_piston = true;
         v_crystal = true;
         v_redstone = true;
      }

      if (v_crystal && v_piston && v_redstone) {
         this.c_crystal.add(pre_crystal);
         this.c_piston.add(pre_piston);
         this.c_redStone.add(pre_redstone);
      }

   }

   private void Init() {
      this.target = null;
      this.b_crystal = null;
      this.b_piston = null;
      this.b_redStone = null;
      this.c_crystal = new ArrayList();
      this.c_piston = new ArrayList();
      this.c_redStone = new ArrayList();
      this.p_crystal = false;
      this.p_piston = false;
      this.p_redstone = false;
      this.u_crystal = false;
      this.attempts = 0;
      this.r_redstone = false;
      this.b_stage = 0;
      this.trapprogress = 0;
      this.timer = 0;
      this.crystalId = 0;
      this.debug_stage = -1;
   }

   private float getRange(BlockPos t) {
      return (float)mc.field_71439_g.func_70011_f((double)t.func_177958_n(), (double)t.func_177956_o(), (double)t.func_177952_p());
   }

   private boolean isAir(Block b) {
      return b == Blocks.field_150350_a;
   }

   private boolean checkBlock(Block b) {
      return b == Blocks.field_150343_Z || b == Blocks.field_150357_h;
   }

   private IBlockState getBlock(BlockPos o) {
      return mc.field_71441_e.func_180495_p(o);
   }

   private double f(double v) {
      return Math.floor(v);
   }

   private Block getRedStoneBlock() {
      return this.isTorch ? Blocks.field_150429_aA : Blocks.field_150451_bX;
   }

   private static enum types {
      Nearest,
      Looking;
   }

   private static enum arm {
      MainHand,
      OffHand,
      None;
   }

   private static enum redstone {
      Block,
      Torch,
      Both;
   }

   private static enum mode {
      Smart,
      Force,
      None;
   }
}
