package ryo.mrbubblegum.nhack4.lite.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import ryo.mrbubblegum.nhack4.impl.util.BlockUtil;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.impl.util.utils.EntityUtils;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class PistonPush extends Module {
   private final Setting<Boolean> rotate = this.register(new Setting("Rotate", true));
   private final Setting<Boolean> disable = this.register(new Setting("Disable", true));
   private final Setting<Boolean> noGhost = this.register(new Setting("Packet", false));
   private final Setting<Integer> deay = this.register(new Setting("Deay", 30, 0, 100));
   private final Setting<Double> range = this.register(new Setting("Range", 4.0D, 0.0D, 10.0D));
   private int tick;
   private boolean gs = true;

   public PistonPush() {
      super("Elevator", "worst than private one", Module.Category.COMBAT, true, false, false);
   }

   public void onUpdate() {
      if (this.tick != 90 && this.tick++ >= (Integer)this.deay.getValue()) {
         this.tick = 0;
         this.gs = true;
      }

      if (mc.field_71439_g != null && !mc.field_71439_g.field_70128_L) {
         if (!nullCheck()) {
            if ((Boolean)this.disable.getValue()) {
               this.disable();
            }

            if (InventoryUtil.findHotbarBlock((Block)Blocks.field_150331_J) == -1) {
               if ((Boolean)this.disable.getValue()) {
                  Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No PISTON...");
               }

            } else if (InventoryUtil.findHotbarBlock(Blocks.field_150451_bX) == -1) {
               if ((Boolean)this.disable.getValue()) {
                  Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No REDSTONE BLOCK...");
               }

            } else if (InventoryUtil.findHotbarBlock(Blocks.field_150343_Z) == -1) {
               if ((Boolean)this.disable.getValue()) {
                  Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No PISTON...");
               }

            } else {
               EntityPlayer target = this.getTarget((Double)this.range.getValue(), true);
               if (this.gs) {
                  this.gs = false;
                  if (target != null && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v)).func_177230_c() != Blocks.field_150350_a) {
                     int imp;
                     if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 2.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t + 1.0D, target.field_70163_u + 1.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t - 1.0D, target.field_70163_u + 1.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t + 2.0D, target.field_70163_u + 1.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a) {
                        if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t + 2.0D, target.field_70163_u, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a) {
                           imp = mc.field_71439_g.field_71071_by.field_70461_c;
                           mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150343_Z);
                           BlockUtil.placeBlock(new BlockPos(target.field_70165_t + 2.0D, target.field_70163_u, target.field_70161_v), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                           mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        }

                        imp = mc.field_71439_g.field_71071_by.field_70461_c;
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150451_bX);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t + 2.0D, target.field_70163_u + 1.0D, target.field_70161_v), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock((Block)Blocks.field_150331_J);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t + 1.0D, target.field_70163_u + 1.0D, target.field_70161_v), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        return;
                     }

                     if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 2.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v + 1.0D)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v - 1.0D)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v + 2.0D)).func_177230_c() == Blocks.field_150350_a) {
                        if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v + 2.0D)).func_177230_c() == Blocks.field_150350_a) {
                           imp = mc.field_71439_g.field_71071_by.field_70461_c;
                           mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150343_Z);
                           BlockUtil.placeBlock(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v + 2.0D), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                           mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        }

                        imp = mc.field_71439_g.field_71071_by.field_70461_c;
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150451_bX);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v + 2.0D), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock((Block)Blocks.field_150331_J);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v + 1.0D), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        return;
                     }

                     if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 2.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v - 1.0D)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v + 1.0D)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v - 2.0D)).func_177230_c() == Blocks.field_150350_a) {
                        if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v - 2.0D)).func_177230_c() == Blocks.field_150350_a) {
                           imp = mc.field_71439_g.field_71071_by.field_70461_c;
                           mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150343_Z);
                           BlockUtil.placeBlock(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v - 2.0D), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                           mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        }

                        imp = mc.field_71439_g.field_71071_by.field_70461_c;
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150451_bX);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v - 2.0D), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock((Block)Blocks.field_150331_J);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t, target.field_70163_u + 1.0D, target.field_70161_v - 1.0D), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        return;
                     }

                     if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t, target.field_70163_u + 2.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t - 1.0D, target.field_70163_u + 1.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t + 1.0D, target.field_70163_u + 1.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a && mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t - 2.0D, target.field_70163_u + 1.0D, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a) {
                        if (mc.field_71441_e.func_180495_p(new BlockPos(target.field_70165_t - 2.0D, target.field_70163_u, target.field_70161_v)).func_177230_c() == Blocks.field_150350_a) {
                           imp = mc.field_71439_g.field_71071_by.field_70461_c;
                           mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150343_Z);
                           BlockUtil.placeBlock(new BlockPos(target.field_70165_t - 2.0D, target.field_70163_u, target.field_70161_v), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                           mc.field_71439_g.field_71071_by.field_70461_c = imp;
                        }

                        imp = mc.field_71439_g.field_71071_by.field_70461_c;
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock(Blocks.field_150451_bX);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t - 2.0D, target.field_70163_u + 1.0D, target.field_70161_v), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.findHotbarBlock((Block)Blocks.field_150331_J);
                        BlockUtil.placeBlock(new BlockPos(target.field_70165_t - 1.0D, target.field_70163_u + 1.0D, target.field_70161_v), EnumHand.MAIN_HAND, (Boolean)this.rotate.getValue(), (Boolean)this.noGhost.getValue(), true);
                        mc.field_71439_g.field_71071_by.field_70461_c = imp;
                     }
                  }
               }

            }
         }
      }
   }

   private EntityPlayer getTarget(double range, boolean trapped) {
      EntityPlayer target = null;
      double distance = Math.pow(range, 2.0D) + 1.0D;
      Iterator var7 = AutoTrap.mc.field_71441_e.field_73010_i.iterator();

      while(true) {
         EntityPlayer player;
         do {
            do {
               if (!var7.hasNext()) {
                  return target;
               }

               player = (EntityPlayer)var7.next();
            } while(EntityUtil.isntValid(player, range));
         } while(trapped && EntityUtils.isTrapped(player, false, false, false, false, false));

         if (!(Loader.speedManager.getPlayerSpeed(player) > 10.0D)) {
            if (target == null) {
               target = player;
               distance = AutoTrap.mc.field_71439_g.func_70068_e(player);
            } else if (AutoTrap.mc.field_71439_g.func_70068_e(player) < distance) {
               target = player;
               distance = AutoTrap.mc.field_71439_g.func_70068_e(player);
            }
         }
      }
   }
}
