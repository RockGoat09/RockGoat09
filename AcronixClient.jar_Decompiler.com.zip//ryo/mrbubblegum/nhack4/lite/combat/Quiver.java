package ryo.mrbubblegum.nhack4.lite.combat;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTippedArrow;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.math.BlockPos;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.impl.util.RotationUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Feature;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class Quiver extends Module {
   private final Setting<Integer> delay = this.register(new Setting("Delay", 0, 0, 500));
   private final Setting<Integer> holdLength = this.register(new Setting("Hold Length", 100, 100, 1000));
   private final Setting<Quiver.mainEnum> main;
   private final Setting<Quiver.mainEnum> secondary;
   private final Timer delayTimer;
   private final Timer holdTimer;
   private int stage;
   private ArrayList<Integer> map;
   private int strSlot;
   private int speedSlot;
   private int oldSlot;

   public Quiver() {
      super("SelfArrow", "shoots yourself with gud arrows", Module.Category.COMBAT, true, false, false);
      this.main = this.register(new Setting("Main", Quiver.mainEnum.SPEED));
      this.secondary = this.register(new Setting("Secondary", Quiver.mainEnum.STRENGTH));
      this.delayTimer = new Timer();
      this.holdTimer = new Timer();
      this.strSlot = -1;
      this.speedSlot = -1;
      this.oldSlot = 1;
   }

   public void onEnable() {
      if (!Feature.nullCheck()) {
         InventoryUtil.switchToHotbarSlot(ItemBow.class, false);
         this.clean();
         this.oldSlot = Util.mc.field_71439_g.field_71071_by.field_70461_c;
         Util.mc.field_71474_y.field_74313_G.field_74513_e = false;
      }
   }

   public void onDisable() {
      if (!Feature.nullCheck()) {
         InventoryUtil.switchToHotbarSlot(this.oldSlot, false);
         Util.mc.field_71474_y.field_74313_G.field_74513_e = false;
         this.clean();
      }
   }

   public void onUpdate() {
      if (!Feature.nullCheck()) {
         if (Util.mc.field_71462_r == null) {
            if (InventoryUtil.findItemInventorySlot(Items.field_151031_f, true) == -1) {
               Command.sendMessage("Couldn't find bow in inventory! Toggling!");
               this.toggle();
            }

            RotationUtil.faceVector(EntityUtil.getInterpolatedPos(Util.mc.field_71439_g, Util.mc.field_71428_T.field_194148_c).func_72441_c(0.0D, 3.0D, 0.0D), false);
            Iterator var1;
            int a;
            ItemStack arrow;
            if (this.stage == 0) {
               this.map = this.mapArrows();
               var1 = this.map.iterator();

               label156:
               while(true) {
                  do {
                     if (!var1.hasNext()) {
                        ++this.stage;
                        break label156;
                     }

                     a = (Integer)var1.next();
                     arrow = (ItemStack)Util.mc.field_71439_g.field_71069_bz.func_75138_a().get(a);
                     if ((PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185223_F) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185225_H) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185224_G)) && this.strSlot == -1) {
                        this.strSlot = a;
                     }
                  } while(!PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185243_o) && !PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185244_p) && !PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185245_q));

                  if (this.speedSlot == -1) {
                     this.speedSlot = a;
                  }
               }
            } else if (this.stage == 1) {
               if (!this.delayTimer.passedMs((long)(Integer)this.delay.getValue())) {
                  return;
               }

               this.delayTimer.reset();
               ++this.stage;
            } else if (this.stage == 2) {
               this.switchTo((Enum)this.main.getValue());
               ++this.stage;
            } else if (this.stage == 3) {
               if (!this.delayTimer.passedMs((long)(Integer)this.delay.getValue())) {
                  return;
               }

               this.delayTimer.reset();
               ++this.stage;
            } else if (this.stage == 4) {
               Util.mc.field_71474_y.field_74313_G.field_74513_e = true;
               this.holdTimer.reset();
               ++this.stage;
            } else if (this.stage == 5) {
               if (!this.holdTimer.passedMs((long)(Integer)this.holdLength.getValue())) {
                  return;
               }

               this.holdTimer.reset();
               ++this.stage;
            } else if (this.stage == 6) {
               Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, Util.mc.field_71439_g.func_174811_aO()));
               Util.mc.field_71439_g.func_184602_cy();
               Util.mc.field_71474_y.field_74313_G.field_74513_e = false;
               ++this.stage;
            } else if (this.stage == 7) {
               if (!this.delayTimer.passedMs((long)(Integer)this.delay.getValue())) {
                  return;
               }

               this.delayTimer.reset();
               ++this.stage;
            } else if (this.stage == 8) {
               this.map = this.mapArrows();
               this.strSlot = -1;
               this.speedSlot = -1;
               var1 = this.map.iterator();

               label128:
               while(true) {
                  do {
                     if (!var1.hasNext()) {
                        ++this.stage;
                        break label128;
                     }

                     a = (Integer)var1.next();
                     arrow = (ItemStack)Util.mc.field_71439_g.field_71069_bz.func_75138_a().get(a);
                     if ((PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185223_F) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185225_H) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185224_G)) && this.strSlot == -1) {
                        this.strSlot = a;
                     }
                  } while(!PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185243_o) && !PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185244_p) && !PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185245_q));

                  if (this.speedSlot == -1) {
                     this.speedSlot = a;
                  }
               }
            }

            if (this.stage == 9) {
               this.switchTo((Enum)this.secondary.getValue());
               ++this.stage;
            } else if (this.stage == 10) {
               if (!this.delayTimer.passedMs((long)(Integer)this.delay.getValue())) {
                  return;
               }

               ++this.stage;
            } else if (this.stage == 11) {
               Util.mc.field_71474_y.field_74313_G.field_74513_e = true;
               this.holdTimer.reset();
               ++this.stage;
            } else if (this.stage == 12) {
               if (!this.holdTimer.passedMs((long)(Integer)this.holdLength.getValue())) {
                  return;
               }

               this.holdTimer.reset();
               ++this.stage;
            } else if (this.stage == 13) {
               Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, Util.mc.field_71439_g.func_174811_aO()));
               Util.mc.field_71439_g.func_184602_cy();
               Util.mc.field_71474_y.field_74313_G.field_74513_e = false;
               ++this.stage;
            } else if (this.stage == 14) {
               ArrayList<Integer> map = this.mapEmpty();
               if (!map.isEmpty()) {
                  a = (Integer)map.get(0);
                  Util.mc.field_71442_b.func_187098_a(Util.mc.field_71439_g.field_71069_bz.field_75152_c, a, 0, ClickType.PICKUP, Util.mc.field_71439_g);
               }

               ++this.stage;
            } else if (this.stage == 15) {
               this.setEnabled(false);
            }

         }
      }
   }

   private void switchTo(Enum<Quiver.mainEnum> mode) {
      if (mode.toString().equalsIgnoreCase("STRENGTH") && this.strSlot != -1) {
         this.switchTo(this.strSlot);
      }

      if (mode.toString().equalsIgnoreCase("SPEED") && this.speedSlot != -1) {
         this.switchTo(this.speedSlot);
      }

   }

   private ArrayList<Integer> mapArrows() {
      ArrayList<Integer> map = new ArrayList();

      for(int a = 9; a < 45; ++a) {
         if (((ItemStack)Util.mc.field_71439_g.field_71069_bz.func_75138_a().get(a)).func_77973_b() instanceof ItemTippedArrow) {
            ItemStack arrow = (ItemStack)Util.mc.field_71439_g.field_71069_bz.func_75138_a().get(a);
            if (PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185223_F) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185225_H) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185224_G)) {
               map.add(a);
            }

            if (PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185243_o) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185244_p) || PotionUtils.func_185191_c(arrow).equals(PotionTypes.field_185245_q)) {
               map.add(a);
            }
         }
      }

      return map;
   }

   private ArrayList<Integer> mapEmpty() {
      ArrayList<Integer> map = new ArrayList();

      for(int a = 9; a < 45; ++a) {
         if (((ItemStack)Util.mc.field_71439_g.field_71069_bz.func_75138_a().get(a)).func_77973_b() instanceof ItemAir || Util.mc.field_71439_g.field_71069_bz.func_75138_a().get(a) == ItemStack.field_190927_a) {
            map.add(a);
         }
      }

      return map;
   }

   private void switchTo(int from) {
      if (from != 9) {
         Util.mc.field_71442_b.func_187098_a(Util.mc.field_71439_g.field_71069_bz.field_75152_c, from, 0, ClickType.PICKUP, Util.mc.field_71439_g);
         Util.mc.field_71442_b.func_187098_a(Util.mc.field_71439_g.field_71069_bz.field_75152_c, 9, 0, ClickType.PICKUP, Util.mc.field_71439_g);
         Util.mc.field_71442_b.func_187098_a(Util.mc.field_71439_g.field_71069_bz.field_75152_c, from, 0, ClickType.PICKUP, Util.mc.field_71439_g);
         Util.mc.field_71442_b.func_78765_e();
      }
   }

   private void clean() {
      this.holdTimer.reset();
      this.delayTimer.reset();
      this.map = null;
      this.speedSlot = -1;
      this.strSlot = -1;
      this.stage = 0;
   }

   private static enum mainEnum {
      STRENGTH,
      SPEED;
   }
}
