package ryo.mrbubblegum.nhack4.lite.hud;

import java.awt.Color;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import ryo.mrbubblegum.nhack4.impl.util.ColorUtil;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class CoolWatermark extends Module {
   public Setting<CoolWatermark.Pages> page;
   public Setting<CoolWatermark.Colorsp> colorp;
   public Setting<Integer> firstRed;
   public Setting<Integer> firstGreen;
   public Setting<Integer> firtBlue;
   public Setting<Integer> firstAlpha;
   public Setting<Integer> secondRed;
   public Setting<Integer> secondGreen;
   public Setting<Integer> secondBlue;
   public Setting<Integer> secondAlpha;
   public Setting<Integer> thirdRed;
   public Setting<Integer> thirdGreen;
   public Setting<Integer> thirdBlue;
   public Setting<Integer> thirdAlpha;
   public Setting<Integer> fourthRed;
   public Setting<Integer> fourthGreen;
   public Setting<Integer> fourthBlue;
   public Setting<Integer> fourthAlpha;
   public Setting<Integer> posY;
   public Setting<Double> barPosY;
   public Setting<Double> textPosY;
   public Setting<Integer> bgRed;
   public Setting<Integer> bgGreen;
   public Setting<Integer> bgBlue;
   public Setting<Integer> bgAlpha;
   public Setting<Integer> bRed;
   public Setting<Integer> bGreen;
   public Setting<Integer> bBlue;
   public Setting<Integer> bAlpha;

   public CoolWatermark() {
      super("Watermark", "best", Module.Category.HUD, true, false, false);
      this.page = this.register(new Setting("Page", CoolWatermark.Pages.Watermark));
      this.colorp = this.register(new Setting("ColorPage", CoolWatermark.Colorsp.First, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor;
      }));
      this.firstRed = this.register(new Setting("FirstRed", 135, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.First;
      }));
      this.firstGreen = this.register(new Setting("FirstGreen", 135, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.First;
      }));
      this.firtBlue = this.register(new Setting("FirstBlue", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.First;
      }));
      this.firstAlpha = this.register(new Setting("FirstAlpha", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.First;
      }));
      this.secondRed = this.register(new Setting("SecondRed", 0, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Second;
      }));
      this.secondGreen = this.register(new Setting("SecondGreen", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Second;
      }));
      this.secondBlue = this.register(new Setting("SecondBlue", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Second;
      }));
      this.secondAlpha = this.register(new Setting("SecondAlpha", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Second;
      }));
      this.thirdRed = this.register(new Setting("ThirdRed", 135, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Third;
      }));
      this.thirdGreen = this.register(new Setting("ThirdGreen", 135, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Third;
      }));
      this.thirdBlue = this.register(new Setting("ThirdBlue", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Third;
      }));
      this.thirdAlpha = this.register(new Setting("ThirdAlpha", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Third;
      }));
      this.fourthRed = this.register(new Setting("FourthRed", 0, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Fourth;
      }));
      this.fourthGreen = this.register(new Setting("FourthGreen", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Fourth;
      }));
      this.fourthBlue = this.register(new Setting("FourthBlue", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Fourth;
      }));
      this.fourthAlpha = this.register(new Setting("FourthAlpha", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.BarColor && this.colorp.getValue() == CoolWatermark.Colorsp.Fourth;
      }));
      this.posY = this.register(new Setting("PosY", 2, 0, 512, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Watermark;
      }));
      this.barPosY = this.register(new Setting("BarPosY", 0.0D, -2.0D, 15.0D, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Watermark;
      }));
      this.textPosY = this.register(new Setting("TextPosY", 0.0D, -6.0D, 3.0D, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Watermark;
      }));
      this.bgRed = this.register(new Setting("BackgroundRed", 20, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Background;
      }));
      this.bgGreen = this.register(new Setting("BackgroundGreen", 20, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Background;
      }));
      this.bgBlue = this.register(new Setting("BackgroundBlue", 20, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Background;
      }));
      this.bgAlpha = this.register(new Setting("BackgroundAlpha", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Background;
      }));
      this.bRed = this.register(new Setting("BorderRed", 0, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Border;
      }));
      this.bGreen = this.register(new Setting("BorderGreen", 0, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Border;
      }));
      this.bBlue = this.register(new Setting("BorderBlue", 0, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Border;
      }));
      this.bAlpha = this.register(new Setting("BorderAlpha", 255, 0, 255, (v) -> {
         return this.page.getValue() == CoolWatermark.Pages.Border;
      }));
   }

   public static void drawRect(double left, double top, double right, double bottom, int color) {
      double j;
      if (left < right) {
         j = left;
         left = right;
         right = j;
      }

      if (top < bottom) {
         j = top;
         top = bottom;
         bottom = j;
      }

      float f3 = (float)(color >> 24 & 255) / 255.0F;
      float f = (float)(color >> 16 & 255) / 255.0F;
      float f1 = (float)(color >> 8 & 255) / 255.0F;
      float f2 = (float)(color & 255) / 255.0F;
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferBuilder = tessellator.func_178180_c();
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      GlStateManager.func_179131_c(f, f1, f2, f3);
      bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
      bufferBuilder.func_181662_b(left, bottom, 0.0D).func_181675_d();
      bufferBuilder.func_181662_b(right, bottom, 0.0D).func_181675_d();
      bufferBuilder.func_181662_b(right, top, 0.0D).func_181675_d();
      bufferBuilder.func_181662_b(left, top, 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
   }

   public static void drawGradientSideways(double left, double top, double right, double bottom, int col1, int col2) {
      float f = (float)(col1 >> 24 & 255) / 255.0F;
      float f1 = (float)(col1 >> 16 & 255) / 255.0F;
      float f2 = (float)(col1 >> 8 & 255) / 255.0F;
      float f3 = (float)(col1 & 255) / 255.0F;
      float f4 = (float)(col2 >> 24 & 255) / 255.0F;
      float f5 = (float)(col2 >> 16 & 255) / 255.0F;
      float f6 = (float)(col2 >> 8 & 255) / 255.0F;
      float f7 = (float)(col2 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(f1, f2, f3, f);
      GL11.glVertex2d(left, top);
      GL11.glVertex2d(left, bottom);
      GL11.glColor4f(f5, f6, f7, f4);
      GL11.glVertex2d(right, bottom);
      GL11.glVertex2d(right, top);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

   @SubscribeEvent
   public void onRender(Post event) {
      if (!nullCheck()) {
         if (event.getType() == ElementType.HOTBAR) {
            String ping = this.getPing(mc.field_71439_g) + "ms";
            String fpsText = Minecraft.field_71470_ab + "fps ";
            String name = mc.field_71439_g.getDisplayNameString();
            String server = Minecraft.func_71410_x().func_71356_B() ? "singleplayer".toLowerCase() : mc.func_147104_D().field_78845_b.toLowerCase();
            String nhack4 = "NHACK4";
            String text = nhack4 + " | " + server + " | " + ping + " | " + fpsText;
            float width = (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a(text) + 6);
            int height = 20;
            int posX = 2;
            int posY = (Integer)this.posY.getValue();
            double barPosY = (Double)this.barPosY.getValue();
            double textPosY = (Double)this.textPosY.getValue();
            RenderUtil.drawRectangleCorrectly(posX - 4, posY - 4, (int)(width + 10.0F), height + 6, ColorUtil.toRGBA((Integer)this.bRed.getValue(), (Integer)this.bGreen.getValue(), (Integer)this.bBlue.getValue(), (Integer)this.bAlpha.getValue()));
            RenderUtil.drawRectangleCorrectly(posX - 4, posY - 4, (int)(width + 11.0F), height + 7, ColorUtil.toRGBA((Integer)this.bRed.getValue(), (Integer)this.bGreen.getValue(), (Integer)this.bBlue.getValue(), (Integer)this.bAlpha.getValue()));
            drawRect((double)posX, (double)posY, (double)((float)posX + width + 2.0F), (double)(posY + height), (new Color((Integer)this.bgRed.getValue(), (Integer)this.bgGreen.getValue(), (Integer)this.bgBlue.getValue(), (Integer)this.bgAlpha.getValue())).getRGB());
            drawRect((double)posX + 2.5D, (double)posY + 2.5D, (double)((float)posX + width) - 0.5D, (double)posY + 4.5D, (new Color((Integer)this.bgRed.getValue(), (Integer)this.bgGreen.getValue(), (Integer)this.bgBlue.getValue(), (Integer)this.bgAlpha.getValue())).getRGB());
            drawGradientSideways(4.0D, (double)posY + barPosY + 3.0D, (double)(4.0F + width / 3.0F), (double)posY + barPosY + 4.0D, (new Color((Integer)this.firstRed.getValue(), (Integer)this.firstGreen.getValue(), (Integer)this.firtBlue.getValue(), (Integer)this.firstAlpha.getValue())).getRGB(), (new Color((Integer)this.secondRed.getValue(), (Integer)this.secondGreen.getValue(), (Integer)this.secondBlue.getValue(), (Integer)this.secondAlpha.getValue())).getRGB());
            drawGradientSideways((double)(4.0F + width / 3.0F), (double)posY + barPosY + 3.0D, (double)(4.0F + width / 3.0F * 2.0F), (double)posY + barPosY + 4.0D, (new Color((Integer)this.secondRed.getValue(), (Integer)this.secondGreen.getValue(), (Integer)this.secondBlue.getValue(), (Integer)this.secondAlpha.getValue())).getRGB(), (new Color((Integer)this.thirdRed.getValue(), (Integer)this.thirdGreen.getValue(), (Integer)this.thirdBlue.getValue(), (Integer)this.thirdAlpha.getValue())).getRGB());
            drawGradientSideways((double)(4.0F + width / 3.0F * 2.0F), (double)posY + barPosY + 3.0D, (double)(width / 3.0F * 3.0F + 1.0F), (double)posY + barPosY + 4.0D, (new Color((Integer)this.thirdRed.getValue(), (Integer)this.thirdGreen.getValue(), (Integer)this.thirdBlue.getValue(), (Integer)this.thirdAlpha.getValue())).getRGB(), (new Color((Integer)this.fourthRed.getValue(), (Integer)this.fourthGreen.getValue(), (Integer)this.fourthBlue.getValue(), (Integer)this.fourthAlpha.getValue())).getRGB());
            Minecraft.func_71410_x().field_71466_p.func_175063_a(text, (float)(4 + posX), (float)(8.0D + (double)posY + textPosY), -1);
         }

      }
   }

   private int getPing(EntityPlayer player) {
      int ping = 0;

      try {
         ping = (int)MathUtil.clamp((float)((NetHandlerPlayClient)Objects.requireNonNull(mc.func_147114_u())).func_175102_a(player.func_110124_au()).func_178853_c(), 1.0F, 300.0F);
      } catch (NullPointerException var4) {
      }

      return ping;
   }

   public static enum Colorsp {
      First,
      Second,
      Third,
      Fourth;
   }

   public static enum Pages {
      Watermark,
      BarColor,
      Background,
      Border;
   }
}
