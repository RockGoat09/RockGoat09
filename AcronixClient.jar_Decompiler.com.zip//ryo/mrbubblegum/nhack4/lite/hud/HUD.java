package ryo.mrbubblegum.nhack4.lite.hud;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.manager.TextManager;
import ryo.mrbubblegum.nhack4.impl.util.ColorUtil;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.Feature;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.client.Colors;
import ryo.mrbubblegum.nhack4.lite.client.Managers;
import ryo.mrbubblegum.nhack4.lite.client.PingBypass;
import ryo.mrbubblegum.nhack4.lite.misc.ToolTips;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;
import ryo.mrbubblegum.nhack4.world.events.Render2DEvent;

public class HUD extends Module {
   private static final ItemStack totem;
   private static final ResourceLocation codHitmarker;
   private static final ResourceLocation csgoHitmarker;
   private static HUD INSTANCE;
   private final Setting<Boolean> renderingUp = this.register(new Setting("RenderingUp", false, "Orientation of the HUD-Elements."));
   private final Setting<HUD.WaterMark> watermark;
   private final Setting<Boolean> modeVer;
   private final Setting<Boolean> arrayList;
   private final Setting<Boolean> moduleColors;
   private final Setting<Boolean> alphabeticalSorting;
   private final Setting<Boolean> serverBrand;
   private final Setting<Boolean> ping;
   private final Setting<Boolean> tps;
   private final Setting<Boolean> fps;
   private final Setting<Boolean> coords;
   private final Setting<Boolean> direction;
   private final Setting<Boolean> speed;
   private final Setting<Boolean> potions;
   private final Setting<Boolean> altPotionsColors;
   private final Setting<Boolean> armor;
   private final Setting<Boolean> durability;
   private final Setting<Boolean> percent;
   private final Setting<Boolean> totems;
   private final Setting<HUD.Greeter> greeter;
   private final Setting<String> spoofGreeter;
   private final Setting<HUD.LagNotify> lag;
   private final Setting<Boolean> hitMarkers;
   private final Setting<Boolean> grayNess;
   private final Timer timer;
   private final Timer moduleTimer;
   private final Map<Potion, Color> potionColorMap;
   public Setting<Boolean> colorSync;
   public Setting<Boolean> rainbow;
   public Setting<Integer> factor;
   public Setting<Boolean> rolling;
   public Setting<Integer> rainbowSpeed;
   public Setting<Integer> rainbowSaturation;
   public Setting<Integer> rainbowBrightness;
   public Setting<Boolean> potionIcons;
   public Setting<Boolean> shadow;
   public Setting<Integer> animationHorizontalTime;
   public Setting<Integer> animationVerticalTime;
   public Setting<Boolean> textRadar;
   public Setting<Boolean> time;
   public Setting<Integer> hudRed;
   public Setting<Integer> hudGreen;
   public Setting<Integer> hudBlue;
   public Setting<Boolean> potions1;
   public Setting<Boolean> MS;
   public Map<Module, Float> moduleProgressMap;
   public Map<Integer, Integer> colorMap;
   private Map<String, Integer> players;
   private int color;
   private boolean shouldIncrement;
   private int hitMarkerTimer;

   public HUD() {
      super("HUD", "HUD Elements rendered on your screen", Module.Category.HUD, true, false, false);
      this.watermark = this.register(new Setting("Logo", HUD.WaterMark.NONE, "WaterMark"));
      this.modeVer = this.register(new Setting("Version", false, (v) -> {
         return this.watermark.getValue() != HUD.WaterMark.NONE;
      }));
      this.arrayList = this.register(new Setting("ActiveModules", false, "Lists the active modules."));
      this.moduleColors = this.register(new Setting("ModuleColors", false, (v) -> {
         return (Boolean)this.arrayList.getValue();
      }));
      this.alphabeticalSorting = this.register(new Setting("AlphabeticalSorting", false, (v) -> {
         return (Boolean)this.arrayList.getValue();
      }));
      this.serverBrand = this.register(new Setting("ServerBrand", false, "Brand of the server you are on."));
      this.ping = this.register(new Setting("Ping", false, "Your response time to the server."));
      this.tps = this.register(new Setting("TPS", false, "Ticks per second of the server."));
      this.fps = this.register(new Setting("FPS", false, "Your frames per second."));
      this.coords = this.register(new Setting("Coords", false, "Your current coordinates"));
      this.direction = this.register(new Setting("Direction", false, "The Direction you are facing."));
      this.speed = this.register(new Setting("Speed", false, "Your Speed"));
      this.potions = this.register(new Setting("Potions", false, "Active potion effects"));
      this.altPotionsColors = this.register(new Setting("AltPotionColors", false, (v) -> {
         return (Boolean)this.potions.getValue();
      }));
      this.armor = this.register(new Setting("Armor", false, "ArmorHUD"));
      this.durability = this.register(new Setting("Durability", false, "Durability"));
      this.percent = this.register(new Setting("Percent", true, (v) -> {
         return (Boolean)this.armor.getValue();
      }));
      this.totems = this.register(new Setting("Totems", false, "TotemHUD"));
      this.greeter = this.register(new Setting("Greeter", HUD.Greeter.NONE, "Greets you."));
      this.spoofGreeter = this.register(new Setting("GreeterName", "NHACK4", (v) -> {
         return this.greeter.getValue() == HUD.Greeter.CUSTOM;
      }));
      this.lag = this.register(new Setting("Lag", HUD.LagNotify.GRAY, "Lag Notifier"));
      this.hitMarkers = this.register(new Setting("HitMarkers", false));
      this.grayNess = this.register(new Setting("FutureColour", false));
      this.timer = new Timer();
      this.moduleTimer = new Timer();
      this.potionColorMap = new HashMap();
      this.colorSync = this.register(new Setting("Sync", false, "Universal colors for hud."));
      this.rainbow = this.register(new Setting("Rainbow", false, "Rainbow hud."));
      this.factor = this.register(new Setting("Factor", 1, 0, 20, (v) -> {
         return (Boolean)this.rainbow.getValue();
      }));
      this.rolling = this.register(new Setting("Rolling", false, (v) -> {
         return (Boolean)this.rainbow.getValue();
      }));
      this.rainbowSpeed = this.register(new Setting("RSpeed", 20, 0, 100, (v) -> {
         return (Boolean)this.rainbow.getValue();
      }));
      this.rainbowSaturation = this.register(new Setting("Saturation", 255, 0, 255, (v) -> {
         return (Boolean)this.rainbow.getValue();
      }));
      this.rainbowBrightness = this.register(new Setting("Brightness", 255, 0, 255, (v) -> {
         return (Boolean)this.rainbow.getValue();
      }));
      this.potionIcons = this.register(new Setting("PotionIcons", true, "Draws Potion Icons."));
      this.shadow = this.register(new Setting("Shadow", false, "Draws the text with a shadow."));
      this.animationHorizontalTime = this.register(new Setting("AnimationHTime", 500, 1, 1000, (v) -> {
         return (Boolean)this.arrayList.getValue();
      }));
      this.animationVerticalTime = this.register(new Setting("AnimationVTime", 50, 1, 500, (v) -> {
         return (Boolean)this.arrayList.getValue();
      }));
      this.textRadar = this.register(new Setting("TextRadar", false, "A TextRadar"));
      this.time = this.register(new Setting("Time", false, "The time"));
      this.hudRed = this.register(new Setting("Red", 135, 0, 255, (v) -> {
         return !(Boolean)this.rainbow.getValue();
      }));
      this.hudGreen = this.register(new Setting("Green", 0, 0, 255, (v) -> {
         return !(Boolean)this.rainbow.getValue();
      }));
      this.hudBlue = this.register(new Setting("Blue", 255, 0, 255, (v) -> {
         return !(Boolean)this.rainbow.getValue();
      }));
      this.potions1 = this.register(new Setting("LevelPotions", false, (v) -> {
         return (Boolean)this.potions.getValue();
      }));
      this.MS = this.register(new Setting("ms", false, (v) -> {
         return (Boolean)this.ping.getValue();
      }));
      this.moduleProgressMap = new HashMap();
      this.colorMap = new HashMap();
      this.players = new HashMap();
      this.setInstance();
      this.potionColorMap.put(MobEffects.field_76424_c, new Color(124, 175, 198));
      this.potionColorMap.put(MobEffects.field_76421_d, new Color(90, 108, 129));
      this.potionColorMap.put(MobEffects.field_76422_e, new Color(217, 192, 67));
      this.potionColorMap.put(MobEffects.field_76419_f, new Color(74, 66, 23));
      this.potionColorMap.put(MobEffects.field_76420_g, new Color(147, 36, 35));
      this.potionColorMap.put(MobEffects.field_76432_h, new Color(67, 10, 9));
      this.potionColorMap.put(MobEffects.field_76433_i, new Color(67, 10, 9));
      this.potionColorMap.put(MobEffects.field_76430_j, new Color(34, 255, 76));
      this.potionColorMap.put(MobEffects.field_76431_k, new Color(85, 29, 74));
      this.potionColorMap.put(MobEffects.field_76428_l, new Color(205, 92, 171));
      this.potionColorMap.put(MobEffects.field_76429_m, new Color(153, 69, 58));
      this.potionColorMap.put(MobEffects.field_76426_n, new Color(228, 154, 58));
      this.potionColorMap.put(MobEffects.field_76427_o, new Color(46, 82, 153));
      this.potionColorMap.put(MobEffects.field_76441_p, new Color(127, 131, 146));
      this.potionColorMap.put(MobEffects.field_76440_q, new Color(31, 31, 35));
      this.potionColorMap.put(MobEffects.field_76439_r, new Color(31, 31, 161));
      this.potionColorMap.put(MobEffects.field_76438_s, new Color(88, 118, 83));
      this.potionColorMap.put(MobEffects.field_76437_t, new Color(72, 77, 72));
      this.potionColorMap.put(MobEffects.field_76436_u, new Color(78, 147, 49));
      this.potionColorMap.put(MobEffects.field_82731_v, new Color(53, 42, 39));
      this.potionColorMap.put(MobEffects.field_180152_w, new Color(248, 125, 35));
      this.potionColorMap.put(MobEffects.field_76444_x, new Color(37, 82, 165));
      this.potionColorMap.put(MobEffects.field_76443_y, new Color(248, 36, 35));
      this.potionColorMap.put(MobEffects.field_188423_x, new Color(148, 160, 97));
      this.potionColorMap.put(MobEffects.field_188424_y, new Color(206, 255, 255));
      this.potionColorMap.put(MobEffects.field_188425_z, new Color(51, 153, 0));
      this.potionColorMap.put(MobEffects.field_189112_A, new Color(192, 164, 77));
   }

   public static HUD getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new HUD();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onUpdate() {
      Iterator var1 = Loader.moduleManager.sortedModules.iterator();

      while(var1.hasNext()) {
         Module module = (Module)var1.next();
         if (module.isDisabled() && module.arrayListOffset == 0.0F) {
            module.sliding = true;
         }
      }

      if (this.timer.passedMs((long)(Integer)Managers.getInstance().textRadarUpdates.getValue())) {
         this.players = this.getTextRadarPlayers();
         this.timer.reset();
      }

      if (this.shouldIncrement) {
         ++this.hitMarkerTimer;
      }

      if (this.hitMarkerTimer == 10) {
         this.hitMarkerTimer = 0;
         this.shouldIncrement = false;
      }

   }

   @SubscribeEvent
   public void onModuleToggle(ClientEvent event) {
      if (event.getFeature() instanceof Module) {
         float i;
         if (event.getStage() == 0) {
            for(i = 0.0F; i <= (float)this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()); i += (float)this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) / 500.0F) {
               if (this.moduleTimer.passedMs(1L)) {
                  this.moduleProgressMap.put((Module)event.getFeature(), (float)this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) - i);
               }

               this.timer.reset();
            }
         } else if (event.getStage() == 1) {
            for(i = 0.0F; i <= (float)this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()); i += (float)this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) / 500.0F) {
               if (this.moduleTimer.passedMs(1L)) {
                  this.moduleProgressMap.put((Module)event.getFeature(), (float)this.renderer.getStringWidth(((Module)event.getFeature()).getDisplayName()) - i);
               }

               this.timer.reset();
            }
         }
      }

   }

   public void onRender2D(Render2DEvent event) {
      if (!Feature.fullNullCheck()) {
         int colorSpeed = 101 - (Integer)this.rainbowSpeed.getValue();
         float hue = (Boolean)this.colorSync.getValue() ? Colors.INSTANCE.hue : (float)(System.currentTimeMillis() % (long)(360 * colorSpeed)) / (360.0F * (float)colorSpeed);
         int width = this.renderer.scaledWidth;
         int height = this.renderer.scaledHeight;
         float tempHue = hue;

         for(int i = 0; i <= height; ++i) {
            if ((Boolean)this.colorSync.getValue()) {
               this.colorMap.put(i, Color.HSBtoRGB(tempHue, (float)(Integer)Colors.INSTANCE.rainbowSaturation.getValue() / 255.0F, (float)(Integer)Colors.INSTANCE.rainbowBrightness.getValue() / 255.0F));
            } else {
               this.colorMap.put(i, Color.HSBtoRGB(tempHue, (float)(Integer)this.rainbowSaturation.getValue() / 255.0F, (float)(Integer)this.rainbowBrightness.getValue() / 255.0F));
            }

            tempHue += 1.0F / (float)height * (float)(Integer)this.factor.getValue();
         }

         GlStateManager.func_179094_E();
         if ((Boolean)this.rainbow.getValue() && !(Boolean)this.rolling.getValue()) {
            this.color = (Boolean)this.colorSync.getValue() ? Colors.INSTANCE.getCurrentColorHex() : Color.HSBtoRGB(hue, (float)(Integer)this.rainbowSaturation.getValue() / 255.0F, (float)(Integer)this.rainbowBrightness.getValue() / 255.0F);
         } else if (!(Boolean)this.rainbow.getValue()) {
            this.color = (Boolean)this.colorSync.getValue() ? Colors.INSTANCE.getCurrentColorHex() : ColorUtil.toRGBA((Integer)this.hudRed.getValue(), (Integer)this.hudGreen.getValue(), (Integer)this.hudBlue.getValue());
         }

         String grayString = (Boolean)this.grayNess.getValue() ? String.valueOf(ChatFormatting.GRAY) : "";
         if (Objects.requireNonNull(this.watermark.getValue()) == HUD.WaterMark.NHACK4) {
            this.renderer.drawString("NHACK4 " + ((Boolean)this.modeVer.getValue() ? "0.1.0" : ""), 2.0F, 2.0F, (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2) : this.color, true);
         }

         if ((Boolean)this.textRadar.getValue()) {
            this.drawTextRadar(!ToolTips.getInstance().isOff() && (Boolean)ToolTips.getInstance().shulkerSpy.getValue() && (Boolean)ToolTips.getInstance().render.getValue() ? ToolTips.getInstance().getTextRadarY() : 0);
         }

         int j = (Boolean)this.renderingUp.getValue() ? 0 : (mc.field_71462_r instanceof GuiChat ? 14 : 0);
         int k;
         String text;
         TextManager renderer3;
         float x3;
         if ((Boolean)this.arrayList.getValue()) {
            Module module;
            Color moduleColor;
            if ((Boolean)this.renderingUp.getValue()) {
               for(k = 0; k < ((Boolean)this.alphabeticalSorting.getValue() ? Loader.moduleManager.alphabeticallySortedModules.size() : Loader.moduleManager.sortedModules.size()); ++k) {
                  module = (Boolean)this.alphabeticalSorting.getValue() ? (Module)Loader.moduleManager.alphabeticallySortedModules.get(k) : (Module)Loader.moduleManager.sortedModules.get(k);
                  text = module.getDisplayName() + ChatFormatting.GRAY + (module.getDisplayInfo() != null ? " [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]" : "");
                  moduleColor = (Color)Loader.moduleManager.moduleColorMap.get(module);
                  this.renderer.drawString(text, (float)(width - 2 - this.renderer.getStringWidth(text)) + ((Integer)this.animationHorizontalTime.getValue() == 1 ? 0.0F : module.arrayListOffset), (float)(2 + j * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(MathUtil.clamp(2 + j * 10, 0, height)) : ((Boolean)this.moduleColors.getValue() && moduleColor != null ? moduleColor.getRGB() : this.color), true);
                  ++j;
               }
            } else {
               for(k = 0; k < ((Boolean)this.alphabeticalSorting.getValue() ? Loader.moduleManager.alphabeticallySortedModules.size() : Loader.moduleManager.sortedModules.size()); ++k) {
                  module = (Boolean)this.alphabeticalSorting.getValue() ? (Module)Loader.moduleManager.alphabeticallySortedModules.get(Loader.moduleManager.alphabeticallySortedModules.size() - 1 - k) : (Module)Loader.moduleManager.sortedModules.get(k);
                  text = module.getDisplayName() + ChatFormatting.GRAY + (module.getDisplayInfo() != null ? " [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]" : "");
                  moduleColor = (Color)Loader.moduleManager.moduleColorMap.get(module);
                  renderer3 = this.renderer;
                  x3 = (float)(width - 2 - this.renderer.getStringWidth(text)) + ((Integer)this.animationHorizontalTime.getValue() == 1 ? 0.0F : module.arrayListOffset);
                  j += 10;
                  renderer3.drawString(text, x3, (float)(height - j), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(MathUtil.clamp(height - j, 0, height)) : ((Boolean)this.moduleColors.getValue() && moduleColor != null ? moduleColor.getRGB() : this.color), true);
               }
            }
         }

         k = (Boolean)this.renderingUp.getValue() ? 0 : 0;
         int hposZ;
         String fpsText;
         Iterator var29;
         PotionEffect effect;
         int itemDamage;
         String text3;
         float x9;
         int hposX;
         if ((Boolean)this.renderingUp.getValue()) {
            int n7;
            TextManager renderer7;
            float x7;
            if ((Boolean)this.serverBrand.getValue()) {
               fpsText = grayString + "Server brand " + ChatFormatting.WHITE + Loader.serverManager.getServerBrand();
               renderer7 = this.renderer;
               x7 = (float)(width - (this.renderer.getStringWidth(fpsText) + 2));
               n7 = height - 2;
               k += 10;
               renderer7.drawString(fpsText, x7, (float)(n7 - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
            }

            if ((Boolean)this.potions.getValue()) {
               var29 = Loader.potionManager.getOwnPotions().iterator();

               while(var29.hasNext()) {
                  effect = (PotionEffect)var29.next();
                  text3 = (Boolean)this.altPotionsColors.getValue() ? Loader.potionManager.getPotionString(effect) : Loader.potionManager.getColoredPotionString(effect);
                  renderer3 = this.renderer;
                  x3 = (float)(width - (this.renderer.getStringWidth(text3) + 2));
                  hposZ = height - 2;
                  k += 10;
                  renderer3.drawString(text3, x3, (float)(hposZ - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : ((Boolean)this.altPotionsColors.getValue() ? ((Color)this.potionColorMap.get(effect.func_188419_a())).getRGB() : this.color), true);
               }
            }

            if ((Boolean)this.speed.getValue()) {
               fpsText = grayString + "Speed " + ChatFormatting.WHITE + Loader.speedManager.getSpeedKpH() + " km/h";
               renderer7 = this.renderer;
               x7 = (float)(width - (this.renderer.getStringWidth(fpsText) + 2));
               n7 = height - 2;
               k += 10;
               renderer7.drawString(fpsText, x7, (float)(n7 - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
            }

            if ((Boolean)this.time.getValue()) {
               fpsText = grayString + "Time " + ChatFormatting.WHITE + (new SimpleDateFormat("h:mm a")).format(new Date());
               renderer7 = this.renderer;
               x7 = (float)(width - (this.renderer.getStringWidth(fpsText) + 2));
               n7 = height - 2;
               k += 10;
               renderer7.drawString(fpsText, x7, (float)(n7 - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
            }

            TextManager renderer9;
            if ((Boolean)this.durability.getValue()) {
               itemDamage = mc.field_71439_g.func_184614_ca().func_77958_k() - mc.field_71439_g.func_184614_ca().func_77952_i();
               if (itemDamage > 0) {
                  text = grayString + "Durability " + ChatFormatting.RESET + itemDamage;
                  renderer9 = this.renderer;
                  x9 = (float)(width - (this.renderer.getStringWidth(text) + 2));
                  hposX = height - 2;
                  k += 10;
                  renderer9.drawString(text, x9, (float)(hposX - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
               }
            }

            if ((Boolean)this.tps.getValue()) {
               fpsText = grayString + "TPS " + ChatFormatting.WHITE + Loader.serverManager.getTPS();
               renderer7 = this.renderer;
               x7 = (float)(width - (this.renderer.getStringWidth(fpsText) + 2));
               n7 = height - 2;
               k += 10;
               renderer7.drawString(fpsText, x7, (float)(n7 - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
            }

            fpsText = grayString + "FPS " + ChatFormatting.WHITE + Minecraft.field_71470_ab;
            text = grayString + "Ping " + ChatFormatting.WHITE + (PingBypass.getInstance().isConnected() ? PingBypass.getInstance().getServerPing() : (long)Loader.serverManager.getPing()) + ((Boolean)this.MS.getValue() ? "ms" : "");
            if (this.renderer.getStringWidth(text) > this.renderer.getStringWidth(fpsText)) {
               if ((Boolean)this.ping.getValue()) {
                  renderer9 = this.renderer;
                  x9 = (float)(width - (this.renderer.getStringWidth(text) + 2));
                  hposX = height - 2;
                  k += 10;
                  renderer9.drawString(text, x9, (float)(hposX - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
               }

               if ((Boolean)this.fps.getValue()) {
                  renderer9 = this.renderer;
                  x9 = (float)(width - (this.renderer.getStringWidth(fpsText) + 2));
                  hposX = height - 2;
                  k += 10;
                  renderer9.drawString(fpsText, x9, (float)(hposX - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
               }
            } else {
               if ((Boolean)this.fps.getValue()) {
                  renderer9 = this.renderer;
                  x9 = (float)(width - (this.renderer.getStringWidth(fpsText) + 2));
                  hposX = height - 2;
                  k += 10;
                  renderer9.drawString(fpsText, x9, (float)(hposX - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
               }

               if ((Boolean)this.ping.getValue()) {
                  renderer9 = this.renderer;
                  x9 = (float)(width - (this.renderer.getStringWidth(text) + 2));
                  hposX = height - 2;
                  k += 10;
                  renderer9.drawString(text, x9, (float)(hposX - k), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(height - k) : this.color, true);
               }
            }
         } else {
            if ((Boolean)this.serverBrand.getValue()) {
               fpsText = grayString + "Server brand " + ChatFormatting.WHITE + Loader.serverManager.getServerBrand();
               this.renderer.drawString(fpsText, (float)(width - (this.renderer.getStringWidth(fpsText) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
            }

            if ((Boolean)this.potions.getValue()) {
               var29 = Loader.potionManager.getOwnPotions().iterator();

               while(var29.hasNext()) {
                  effect = (PotionEffect)var29.next();
                  text3 = (Boolean)this.altPotionsColors.getValue() ? Loader.potionManager.getPotionString(effect) : Loader.potionManager.getColoredPotionString(effect);
                  this.renderer.drawString(text3, (float)(width - (this.renderer.getStringWidth(text3) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : ((Boolean)this.altPotionsColors.getValue() ? ((Color)this.potionColorMap.get(effect.func_188419_a())).getRGB() : this.color), true);
               }
            }

            if ((Boolean)this.speed.getValue()) {
               fpsText = grayString + "Speed " + ChatFormatting.WHITE + Loader.speedManager.getSpeedKpH() + " km/h";
               this.renderer.drawString(fpsText, (float)(width - (this.renderer.getStringWidth(fpsText) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
            }

            if ((Boolean)this.time.getValue()) {
               fpsText = grayString + "Time " + ChatFormatting.WHITE + (new SimpleDateFormat("h:mm a")).format(new Date());
               this.renderer.drawString(fpsText, (float)(width - (this.renderer.getStringWidth(fpsText) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
            }

            if ((Boolean)this.durability.getValue()) {
               itemDamage = mc.field_71439_g.func_184614_ca().func_77958_k() - mc.field_71439_g.func_184614_ca().func_77952_i();
               if (itemDamage > 0) {
                  text = grayString + "Durability " + ChatFormatting.GREEN + itemDamage;
                  this.renderer.drawString(text, (float)(width - (this.renderer.getStringWidth(text) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
               }
            }

            if ((Boolean)this.tps.getValue()) {
               fpsText = grayString + "TPS " + ChatFormatting.WHITE + Loader.serverManager.getTPS();
               this.renderer.drawString(fpsText, (float)(width - (this.renderer.getStringWidth(fpsText) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
            }

            fpsText = grayString + "FPS " + ChatFormatting.WHITE + Minecraft.field_71470_ab;
            text = grayString + "Ping " + ChatFormatting.WHITE + Loader.serverManager.getPing();
            if (this.renderer.getStringWidth(text) > this.renderer.getStringWidth(fpsText)) {
               if ((Boolean)this.ping.getValue()) {
                  this.renderer.drawString(text, (float)(width - (this.renderer.getStringWidth(text) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
               }

               if ((Boolean)this.fps.getValue()) {
                  this.renderer.drawString(fpsText, (float)(width - (this.renderer.getStringWidth(fpsText) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
               }
            } else {
               if ((Boolean)this.fps.getValue()) {
                  this.renderer.drawString(fpsText, (float)(width - (this.renderer.getStringWidth(fpsText) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
               }

               if ((Boolean)this.ping.getValue()) {
                  this.renderer.drawString(text, (float)(width - (this.renderer.getStringWidth(text) + 2)), (float)(2 + k++ * 10), (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2 + k * 10) : this.color, true);
               }
            }
         }

         boolean inHell = mc.field_71441_e.func_180494_b(mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
         int posX = (int)mc.field_71439_g.field_70165_t;
         int posY = (int)mc.field_71439_g.field_70163_u;
         int posZ = (int)mc.field_71439_g.field_70161_v;
         x9 = inHell ? 8.0F : 0.125F;
         hposX = (int)(mc.field_71439_g.field_70165_t * (double)x9);
         hposZ = (int)(mc.field_71439_g.field_70161_v * (double)x9);
         if ((Boolean)this.renderingUp.getValue()) {
            Loader.notificationManager.handleNotifications(height - (k + 16));
         } else {
            Loader.notificationManager.handleNotifications(height - (j + 16));
         }

         k = mc.field_71462_r instanceof GuiChat ? 14 : 0;
         String coordinates = String.valueOf(ChatFormatting.WHITE) + posX + ChatFormatting.GRAY + " [" + hposX + "], " + ChatFormatting.WHITE + posY + ChatFormatting.GRAY + ", " + ChatFormatting.WHITE + posZ + ChatFormatting.GRAY + " [" + hposZ + "]";
         String text4 = ((Boolean)this.direction.getValue() ? Loader.rotationManager.getDirection4D(false) + " " : "") + ((Boolean)this.coords.getValue() ? coordinates : "") + "";
         TextManager renderer12 = this.renderer;
         float x12 = 2.0F;
         k += 10;
         float y = (float)(height - k);
         int color;
         if ((Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue()) {
            Map<Integer, Integer> colorMap = this.colorMap;
            k += 10;
            color = (Integer)colorMap.get(height - k);
         } else {
            color = this.color;
         }

         renderer12.drawString(text4, 2.0F, y, color, true);
         if ((Boolean)this.armor.getValue()) {
            this.renderArmorHUD((Boolean)this.percent.getValue());
         }

         if ((Boolean)this.totems.getValue()) {
            this.renderTotemHUD();
         }

         if (this.greeter.getValue() != HUD.Greeter.NONE) {
            this.renderGreeter();
         }

         if (this.lag.getValue() != HUD.LagNotify.NONE) {
            this.renderLag();
         }

         if ((Boolean)this.hitMarkers.getValue() && this.hitMarkerTimer > 0) {
            this.drawHitMarkers();
         }

         GlStateManager.func_179121_F();
      }
   }

   public Map<String, Integer> getTextRadarPlayers() {
      return EntityUtil.getTextRadarPlayers();
   }

   public void renderGreeter() {
      int width = this.renderer.scaledWidth;
      String text = "";
      switch((HUD.Greeter)this.greeter.getValue()) {
      case TIME:
         text = text + MathUtil.getTimeOfDay() + mc.field_71439_g.getDisplayNameString();
         break;
      case CHRISTMAS:
         text = text + "Merry Christmas " + mc.field_71439_g.getDisplayNameString() + " :^)";
         break;
      case LONG:
         text = text + "Welcome to NHACK4 " + mc.field_71439_g.getDisplayNameString() + " :^)";
         break;
      case CUSTOM:
         text = text + (String)this.spoofGreeter.getValue();
         break;
      default:
         text = text + "Welcome " + mc.field_71439_g.getDisplayNameString();
      }

      this.renderer.drawString(text, (float)width / 2.0F - (float)this.renderer.getStringWidth(text) / 2.0F + 2.0F, 2.0F, (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(2) : this.color, true);
   }

   public void renderLag() {
      int width = this.renderer.scaledWidth;
      if (Loader.serverManager.isServerNotResponding()) {
         String text = (this.lag.getValue() == HUD.LagNotify.GRAY ? ChatFormatting.GRAY : ChatFormatting.RED) + "Server not responding: " + MathUtil.round((float)Loader.serverManager.serverRespondingTime() / 1000.0F, 1) + "s.";
         this.renderer.drawString(text, (float)width / 2.0F - (float)this.renderer.getStringWidth(text) / 2.0F + 2.0F, 20.0F, (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(20) : this.color, true);
      }

   }

   public void renderArrayList() {
   }

   public void renderTotemHUD() {
      int width = this.renderer.scaledWidth;
      int height = this.renderer.scaledHeight;
      int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter((itemStack) -> {
         return itemStack.func_77973_b() == Items.field_190929_cY;
      }).mapToInt(ItemStack::func_190916_E).sum();
      if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
         totems += mc.field_71439_g.func_184592_cb().func_190916_E();
      }

      if (totems > 0) {
         GlStateManager.func_179098_w();
         int i = width / 2;
         int iteration = false;
         int y = height - 55 - (mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f() ? 10 : 0);
         int x = i - 189 + 180 + 2;
         GlStateManager.func_179126_j();
         RenderUtil.itemRender.field_77023_b = 200.0F;
         RenderUtil.itemRender.func_180450_b(totem, x, y);
         RenderUtil.itemRender.func_180453_a(mc.field_71466_p, totem, x, y, "");
         RenderUtil.itemRender.field_77023_b = 0.0F;
         GlStateManager.func_179098_w();
         GlStateManager.func_179140_f();
         GlStateManager.func_179097_i();
         this.renderer.drawStringWithShadow(totems + "", (float)(x + 19 - 2 - this.renderer.getStringWidth(totems + "")), (float)(y + 9), 16777215);
         GlStateManager.func_179126_j();
         GlStateManager.func_179140_f();
      }

   }

   public void renderArmorHUD(boolean percent) {
      int width = this.renderer.scaledWidth;
      int height = this.renderer.scaledHeight;
      GlStateManager.func_179098_w();
      int i = width / 2;
      int iteration = 0;
      int y = height - 55 - (mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f() ? 10 : 0);
      Iterator var7 = mc.field_71439_g.field_71071_by.field_70460_b.iterator();

      while(var7.hasNext()) {
         ItemStack is = (ItemStack)var7.next();
         ++iteration;
         if (!is.func_190926_b()) {
            int x = i - 90 + (9 - iteration) * 20 + 2;
            GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = 200.0F;
            RenderUtil.itemRender.func_180450_b(is, x, y);
            RenderUtil.itemRender.func_180453_a(mc.field_71466_p, is, x, y, "");
            RenderUtil.itemRender.field_77023_b = 0.0F;
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            String s = is.func_190916_E() > 1 ? is.func_190916_E() + "" : "";
            this.renderer.drawStringWithShadow(s, (float)(x + 19 - 2 - this.renderer.getStringWidth(s)), (float)(y + 9), 16777215);
            if (percent) {
               int dmg = false;
               int itemDurability = is.func_77958_k() - is.func_77952_i();
               float green = ((float)is.func_77958_k() - (float)is.func_77952_i()) / (float)is.func_77958_k();
               float red = 1.0F - green;
               int dmg;
               if (percent) {
                  dmg = 100 - (int)(red * 100.0F);
               } else {
                  dmg = itemDurability;
               }

               this.renderer.drawStringWithShadow(dmg + "", (float)(x + 8 - this.renderer.getStringWidth(dmg + "") / 2), (float)(y - 11), ColorUtil.toRGBA((int)(red * 255.0F), (int)(green * 255.0F), 0));
            }
         }
      }

      GlStateManager.func_179126_j();
      GlStateManager.func_179140_f();
   }

   public void drawHitMarkers() {
      ScaledResolution resolution = new ScaledResolution(mc);
      RenderUtil.drawLine((float)resolution.func_78326_a() / 2.0F - 4.0F, (float)resolution.func_78328_b() / 2.0F - 4.0F, (float)resolution.func_78326_a() / 2.0F - 8.0F, (float)resolution.func_78328_b() / 2.0F - 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
      RenderUtil.drawLine((float)resolution.func_78326_a() / 2.0F + 4.0F, (float)resolution.func_78328_b() / 2.0F - 4.0F, (float)resolution.func_78326_a() / 2.0F + 8.0F, (float)resolution.func_78328_b() / 2.0F - 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
      RenderUtil.drawLine((float)resolution.func_78326_a() / 2.0F - 4.0F, (float)resolution.func_78328_b() / 2.0F + 4.0F, (float)resolution.func_78326_a() / 2.0F - 8.0F, (float)resolution.func_78328_b() / 2.0F + 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
      RenderUtil.drawLine((float)resolution.func_78326_a() / 2.0F + 4.0F, (float)resolution.func_78328_b() / 2.0F + 4.0F, (float)resolution.func_78326_a() / 2.0F + 8.0F, (float)resolution.func_78328_b() / 2.0F + 8.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255, 255));
   }

   public void drawTextRadar(int yOffset) {
      if (!this.players.isEmpty()) {
         int y = this.renderer.getFontHeight() + 7 + yOffset;

         int textheight;
         for(Iterator var3 = this.players.entrySet().iterator(); var3.hasNext(); y += textheight) {
            Entry<String, Integer> player = (Entry)var3.next();
            String text = (String)player.getKey() + " ";
            textheight = this.renderer.getFontHeight() + 1;
            this.renderer.drawString(text, 2.0F, (float)y, (Boolean)this.rolling.getValue() && (Boolean)this.rainbow.getValue() ? (Integer)this.colorMap.get(y) : this.color, true);
         }
      }

   }

   static {
      totem = new ItemStack(Items.field_190929_cY);
      codHitmarker = new ResourceLocation("nhack4sounds", "cod_hitmarker");
      csgoHitmarker = new ResourceLocation("nhack4sounds", "csgo_hitmarker");
      INSTANCE = new HUD();
   }

   public static enum Sound {
      NONE,
      COD,
      CSGO;
   }

   public static enum WaterMark {
      NONE,
      NHACK4;
   }

   public static enum LagNotify {
      NONE,
      RED,
      GRAY;
   }

   public static enum Greeter {
      NONE,
      NAME,
      TIME,
      CHRISTMAS,
      LONG,
      CUSTOM;
   }
}
