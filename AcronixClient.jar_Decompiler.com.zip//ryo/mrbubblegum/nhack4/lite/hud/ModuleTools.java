package ryo.mrbubblegum.nhack4.lite.hud;

import ryo.mrbubblegum.nhack4.impl.util.TextUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class ModuleTools extends Module {
   private static ModuleTools INSTANCE;
   public Setting<ModuleTools.Notifier> notifier;
   public Setting<ModuleTools.PopNotifier> popNotifier;
   public Setting<TextUtil.Color> abyssColor;

   public ModuleTools() {
      super("PopNotify", "Change settings", Module.Category.HUD, true, false, false);
      this.notifier = this.register(new Setting("ModuleNotifier", ModuleTools.Notifier.NHACK4));
      this.popNotifier = this.register(new Setting("PopNotifier", ModuleTools.PopNotifier.NONE));
      this.abyssColor = this.register(new Setting("AbyssTextColor", TextUtil.Color.AQUA, (color) -> {
         return this.notifier.getValue() == ModuleTools.Notifier.ABYSS;
      }));
      INSTANCE = this;
   }

   public static ModuleTools getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new ModuleTools();
      }

      return INSTANCE;
   }

   public static enum PopNotifier {
      PHOBOS,
      FUTURE,
      DOTGOD,
      NONE;
   }

   public static enum Notifier {
      NHACK4,
      FUTURE,
      DOTGOD,
      MUFFIN,
      WEATHER,
      SNOW,
      PYRO,
      CATALYST,
      KONAS,
      RUSHERHACK,
      LEGACY,
      EUROPA,
      ABYSS,
      LUIGIHACK;
   }
}
