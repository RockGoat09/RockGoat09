package ryo.mrbubblegum.nhack4.lite.misc;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class AntiSpam extends Module {
   public Setting<Boolean> Badwords = this.register(new Setting("BadWords", true));
   public Setting<Boolean> Links = this.register(new Setting("Links", true));
   public Setting<Boolean> Shop = this.register(new Setting("Shop", true));
   public Setting<Boolean> Kit = this.register(new Setting("Kit", true));
   public Setting<Boolean> Nig = this.register(new Setting("Racism", true));
   public Setting<Boolean> Discord = this.register(new Setting("Discord", true));
   public Setting<Boolean> YouTube = this.register(new Setting("YouTube", true));

   public AntiSpam() {
      super("AntiSpam", "nutella shop stop advsing in the chat", Module.Category.MISC, true, false, false);
   }

   @SubscribeEvent
   public void onClientChatReceive(ClientChatReceivedEvent e) {
      if ((Boolean)this.Links.getValue() && e.getMessage().func_150260_c().contains("http")) {
         e.setCanceled(true);
      }

      if ((Boolean)this.Shop.getValue() && e.getMessage().func_150260_c().contains("Shop") || e.getMessage().func_150260_c().contains("shop") || e.getMessage().func_150260_c().contains("Sh0p") || e.getMessage().func_150260_c().contains("sh0p") || e.getMessage().func_150260_c().contains("Buy") || e.getMessage().func_150260_c().contains("buy") || e.getMessage().func_150260_c().contains("sell") || e.getMessage().func_150260_c().contains("Sell") || e.getMessage().func_150260_c().contains("шоп") || e.getMessage().func_150260_c().contains("Шоп") || e.getMessage().func_150260_c().contains("маг") || e.getMessage().func_150260_c().contains("фед") || e.getMessage().func_150260_c().contains("бес")) {
         e.setCanceled(true);
      }

      if ((Boolean)this.Kit.getValue() && e.getMessage().func_150260_c().contains("Kit") || e.getMessage().func_150260_c().contains("kits") || e.getMessage().func_150260_c().contains("кит") || e.getMessage().func_150260_c().contains("Кит") || e.getMessage().func_150260_c().contains("К1т") || e.getMessage().func_150260_c().contains("к1т")) {
         e.setCanceled(true);
      }

      if ((Boolean)this.Nig.getValue() && e.getMessage().func_150260_c().contains("Nig") || e.getMessage().func_150260_c().contains("nig") || e.getMessage().func_150260_c().contains("n1g") || e.getMessage().func_150260_c().contains("Nig") || e.getMessage().func_150260_c().contains("N1g") || e.getMessage().func_150260_c().contains("Нег") || e.getMessage().func_150260_c().contains("нег")) {
         e.setCanceled(true);
      }

      if ((Boolean)this.Discord.getValue() && e.getMessage().func_150260_c().contains("disc") || e.getMessage().func_150260_c().contains("Disc") || e.getMessage().func_150260_c().contains("#") || e.getMessage().func_150260_c().contains("дис") || e.getMessage().func_150260_c().contains("Дис")) {
         e.setCanceled(true);
      }

      if ((Boolean)this.Badwords.getValue() && e.getMessage().func_150260_c().contains("fag") || e.getMessage().func_150260_c().contains("ped") || e.getMessage().func_150260_c().contains("dum") || e.getMessage().func_150260_c().contains("ass") || e.getMessage().func_150260_c().contains("fat") || e.getMessage().func_150260_c().contains("bitch") || e.getMessage().func_150260_c().contains("Bitch") || e.getMessage().func_150260_c().contains("fuc") || e.getMessage().func_150260_c().contains("dick") || e.getMessage().func_150260_c().contains("Ped") || e.getMessage().func_150260_c().contains("Dum") || e.getMessage().func_150260_c().contains("Ass") || e.getMessage().func_150260_c().contains("Fat") || e.getMessage().func_150260_c().contains("Fuc") || e.getMessage().func_150260_c().contains("Dick") || e.getMessage().func_150260_c().contains("ху") || e.getMessage().func_150260_c().contains("пиз") || e.getMessage().func_150260_c().contains("бл") || e.getMessage().func_150260_c().contains("моча") || e.getMessage().func_150260_c().contains("шлю") || e.getMessage().func_150260_c().contains("ху") || e.getMessage().func_150260_c().contains("еб") || e.getMessage().func_150260_c().contains("ёб") || e.getMessage().func_150260_c().contains("впиз") || e.getMessage().func_150260_c().contains("жоп") || e.getMessage().func_150260_c().contains("выб") || e.getMessage().func_150260_c().contains("дерьмо") || e.getMessage().func_150260_c().contains("сын") || e.getMessage().func_150260_c().contains("мам") || e.getMessage().func_150260_c().contains("дое") || e.getMessage().func_150260_c().contains("жир") || e.getMessage().func_150260_c().contains("жид") || e.getMessage().func_150260_c().contains("зае") || e.getMessage().func_150260_c().contains("нае") || e.getMessage().func_150260_c().contains("уеб") || e.getMessage().func_150260_c().contains("уёб") || e.getMessage().func_150260_c().contains("Ху") || e.getMessage().func_150260_c().contains("Пиз") || e.getMessage().func_150260_c().contains("Бл") || e.getMessage().func_150260_c().contains("Моча") || e.getMessage().func_150260_c().contains("Шлю") || e.getMessage().func_150260_c().contains("Ху") || e.getMessage().func_150260_c().contains("Еб") || e.getMessage().func_150260_c().contains("Ёб") || e.getMessage().func_150260_c().contains("Впиз") || e.getMessage().func_150260_c().contains("Жоп") || e.getMessage().func_150260_c().contains("Выб") || e.getMessage().func_150260_c().contains("Дерьмо") || e.getMessage().func_150260_c().contains("Сын") || e.getMessage().func_150260_c().contains("Мам") || e.getMessage().func_150260_c().contains("Дое") || e.getMessage().func_150260_c().contains("Жир") || e.getMessage().func_150260_c().contains("Жид") || e.getMessage().func_150260_c().contains("Зае") || e.getMessage().func_150260_c().contains("Нае") || e.getMessage().func_150260_c().contains("Уеб") || e.getMessage().func_150260_c().contains("Уёб") || e.getMessage().func_150260_c().contains("Ана") || e.getMessage().func_150260_c().contains("ана") || e.getMessage().func_150260_c().contains("Очк") || e.getMessage().func_150260_c().contains("очк") || e.getMessage().func_150260_c().contains("Су") || e.getMessage().func_150260_c().contains("су") || e.getMessage().func_150260_c().contains("ху")) {
         e.setCanceled(true);
      }

      if ((Boolean)this.YouTube.getValue() && e.getMessage().func_150260_c().contains("yt") || e.getMessage().func_150260_c().contains("tub") || e.getMessage().func_150260_c().contains("ash") || e.getMessage().func_150260_c().contains("заходи") || e.getMessage().func_150260_c().contains("join") || e.getMessage().func_150260_c().contains("ash") || e.getMessage().func_150260_c().contains("video") || e.getMessage().func_150260_c().contains("ют") || e.getMessage().func_150260_c().contains("канал") || e.getMessage().func_150260_c().contains("chan")) {
         e.setCanceled(true);
      }

   }
}
