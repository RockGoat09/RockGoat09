package ryo.mrbubblegum.nhack4.lite.misc;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.manager.FileManager;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.combat.AutoCrystal;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.DeathEvent;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;

public class AutoGG extends Module {
   private static final String path = "nhack4/autogg.txt";
   private final Setting<Boolean> onOwnDeath = this.register(new Setting("OwnDeath", false));
   private final Setting<Boolean> greentext = this.register(new Setting("Greentext", false));
   private final Setting<Boolean> loadFiles = this.register(new Setting("LoadFiles", false));
   private final Setting<Integer> targetResetTimer = this.register(new Setting("Reset", 30, 0, 90));
   private final Setting<Integer> delay = this.register(new Setting("Delay", 5, 0, 30));
   private final Setting<Boolean> test = this.register(new Setting("Test", false));
   private final Timer timer = new Timer();
   private final Timer cooldownTimer = new Timer();
   public Map<EntityPlayer, Integer> targets = new ConcurrentHashMap();
   public List<String> messages = new ArrayList();
   public EntityPlayer cauraTarget;
   private boolean cooldown;

   public AutoGG() {
      super("AutoGG", "Automatically GGs", Module.Category.MISC, true, false, true);
      File file = new File("nhack4/autogg.txt");
      if (!file.exists()) {
         try {
            file.createNewFile();
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }

   }

   public void onEnable() {
      this.loadMessages();
      this.timer.reset();
      this.cooldownTimer.reset();
   }

   public void onTick() {
      if ((Boolean)this.loadFiles.getValue()) {
         this.loadMessages();
         Command.sendMessage("<AutoGG> Loaded messages.");
         this.loadFiles.setValue(false);
      }

      if (AutoCrystal.target != null && this.cauraTarget != AutoCrystal.target) {
         this.cauraTarget = AutoCrystal.target;
      }

      if ((Boolean)this.test.getValue()) {
         this.announceDeath(mc.field_71439_g);
         this.test.setValue(false);
      }

      if (!this.cooldown) {
         this.cooldownTimer.reset();
      }

      if (this.cooldownTimer.passedS((double)(Integer)this.delay.getValue()) && this.cooldown) {
         this.cooldown = false;
         this.cooldownTimer.reset();
      }

      if (AutoCrystal.target != null) {
         this.targets.put(AutoCrystal.target, (int)(this.timer.getPassedTimeMs() / 1000L));
      }

      this.targets.replaceAll((p, v) -> {
         return (int)(this.timer.getPassedTimeMs() / 1000L);
      });
      Iterator var1 = this.targets.keySet().iterator();

      while(var1.hasNext()) {
         EntityPlayer player = (EntityPlayer)var1.next();
         if ((Integer)this.targets.get(player) > (Integer)this.targetResetTimer.getValue()) {
            this.targets.remove(player);
            this.timer.reset();
         }
      }

   }

   @SubscribeEvent
   public void onEntityDeath(DeathEvent event) {
      if (this.targets.containsKey(event.player) && !this.cooldown) {
         this.announceDeath(event.player);
         this.cooldown = true;
         this.targets.remove(event.player);
      }

      if (event.player == this.cauraTarget && !this.cooldown) {
         this.announceDeath(event.player);
         this.cooldown = true;
      }

      if (event.player == mc.field_71439_g && (Boolean)this.onOwnDeath.getValue()) {
         this.announceDeath(event.player);
         this.cooldown = true;
      }

   }

   @SubscribeEvent
   public void onAttackEntity(AttackEntityEvent event) {
      if (event.getTarget() instanceof EntityPlayer && !Loader.friendManager.isFriend(event.getEntityPlayer())) {
         this.targets.put((EntityPlayer)event.getTarget(), 0);
      }

   }

   @SubscribeEvent
   public void onSendAttackPacket(PacketEvent.Send event) {
      CPacketUseEntity packet;
      if (event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == Action.ATTACK && packet.func_149564_a(mc.field_71441_e) instanceof EntityPlayer && !Loader.friendManager.isFriend((EntityPlayer)packet.func_149564_a(mc.field_71441_e))) {
         this.targets.put((EntityPlayer)packet.func_149564_a(mc.field_71441_e), 0);
      }

   }

   public void loadMessages() {
      this.messages = FileManager.readTextFileAllLines("nhack4/autogg.txt");
   }

   public String getRandomMessage() {
      this.loadMessages();
      Random rand = new Random();
      if (this.messages.size() == 0) {
         return "<player> GET NHACK4 DAWG";
      } else {
         return this.messages.size() == 1 ? (String)this.messages.get(0) : (String)this.messages.get(MathUtil.clamp(rand.nextInt(this.messages.size()), 0, this.messages.size() - 1));
      }
   }

   public void announceDeath(EntityPlayer target) {
      mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage(((Boolean)this.greentext.getValue() ? ">" : "") + this.getRandomMessage().replaceAll("<player>", target.getDisplayNameString())));
   }
}
