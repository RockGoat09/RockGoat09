package ryo.mrbubblegum.nhack4.lite.misc;

import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import net.minecraft.init.SoundEvents;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import ryo.mrbubblegum.nhack4.impl.util.PlayerUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class StashFinder extends Module {
   private static final String pathSave = "nhack4/StashLogger.txt";
   public Setting<Integer> amount = this.register(new Setting("Amount", 15, 1, 100));
   public Setting<Boolean> hoppers = this.register(new Setting("Hoppers", true));
   public Setting<Boolean> shulkers = this.register(new Setting("Shulkers", true));
   public Setting<Boolean> dispensers = this.register(new Setting("Dispensers", true));
   public Setting<Boolean> droppers = this.register(new Setting("Droppers", true));
   public Setting<Boolean> chests = this.register(new Setting("Chests", true));
   public Setting<Boolean> windowsAlert = this.register(new Setting("WindowsAlert", true));
   public Setting<Boolean> sound = this.register(new Setting("Sound", true));
   public Setting<Boolean> chatMessage = this.register(new Setting("ChatMessage", true));
   private final Timer timer = new Timer();
   private final HashMap<Chunk, ArrayList<TileEntity>> map = new HashMap();
   private final ArrayList<Chunk> loggedChunks = new ArrayList();

   public StashFinder() {
      super("StashFinder", "dpsociety module", Module.Category.MISC, true, false, false);
   }

   public static void sendWindowsAlert(String message) {
      try {
         SystemTray tray = SystemTray.getSystemTray();
         Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
         TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
         trayIcon.setImageAutoSize(true);
         trayIcon.setToolTip("System tray icon demo");
         tray.add(trayIcon);
         trayIcon.displayMessage("Loader", message, MessageType.INFO);
      } catch (Exception var4) {
      }

   }

   public void onDisable() {
      this.loggedChunks.clear();
   }

   @SubscribeEvent
   public void onTick(ClientTickEvent e) {
      if (this.timer.passedMs(500L) && mc.field_71439_g != null && mc.field_71441_e != null && mc.field_71441_e.field_72996_f != null) {
         this.timer.reset();
         this.map.clear();
         Iterator var2 = mc.field_71441_e.field_147482_g.iterator();

         while(var2.hasNext()) {
            TileEntity tileEntity = (TileEntity)var2.next();
            if (this.isValid(tileEntity)) {
               Chunk chunk = mc.field_71441_e.func_175726_f(tileEntity.func_174877_v());
               ArrayList<TileEntity> list = new ArrayList();
               if (this.map.containsKey(chunk)) {
                  list = (ArrayList)this.map.get(chunk);
               }

               list.add(tileEntity);
               this.map.put(chunk, list);
            }
         }

         var2 = this.map.keySet().iterator();

         while(var2.hasNext()) {
            Chunk chunk = (Chunk)var2.next();
            if (((ArrayList)this.map.get(chunk)).size() >= (Integer)this.amount.getValue() && !this.loggedChunks.contains(chunk)) {
               this.loggedChunks.add(chunk);
               this.log(chunk, (ArrayList)this.map.get(chunk));
            }
         }
      }

   }

   public void log(Chunk chunk, ArrayList<TileEntity> list) {
      if (list.size() > 0) {
         int x = ((TileEntity)list.get(0)).func_174877_v().func_177958_n();
         int z = ((TileEntity)list.get(0)).func_174877_v().func_177952_p();
         if ((Boolean)this.chatMessage.getValue()) {
            Command.sendMessage("Stash located with " + list.size() + " on X: " + x + " Z: " + z);
         }

         if ((Boolean)this.sound.getValue()) {
            mc.field_71441_e.func_184156_a(PlayerUtil.getPlayerPos(), SoundEvents.field_187802_ec, SoundCategory.AMBIENT, 100.0F, 18.0F, true);
         }

         if ((Boolean)this.windowsAlert.getValue()) {
            sendWindowsAlert("Found the stem!");
         }

         (new Thread(() -> {
            try {
               File file = new File("nhack4/StashLogger.txt");
               if (!file.exists()) {
                  file.createNewFile();
               }

               BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true)));
               DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");
               LocalDateTime now = LocalDateTime.now();
               bw.write("X: " + x + " Z: " + z + " Found " + list.size() + " container blocks - " + dtf.format(now));
               bw.newLine();
               bw.close();
            } catch (Exception var7) {
               System.out.println(" - Error logging chunk. StashLogger");
               var7.printStackTrace();
            }

         })).start();
      }
   }

   public boolean isValid(TileEntity tileEntity) {
      return (Boolean)this.chests.getValue() && tileEntity instanceof TileEntityChest || (Boolean)this.droppers.getValue() && tileEntity instanceof TileEntityDropper || (Boolean)this.dispensers.getValue() && tileEntity instanceof TileEntityDispenser || (Boolean)this.shulkers.getValue() && tileEntity instanceof TileEntityShulkerBox || (Boolean)this.hoppers.getValue() && tileEntity instanceof TileEntityDropper;
   }
}
