package ryo.mrbubblegum.nhack4.lite.movement;

import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.PlayerUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.player.Freecam;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class FastFall extends Module {
   public Setting<Double> speed = this.register(new Setting("Speed", 3.0D, 0.1D, 10.0D));
   public Setting<Double> height = this.register(new Setting("Height", 10.0D, 0.1D, 90.0D));
   public Setting<Boolean> noLag = this.register(new Setting("NoLag", true));
   List<Block> incelBlocks;

   public FastFall() {
      super("FastFall", "reverse step", Module.Category.MOVEMENT, true, false, false);
      this.incelBlocks = Arrays.asList(Blocks.field_150324_C, Blocks.field_180399_cE);
   }

   public void onUpdate() {
      if (!fullNullCheck() && !this.shouldReturn()) {
         if (!(Boolean)this.noLag.getValue() || !Loader.packetManager.caughtPlayerPosLook()) {
            RayTraceResult trace = mc.field_71441_e.func_147447_a(mc.field_71439_g.func_174791_d(), new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - (Double)this.height.getValue(), mc.field_71439_g.field_70161_v), false, false, false);
            if (trace != null && trace.field_72313_a == Type.BLOCK && mc.field_71441_e.func_180495_p(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 0.1D, mc.field_71439_g.field_70161_v)).func_177230_c() != this.incelBlocks) {
               mc.field_71439_g.field_70181_x = -(Double)this.speed.getValue();
            }

         }
      }
   }

   boolean shouldReturn() {
      return mc.field_71439_g.func_184613_cA() || PlayerUtil.isClipping() || EntityUtil.isInLiquid() || mc.field_71439_g.func_70617_f_() || mc.field_71439_g.field_71075_bZ.field_75100_b || mc.field_71439_g.field_70181_x > 0.0D || mc.field_71474_y.field_74314_A.func_151470_d() || mc.field_71439_g.func_70094_T() || mc.field_71439_g.field_70145_X || !mc.field_71439_g.field_70122_E || Loader.moduleManager.isModuleEnabled("PacketFly") || Freecam.getInstance().isEnabled() || Loader.moduleManager.isModuleEnabled("PhaseWalk") || Loader.moduleManager.isModuleEnabled("LongJump") || Loader.moduleManager.isModuleEnabled("Strafe") || Loader.moduleManager.isModuleEnabled("SpeedNew");
   }
}
