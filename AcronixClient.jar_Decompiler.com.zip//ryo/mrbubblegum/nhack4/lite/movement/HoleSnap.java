package ryo.mrbubblegum.nhack4.lite.movement;

import java.util.Comparator;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.impl.util.utils.HoleUtilSafety;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;

public class HoleSnap extends Module {
   public HoleUtilSafety.Hole holes;
   public Setting<HoleSnap.Mode> mode;
   private final Setting<Float> range2;
   private final Setting<Boolean> SpeedCheck;
   private final Setting<Boolean> StepCheck;
   private final Setting<Float> range;
   public Setting<Float> timerfactor;
   Timer timer;
   private final Setting<Boolean> motionstop;
   private final int ticks;

   public HoleSnap() {
      super("HoleSnap", "hole tp dawg", Module.Category.MOVEMENT, true, false, false);
      this.mode = this.register(new Setting("SnapMode", HoleSnap.Mode.Motion));
      this.range2 = this.register(new Setting("Motion Range", 4.0F, 0.1F, 10.0F, (f) -> {
         return this.mode.getValue() == HoleSnap.Mode.Motion;
      }));
      this.SpeedCheck = this.register(new Setting("Disable Speed", true, (v) -> {
         return this.mode.getValue() == HoleSnap.Mode.Motion;
      }));
      this.StepCheck = this.register(new Setting("Disable Step", true, (v) -> {
         return this.mode.getValue() == HoleSnap.Mode.Motion;
      }));
      this.range = this.register(new Setting("Instant Range", 0.5F, 0.1F, 5.0F, (f) -> {
         return this.mode.getValue() == HoleSnap.Mode.Instant;
      }));
      this.timerfactor = this.register(new Setting("Timer", 2.0F, 1.0F, 5.0F, (f) -> {
         return this.mode.getValue() == HoleSnap.Mode.Motion;
      }));
      this.timer = new Timer();
      this.motionstop = this.register(new Setting("StopMotion", true, (v) -> {
         return this.mode.getValue() == HoleSnap.Mode.Motion;
      }));
      this.ticks = 0;
   }

   public static HoleUtilSafety.Hole getTargetHoleVec3D(double d) {
      return (HoleUtilSafety.Hole)HoleUtilSafety.getHoles(d, getPlayerPos(), false).stream().filter((hole) -> {
         return mc.field_71439_g.func_174791_d().func_72438_d(new Vec3d((double)hole.pos1.func_177958_n() + 0.5D, mc.field_71439_g.field_70163_u, (double)hole.pos1.func_177952_p() + 0.5D)) <= d;
      }).min(Comparator.comparingDouble((hole) -> {
         return mc.field_71439_g.func_174791_d().func_72438_d(new Vec3d((double)hole.pos1.func_177958_n() + 0.5D, mc.field_71439_g.field_70163_u, (double)hole.pos1.func_177952_p() + 0.5D));
      })).orElse((Object)null);
   }

   public static BlockPos getPlayerPos() {
      double d = mc.field_71439_g.field_70163_u - Math.floor(mc.field_71439_g.field_70163_u);
      return new BlockPos(mc.field_71439_g.field_70165_t, d > 0.8D ? Math.floor(mc.field_71439_g.field_70163_u) + 1.0D : Math.floor(mc.field_71439_g.field_70163_u), mc.field_71439_g.field_70161_v);
   }

   public static Vec2f getRotationTo(Vec3d vec3d, Vec3d vec3d2) {
      return getRotationFromVec(vec3d.func_178788_d(vec3d2));
   }

   public static Vec2f getRotationFromVec(Vec3d vec3d) {
      double d = Math.hypot(vec3d.field_72450_a, vec3d.field_72449_c);
      float f = (float)normalizeAngle(Math.toDegrees(Math.atan2(vec3d.field_72449_c, vec3d.field_72450_a)) - 90.0D);
      float f2 = (float)normalizeAngle(Math.toDegrees(-Math.atan2(vec3d.field_72448_b, d)));
      return new Vec2f(f, f2);
   }

   public static double normalizeAngle(Double d) {
      double d2 = 0.0D;
      double d3 = d;
      d3 %= 360.0D;
      if (d2 >= 180.0D) {
         d3 -= 360.0D;
      }

      if (d3 < -180.0D) {
         d3 += 360.0D;
      }

      return d3;
   }

   public void onTick() {
      BlockPos blockPos2;
      if (this.mode.getValue() == HoleSnap.Mode.Instant) {
         blockPos2 = (BlockPos)Loader.holeManager.calcHoles().stream().min(Comparator.comparing((blockPos) -> {
            return mc.field_71439_g.func_70011_f((double)blockPos.func_177958_n(), (double)blockPos.func_177956_o(), (double)blockPos.func_177952_p());
         })).orElse((Object)null);
         if (blockPos2 != null) {
            if (mc.field_71439_g.func_70011_f((double)blockPos2.func_177958_n(), (double)blockPos2.func_177956_o(), (double)blockPos2.func_177952_p()) < (double)(Float)this.range.getValue() + 1.5D) {
               mc.field_71439_g.func_70107_b((double)blockPos2.func_177958_n() + 0.5D, (double)blockPos2.func_177956_o(), (double)blockPos2.func_177952_p() + 0.5D);
               mc.field_71439_g.func_70107_b((double)blockPos2.func_177958_n() + 0.5D, (double)blockPos2.func_177956_o(), (double)blockPos2.func_177952_p() + 0.5D);
               Command.sendMessage("Accepting Teleport");
            } else {
               Command.sendMessage("Out of range. disabling HoleSnap");
            }
         } else {
            Command.sendMessage("Unable to find hole, disabling HoleSnap");
         }

         this.disable();
      }

      if (this.mode.getValue() == HoleSnap.Mode.Motion) {
         if (fullNullCheck()) {
            return;
         }

         if (EntityUtil.isInLiquid()) {
            this.disable();
            return;
         }

         mc.field_71428_T.field_194149_e = 50.0F / (Float)this.timerfactor.getValue();
         this.holes = getTargetHoleVec3D((double)(Float)this.range2.getValue());
         if (this.holes == null) {
            Command.sendMessage("Unable to find hole, disabling HoleSnap");
            this.disable();
            return;
         }

         if (this.timer.passedMs(500L)) {
            this.disable();
            return;
         }

         if (HoleUtilSafety.isObbyHole(getPlayerPos()) || HoleUtilSafety.isBedrockHoles(getPlayerPos())) {
            this.disable();
            return;
         }

         if (mc.field_71441_e.func_180495_p(this.holes.pos1).func_177230_c() != Blocks.field_150350_a) {
            this.disable();
            return;
         }

         blockPos2 = this.holes.pos1;
         Vec3d vec3d = mc.field_71439_g.func_174791_d();
         Vec3d vec3d2 = new Vec3d((double)blockPos2.func_177958_n() + 0.5D, mc.field_71439_g.field_70163_u, (double)blockPos2.func_177952_p() + 0.5D);
         double d = Math.toRadians((double)getRotationTo(vec3d, vec3d2).field_189982_i);
         double d2 = vec3d.func_72438_d(vec3d2);
         double d3 = mc.field_71439_g.field_70122_E ? -Math.min(0.2805D, d2 / 2.0D) : -EntityUtil.getMaxSpeed() + 0.02D;
         mc.field_71439_g.field_70159_w = -Math.sin(d) * d3;
         mc.field_71439_g.field_70179_y = Math.cos(d) * d3;
      }

   }

   public void onDisable() {
      this.timer.reset();
      this.holes = null;
      mc.field_71428_T.field_194149_e = 50.0F;
   }

   public void onEnable() {
      if (this.mode.getValue() == HoleSnap.Mode.Motion && (Boolean)this.motionstop.getValue()) {
         mc.field_71439_g.field_70159_w = 0.0D;
         mc.field_71439_g.field_70179_y = 0.0D;
      }

      if ((Boolean)this.SpeedCheck.getValue() && SpeedNew.getInstance().isOn()) {
         SpeedNew.getInstance().disable();
         Command.sendMessage("<HoleSnap> Disable Speed");
      }

      if ((Boolean)this.StepCheck.getValue() && Step.getInstance().isOn()) {
         Step.getInstance().disable();
         Command.sendMessage("<HoleSnap> Disable Step");
      }

      if (!fullNullCheck()) {
         this.timer.reset();
         this.holes = null;
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Receive receive) {
      if (!this.isDisabled()) {
         if (receive.getPacket() instanceof SPacketPlayerPosLook) {
            this.disable();
         }

      }
   }

   public static enum Mode {
      Instant,
      Motion;
   }
}
