package ryo.mrbubblegum.nhack4.lite.movement;

import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.PlayerUpdateMoveEvent;
import ryo.mrbubblegum.nhack4.world.events.KeyEvent;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;

public class NoSlowDown extends Module {
   private static final KeyBinding[] keys;
   public Setting<NoSlowDown.ItemMode> itemMode;
   public Setting<Boolean> items;
   public Setting<Boolean> guiMove;
   public Setting<Boolean> sneak;
   boolean sneakingFlag;

   public NoSlowDown() {
      super("NoSlow", "no need to explain", Module.Category.MOVEMENT, true, false, false);
      this.itemMode = this.register(new Setting("ItemMode", NoSlowDown.ItemMode.Normal));
      this.items = this.register(new Setting("Items", true));
      this.guiMove = this.register(new Setting("GuiMove", true));
      this.sneak = this.register(new Setting("Sneak", false));
   }

   @SubscribeEvent
   public void onUpdate(PlayerUpdateMoveEvent event) {
      if ((Boolean)this.guiMove.getValue()) {
         KeyBinding[] var2;
         int var3;
         int var4;
         KeyBinding bind;
         if (!(mc.field_71462_r instanceof GuiOptions) && !(mc.field_71462_r instanceof GuiVideoSettings) && !(mc.field_71462_r instanceof GuiScreenOptionsSounds) && !(mc.field_71462_r instanceof GuiContainer) && !(mc.field_71462_r instanceof GuiIngameMenu)) {
            if (mc.field_71462_r == null) {
               var2 = keys;
               var3 = var2.length;

               for(var4 = 0; var4 < var3; ++var4) {
                  bind = var2[var4];
                  if (!Keyboard.isKeyDown(bind.func_151463_i())) {
                     KeyBinding.func_74510_a(bind.func_151463_i(), false);
                  }
               }
            }
         } else {
            var2 = keys;
            var3 = var2.length;

            for(var4 = 0; var4 < var3; ++var4) {
               bind = var2[var4];
               KeyBinding.func_74510_a(bind.func_151463_i(), Keyboard.isKeyDown(bind.func_151463_i()));
            }
         }
      }

      if (this.itemMode.getValue() == NoSlowDown.ItemMode._2B2TSneak && !Util.mc.field_71439_g.func_70093_af() && !Util.mc.field_71439_g.func_184218_aH()) {
         if (Util.mc.field_71439_g.func_184587_cr()) {
            Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(Util.mc.field_71439_g, Action.START_SNEAKING));
            this.sneakingFlag = true;
         } else if (this.sneakingFlag) {
            Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(Util.mc.field_71439_g, Action.STOP_SNEAKING));
            this.sneakingFlag = false;
         }
      }

   }

   @SubscribeEvent
   public void onInput(InputUpdateEvent event) {
      if ((Boolean)this.items.getValue() && Util.mc.field_71439_g.func_184587_cr() && !Util.mc.field_71439_g.func_184218_aH() || (Boolean)this.sneak.getValue() && Util.mc.field_71439_g.func_70093_af()) {
         MovementInput var10000 = event.getMovementInput();
         var10000.field_192832_b /= 0.2F;
         var10000 = event.getMovementInput();
         var10000.field_78902_a /= 0.2F;
      }

   }

   @SubscribeEvent
   public void onKeyEvent(KeyEvent event) {
      if ((Boolean)this.guiMove.getValue() && event.getStage() == 0 && !(mc.field_71462_r instanceof GuiChat)) {
         event.info = event.pressed;
      }

   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send event) {
      if (event.getPacket() instanceof CPacketPlayer && (Boolean)this.items.getValue() && Util.mc.field_71439_g.func_184587_cr() && !Util.mc.field_71439_g.func_184218_aH()) {
         switch((NoSlowDown.ItemMode)this.itemMode.getValue()) {
         case NCPStrict:
            Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(net.minecraft.network.play.client.CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, new BlockPos(Math.floor(Util.mc.field_71439_g.field_70165_t), Math.floor(Util.mc.field_71439_g.field_70163_u), Math.floor(Util.mc.field_71439_g.field_70161_v)), EnumFacing.DOWN));
            break;
         case _2B2TBypass:
            Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(Util.mc.field_71439_g.field_71071_by.field_70461_c));
         }
      }

   }

   static {
      keys = new KeyBinding[]{mc.field_71474_y.field_74351_w, mc.field_71474_y.field_74368_y, mc.field_71474_y.field_74370_x, mc.field_71474_y.field_74366_z, mc.field_71474_y.field_74314_A, mc.field_71474_y.field_151444_V};
   }

   public static enum ItemMode {
      Normal,
      NCPStrict,
      _2B2TSneak,
      _2B2TBypass;
   }
}
