package ryo.mrbubblegum.nhack4.lite.movement;

import java.util.Objects;
import java.util.Random;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovementInput;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.BlockUtil;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.MathUtil;
import ryo.mrbubblegum.nhack4.impl.util.MovementUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.ClientEvent;
import ryo.mrbubblegum.nhack4.world.events.MoveEvent;
import ryo.mrbubblegum.nhack4.world.events.UpdateWalkingPlayerEvent;

public class Speed extends Module {
   private static Speed INSTANCE = new Speed();
   public Setting<Speed.Mode> mode;
   public Setting<Boolean> strafeJump;
   public Setting<Boolean> noShake;
   public Setting<Boolean> useTimer;
   public Setting<Double> zeroSpeed;
   public Setting<Double> speed;
   public Setting<Double> blocked;
   public Setting<Double> unblocked;
   public Setting<Boolean> motionyonoff;
   public Setting<Double> yspeed;
   public double startY;
   public boolean antiShake;
   public double minY;
   public boolean changeY;
   private double highChainVal;
   private double lowChainVal;
   private boolean oneTime;
   private double bounceHeight;
   private float move;
   private int vanillaCounter;

   public Speed() {
      super("Speed", "Makes you faster.", Module.Category.MOVEMENT, true, false, false);
      this.mode = this.register(new Setting("Mode", Speed.Mode.INSTANT));
      this.strafeJump = this.register(new Setting("Jump", false, (v) -> {
         return this.mode.getValue() == Speed.Mode.INSTANT;
      }));
      this.noShake = this.register(new Setting("NoShake", true, (v) -> {
         return this.mode.getValue() != Speed.Mode.INSTANT;
      }));
      this.useTimer = this.register(new Setting("UseTimer", false, (v) -> {
         return this.mode.getValue() != Speed.Mode.INSTANT;
      }));
      this.zeroSpeed = this.register(new Setting("0-Speed", 0.0D, 0.0D, 100.0D, (v) -> {
         return this.mode.getValue() == Speed.Mode.VANILLA;
      }));
      this.speed = this.register(new Setting("Speed", 10.0D, 0.1D, 100.0D, (v) -> {
         return this.mode.getValue() == Speed.Mode.VANILLA;
      }));
      this.blocked = this.register(new Setting("Blocked", 10.0D, 0.0D, 100.0D, (v) -> {
         return this.mode.getValue() == Speed.Mode.VANILLA;
      }));
      this.unblocked = this.register(new Setting("Unblocked", 10.0D, 0.0D, 100.0D, (v) -> {
         return this.mode.getValue() == Speed.Mode.VANILLA;
      }));
      this.motionyonoff = this.register(new Setting("MotionYOnOff", false, (v) -> {
         return this.mode.getValue() == Speed.Mode.YPORT;
      }));
      this.yspeed = this.register(new Setting("YSpeed", 1.0D, 0.1D, 10.0D, (v) -> {
         return this.mode.getValue() == Speed.Mode.YPORT;
      }));
      this.bounceHeight = 0.4D;
      this.move = 0.26F;
      this.setInstance();
   }

   public static Speed getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Speed();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   private boolean shouldReturn() {
      return Loader.moduleManager.isModuleEnabled("Freecam") || Loader.moduleManager.isModuleEnabled("PacketFly") || Loader.moduleManager.isModuleEnabled("ElytraFlight") || Loader.moduleManager.isModuleEnabled("Strafe") || Loader.moduleManager.isModuleEnabled("Flight") || Loader.moduleManager.isModuleEnabled("SpeedNew");
   }

   public void onUpdate() {
      if (!this.shouldReturn() && !mc.field_71439_g.func_70093_af() && !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab()) {
         switch((Speed.Mode)this.mode.getValue()) {
         case BOOST:
            this.doBoost();
            break;
         case ACCEL:
            this.doAccel();
            break;
         case YPORT:
            this.handleYPortSpeed();
            break;
         case ONGROUND:
            this.doOnground();
         }

      }
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
      if (this.mode.getValue() == Speed.Mode.VANILLA && !nullCheck()) {
         switch(event.getStage()) {
         case 0:
            int n = this.vanillaCounter = this.vanilla() ? ++this.vanillaCounter : 0;
            if (this.vanillaCounter == 4) {
               this.changeY = true;
               this.minY = mc.field_71439_g.func_174813_aQ().field_72338_b + (mc.field_71441_e.func_180495_p(mc.field_71439_g.func_180425_c()).func_185904_a().func_76230_c() ? -(Double)this.blocked.getValue() / 10.0D : (Double)this.unblocked.getValue() / 10.0D) + this.getJumpBoostModifier();
               return;
            }
            break;
         case 1:
            EntityPlayerSP var10000;
            if (this.vanillaCounter == 3) {
               var10000 = mc.field_71439_g;
               var10000.field_70159_w *= (Double)this.zeroSpeed.getValue() / 10.0D;
               var10000 = mc.field_71439_g;
               var10000.field_70179_y *= (Double)this.zeroSpeed.getValue() / 10.0D;
            } else if (this.vanillaCounter == 4) {
               var10000 = mc.field_71439_g;
               var10000.field_70159_w /= (Double)this.speed.getValue() / 10.0D;
               var10000 = mc.field_71439_g;
               var10000.field_70179_y /= (Double)this.speed.getValue() / 10.0D;
               this.vanillaCounter = 2;
            }
         }

      }
   }

   private double getJumpBoostModifier() {
      double boost = 0.0D;
      if (mc.field_71439_g.func_70644_a(MobEffects.field_76430_j)) {
         int amplifier = ((PotionEffect)Objects.requireNonNull(mc.field_71439_g.func_70660_b(MobEffects.field_76430_j))).func_76458_c();
         boost *= 1.0D + 0.2D * (double)amplifier;
      }

      return boost;
   }

   private boolean vanilla() {
      return mc.field_71439_g.field_70122_E;
   }

   private void handleYPortSpeed() {
      if (MovementUtil.isMoving(mc.field_71439_g) && (!mc.field_71439_g.func_70090_H() || !mc.field_71439_g.func_180799_ab()) && !mc.field_71439_g.field_70123_F) {
         if (mc.field_71439_g.field_70122_E) {
            mc.field_71439_g.func_70664_aZ();
            MovementUtil.setSpeed(mc.field_71439_g, MovementUtil.getBaseMoveSpeed() + (Double)this.yspeed.getValue());
         } else {
            mc.field_71439_g.field_70181_x = -1.0D;
         }

      }
   }

   private void doBoost() {
      this.bounceHeight = 0.4D;
      this.move = 0.26F;
      if (mc.field_71439_g.field_70122_E) {
         this.startY = mc.field_71439_g.field_70163_u;
      }

      if (EntityUtil.getEntitySpeed(mc.field_71439_g) <= 1.0D) {
         this.lowChainVal = 1.0D;
         this.highChainVal = 1.0D;
      }

      if (EntityUtil.isEntityMoving(mc.field_71439_g) && !mc.field_71439_g.field_70123_F && !BlockUtil.isBlockAboveEntitySolid(mc.field_71439_g) && BlockUtil.isBlockBelowEntitySolid(mc.field_71439_g)) {
         this.oneTime = true;
         this.antiShake = (Boolean)this.noShake.getValue() && mc.field_71439_g.func_184187_bx() == null;
         Random random = new Random();
         boolean rnd = random.nextBoolean();
         if (mc.field_71439_g.field_70163_u >= this.startY + this.bounceHeight) {
            mc.field_71439_g.field_70181_x = -this.bounceHeight;
            ++this.lowChainVal;
            if (this.lowChainVal == 1.0D) {
               this.move = 0.075F;
            }

            if (this.lowChainVal == 2.0D) {
               this.move = 0.15F;
            }

            if (this.lowChainVal == 3.0D) {
               this.move = 0.175F;
            }

            if (this.lowChainVal == 4.0D) {
               this.move = 0.2F;
            }

            if (this.lowChainVal == 5.0D) {
               this.move = 0.225F;
            }

            if (this.lowChainVal == 6.0D) {
               this.move = 0.25F;
            }

            if (this.lowChainVal >= 7.0D) {
               this.move = 0.27895F;
            }

            if ((Boolean)this.useTimer.getValue()) {
               Loader.timerManager.setTimer(1.0F);
            }
         }

         if (mc.field_71439_g.field_70163_u == this.startY) {
            mc.field_71439_g.field_70181_x = this.bounceHeight;
            ++this.highChainVal;
            if (this.highChainVal == 1.0D) {
               this.move = 0.075F;
            }

            if (this.highChainVal == 2.0D) {
               this.move = 0.175F;
            }

            if (this.highChainVal == 3.0D) {
               this.move = 0.325F;
            }

            if (this.highChainVal == 4.0D) {
               this.move = 0.375F;
            }

            if (this.highChainVal == 5.0D) {
               this.move = 0.4F;
            }

            if (this.highChainVal >= 6.0D) {
               this.move = 0.43395F;
            }

            if ((Boolean)this.useTimer.getValue()) {
               if (rnd) {
                  Loader.timerManager.setTimer(1.3F);
               } else {
                  Loader.timerManager.setTimer(1.0F);
               }
            }
         }

         EntityUtil.moveEntityStrafe((double)this.move, mc.field_71439_g);
      } else {
         if (this.oneTime) {
            mc.field_71439_g.field_70181_x = -0.1D;
            this.oneTime = false;
         }

         this.highChainVal = 0.0D;
         this.lowChainVal = 0.0D;
         this.antiShake = false;
         this.speedOff();
      }

   }

   private void doAccel() {
      this.bounceHeight = 0.4D;
      this.move = 0.26F;
      if (mc.field_71439_g.field_70122_E) {
         this.startY = mc.field_71439_g.field_70163_u;
      }

      if (EntityUtil.getEntitySpeed(mc.field_71439_g) <= 1.0D) {
         this.lowChainVal = 1.0D;
         this.highChainVal = 1.0D;
      }

      if (EntityUtil.isEntityMoving(mc.field_71439_g) && !mc.field_71439_g.field_70123_F && !BlockUtil.isBlockAboveEntitySolid(mc.field_71439_g) && BlockUtil.isBlockBelowEntitySolid(mc.field_71439_g)) {
         this.oneTime = true;
         this.antiShake = (Boolean)this.noShake.getValue() && mc.field_71439_g.func_184187_bx() == null;
         Random random = new Random();
         boolean rnd = random.nextBoolean();
         if (mc.field_71439_g.field_70163_u >= this.startY + this.bounceHeight) {
            mc.field_71439_g.field_70181_x = -this.bounceHeight;
            ++this.lowChainVal;
            if (this.lowChainVal == 1.0D) {
               this.move = 0.075F;
            }

            if (this.lowChainVal == 2.0D) {
               this.move = 0.175F;
            }

            if (this.lowChainVal == 3.0D) {
               this.move = 0.275F;
            }

            if (this.lowChainVal == 4.0D) {
               this.move = 0.35F;
            }

            if (this.lowChainVal == 5.0D) {
               this.move = 0.375F;
            }

            if (this.lowChainVal == 6.0D) {
               this.move = 0.4F;
            }

            if (this.lowChainVal == 7.0D) {
               this.move = 0.425F;
            }

            if (this.lowChainVal == 8.0D) {
               this.move = 0.45F;
            }

            if (this.lowChainVal == 9.0D) {
               this.move = 0.475F;
            }

            if (this.lowChainVal == 10.0D) {
               this.move = 0.5F;
            }

            if (this.lowChainVal == 11.0D) {
               this.move = 0.5F;
            }

            if (this.lowChainVal == 12.0D) {
               this.move = 0.525F;
            }

            if (this.lowChainVal == 13.0D) {
               this.move = 0.525F;
            }

            if (this.lowChainVal == 14.0D) {
               this.move = 0.535F;
            }

            if (this.lowChainVal == 15.0D) {
               this.move = 0.535F;
            }

            if (this.lowChainVal == 16.0D) {
               this.move = 0.545F;
            }

            if (this.lowChainVal >= 17.0D) {
               this.move = 0.545F;
            }

            if ((Boolean)this.useTimer.getValue()) {
               Loader.timerManager.setTimer(1.0F);
            }
         }

         if (mc.field_71439_g.field_70163_u == this.startY) {
            mc.field_71439_g.field_70181_x = this.bounceHeight;
            ++this.highChainVal;
            if (this.highChainVal == 1.0D) {
               this.move = 0.075F;
            }

            if (this.highChainVal == 2.0D) {
               this.move = 0.175F;
            }

            if (this.highChainVal == 3.0D) {
               this.move = 0.375F;
            }

            if (this.highChainVal == 4.0D) {
               this.move = 0.6F;
            }

            if (this.highChainVal == 5.0D) {
               this.move = 0.775F;
            }

            if (this.highChainVal == 6.0D) {
               this.move = 0.825F;
            }

            if (this.highChainVal == 7.0D) {
               this.move = 0.875F;
            }

            if (this.highChainVal == 8.0D) {
               this.move = 0.925F;
            }

            if (this.highChainVal == 9.0D) {
               this.move = 0.975F;
            }

            if (this.highChainVal == 10.0D) {
               this.move = 1.05F;
            }

            if (this.highChainVal == 11.0D) {
               this.move = 1.1F;
            }

            if (this.highChainVal == 12.0D) {
               this.move = 1.1F;
            }

            if (this.highChainVal == 13.0D) {
               this.move = 1.15F;
            }

            if (this.highChainVal == 14.0D) {
               this.move = 1.15F;
            }

            if (this.highChainVal == 15.0D) {
               this.move = 1.175F;
            }

            if (this.highChainVal == 16.0D) {
               this.move = 1.175F;
            }

            if (this.highChainVal >= 17.0D) {
               this.move = 1.175F;
            }

            if ((Boolean)this.useTimer.getValue()) {
               if (rnd) {
                  Loader.timerManager.setTimer(1.3F);
               } else {
                  Loader.timerManager.setTimer(1.0F);
               }
            }
         }

         EntityUtil.moveEntityStrafe((double)this.move, mc.field_71439_g);
      } else {
         if (this.oneTime) {
            mc.field_71439_g.field_70181_x = -0.1D;
            this.oneTime = false;
         }

         this.antiShake = false;
         this.highChainVal = 0.0D;
         this.lowChainVal = 0.0D;
         this.speedOff();
      }

   }

   private void doOnground() {
      this.bounceHeight = 0.4D;
      this.move = 0.26F;
      if (mc.field_71439_g.field_70122_E) {
         this.startY = mc.field_71439_g.field_70163_u;
      }

      if (EntityUtil.getEntitySpeed(mc.field_71439_g) <= 1.0D) {
         this.lowChainVal = 1.0D;
         this.highChainVal = 1.0D;
      }

      if (EntityUtil.isEntityMoving(mc.field_71439_g) && !mc.field_71439_g.field_70123_F && !BlockUtil.isBlockAboveEntitySolid(mc.field_71439_g) && BlockUtil.isBlockBelowEntitySolid(mc.field_71439_g)) {
         this.oneTime = true;
         this.antiShake = (Boolean)this.noShake.getValue() && mc.field_71439_g.func_184187_bx() == null;
         Random random = new Random();
         boolean rnd = random.nextBoolean();
         if (mc.field_71439_g.field_70163_u >= this.startY + this.bounceHeight) {
            mc.field_71439_g.field_70181_x = -this.bounceHeight;
            ++this.lowChainVal;
            if (this.lowChainVal == 1.0D) {
               this.move = 0.075F;
            }

            if (this.lowChainVal == 2.0D) {
               this.move = 0.175F;
            }

            if (this.lowChainVal == 3.0D) {
               this.move = 0.275F;
            }

            if (this.lowChainVal == 4.0D) {
               this.move = 0.35F;
            }

            if (this.lowChainVal == 5.0D) {
               this.move = 0.375F;
            }

            if (this.lowChainVal == 6.0D) {
               this.move = 0.4F;
            }

            if (this.lowChainVal == 7.0D) {
               this.move = 0.425F;
            }

            if (this.lowChainVal == 8.0D) {
               this.move = 0.45F;
            }

            if (this.lowChainVal == 9.0D) {
               this.move = 0.475F;
            }

            if (this.lowChainVal == 10.0D) {
               this.move = 0.5F;
            }

            if (this.lowChainVal == 11.0D) {
               this.move = 0.5F;
            }

            if (this.lowChainVal == 12.0D) {
               this.move = 0.525F;
            }

            if (this.lowChainVal == 13.0D) {
               this.move = 0.525F;
            }

            if (this.lowChainVal == 14.0D) {
               this.move = 0.535F;
            }

            if (this.lowChainVal == 15.0D) {
               this.move = 0.535F;
            }

            if (this.lowChainVal == 16.0D) {
               this.move = 0.545F;
            }

            if (this.lowChainVal >= 17.0D) {
               this.move = 0.545F;
            }

            if ((Boolean)this.useTimer.getValue()) {
               Loader.timerManager.setTimer(1.0F);
            }
         }

         if (mc.field_71439_g.field_70163_u == this.startY) {
            mc.field_71439_g.field_70181_x = this.bounceHeight;
            ++this.highChainVal;
            if (this.highChainVal == 1.0D) {
               this.move = 0.075F;
            }

            if (this.highChainVal == 2.0D) {
               this.move = 0.175F;
            }

            if (this.highChainVal == 3.0D) {
               this.move = 0.375F;
            }

            if (this.highChainVal == 4.0D) {
               this.move = 0.6F;
            }

            if (this.highChainVal == 5.0D) {
               this.move = 0.775F;
            }

            if (this.highChainVal == 6.0D) {
               this.move = 0.825F;
            }

            if (this.highChainVal == 7.0D) {
               this.move = 0.875F;
            }

            if (this.highChainVal == 8.0D) {
               this.move = 0.925F;
            }

            if (this.highChainVal == 9.0D) {
               this.move = 0.975F;
            }

            if (this.highChainVal == 10.0D) {
               this.move = 1.05F;
            }

            if (this.highChainVal == 11.0D) {
               this.move = 1.1F;
            }

            if (this.highChainVal == 12.0D) {
               this.move = 1.1F;
            }

            if (this.highChainVal == 13.0D) {
               this.move = 1.15F;
            }

            if (this.highChainVal == 14.0D) {
               this.move = 1.15F;
            }

            if (this.highChainVal == 15.0D) {
               this.move = 1.175F;
            }

            if (this.highChainVal == 16.0D) {
               this.move = 1.175F;
            }

            if (this.highChainVal >= 17.0D) {
               this.move = 1.2F;
            }

            if ((Boolean)this.useTimer.getValue()) {
               if (rnd) {
                  Loader.timerManager.setTimer(1.3F);
               } else {
                  Loader.timerManager.setTimer(1.0F);
               }
            }
         }

         EntityUtil.moveEntityStrafe((double)this.move, mc.field_71439_g);
      } else {
         if (this.oneTime) {
            mc.field_71439_g.field_70181_x = -0.1D;
            this.oneTime = false;
         }

         this.antiShake = false;
         this.highChainVal = 0.0D;
         this.lowChainVal = 0.0D;
         this.speedOff();
      }

   }

   public void onDisable() {
      if (this.mode.getValue() == Speed.Mode.ONGROUND || this.mode.getValue() == Speed.Mode.BOOST) {
         mc.field_71439_g.field_70181_x = -0.1D;
      }

      this.changeY = false;
      Loader.timerManager.setTimer(1.0F);
      this.highChainVal = 0.0D;
      this.lowChainVal = 0.0D;
      this.antiShake = false;
      if (this.mode.getValue() == Speed.Mode.YPORT && (Boolean)this.motionyonoff.getValue()) {
         mc.field_71439_g.field_70181_x = -3.0D;
      }

   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent event) {
      if (event.getStage() == 2 && event.getSetting().equals(this.mode) && this.mode.getPlannedValue() == Speed.Mode.INSTANT) {
         mc.field_71439_g.field_70181_x = -0.1D;
      }

   }

   public String getDisplayInfo() {
      return this.mode.currentEnumName();
   }

   @SubscribeEvent
   public void onMode(MoveEvent event) {
      if (!this.shouldReturn() && event.getStage() == 0 && this.mode.getValue() == Speed.Mode.INSTANT && !nullCheck() && !mc.field_71439_g.func_70093_af() && !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab() && (mc.field_71439_g.field_71158_b.field_192832_b != 0.0F || mc.field_71439_g.field_71158_b.field_78902_a != 0.0F)) {
         if (mc.field_71439_g.field_70122_E && (Boolean)this.strafeJump.getValue()) {
            mc.field_71439_g.field_70181_x = 0.4D;
            event.setY(0.4D);
         }

         MovementInput movementInput = mc.field_71439_g.field_71158_b;
         float moveForward = movementInput.field_192832_b;
         float moveStrafe = movementInput.field_78902_a;
         float rotationYaw = mc.field_71439_g.field_70177_z;
         if ((double)moveForward == 0.0D && (double)moveStrafe == 0.0D) {
            event.setX(0.0D);
            event.setZ(0.0D);
         } else {
            if ((double)moveForward != 0.0D) {
               if ((double)moveStrafe > 0.0D) {
                  rotationYaw += (float)((double)moveForward > 0.0D ? -45 : 45);
               } else if ((double)moveStrafe < 0.0D) {
                  rotationYaw += (float)((double)moveForward > 0.0D ? 45 : -45);
               }

               moveStrafe = 0.0F;
            }

            moveStrafe = moveStrafe == 0.0F ? moveStrafe : ((double)moveStrafe > 0.0D ? 1.0F : -1.0F);
            double cos = Math.cos(Math.toRadians((double)(rotationYaw + 90.0F)));
            double sin = Math.sin(Math.toRadians((double)(rotationYaw + 90.0F)));
            event.setX((double)moveForward * EntityUtil.getMaxSpeed() * cos + (double)moveStrafe * EntityUtil.getMaxSpeed() * sin);
            event.setZ((double)moveForward * EntityUtil.getMaxSpeed() * sin - (double)moveStrafe * EntityUtil.getMaxSpeed() * cos);
         }
      }

   }

   private void speedOff() {
      float yaw = (float)Math.toRadians((double)mc.field_71439_g.field_70177_z);
      EntityPlayerSP var10000;
      if (BlockUtil.isBlockAboveEntitySolid(mc.field_71439_g)) {
         if (mc.field_71474_y.field_74351_w.func_151470_d() && !mc.field_71474_y.field_74311_E.func_151470_d() && mc.field_71439_g.field_70122_E) {
            var10000 = mc.field_71439_g;
            var10000.field_70159_w -= (double)MathUtil.sin(yaw) * 0.15D;
            var10000 = mc.field_71439_g;
            var10000.field_70179_y += (double)MathUtil.cos(yaw) * 0.15D;
         }
      } else if (mc.field_71439_g.field_70123_F) {
         if (mc.field_71474_y.field_74351_w.func_151470_d() && !mc.field_71474_y.field_74311_E.func_151470_d() && mc.field_71439_g.field_70122_E) {
            var10000 = mc.field_71439_g;
            var10000.field_70159_w -= (double)MathUtil.sin(yaw) * 0.03D;
            var10000 = mc.field_71439_g;
            var10000.field_70179_y += (double)MathUtil.cos(yaw) * 0.03D;
         }
      } else if (!BlockUtil.isBlockBelowEntitySolid(mc.field_71439_g)) {
         if (mc.field_71474_y.field_74351_w.func_151470_d() && !mc.field_71474_y.field_74311_E.func_151470_d() && mc.field_71439_g.field_70122_E) {
            var10000 = mc.field_71439_g;
            var10000.field_70159_w -= (double)MathUtil.sin(yaw) * 0.03D;
            var10000 = mc.field_71439_g;
            var10000.field_70179_y += (double)MathUtil.cos(yaw) * 0.03D;
         }
      } else {
         mc.field_71439_g.field_70159_w = 0.0D;
         mc.field_71439_g.field_70179_y = 0.0D;
      }

   }

   public static enum Mode {
      INSTANT,
      ONGROUND,
      ACCEL,
      BOOST,
      VANILLA,
      YPORT;
   }
}
