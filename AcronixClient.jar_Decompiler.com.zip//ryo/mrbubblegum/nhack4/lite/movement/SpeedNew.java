package ryo.mrbubblegum.nhack4.lite.movement;

import java.util.Objects;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.impl.util.MovementUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.MoveEvent;
import ryo.mrbubblegum.nhack4.world.events.UpdateWalkingPlayerEvent;

public class SpeedNew extends Module {
   private static SpeedNew instance;
   private final Setting<SpeedNew.SpeedNewModes> mode;
   private final Setting<Float> yPortAirSpeed;
   private final Setting<Float> yPortGroundSpeed;
   private final Setting<Float> yPortJumpMotionY;
   private final Setting<Float> yPortFallSpeed;
   private final Setting<Boolean> yPortTimerSpeed;
   private final Setting<Float> yPortTimerSpeedVal;
   private final Setting<Boolean> customStrafe;
   private final Setting<Float> airSpeed;
   private final Setting<Float> onGroundSpeed;
   private final Setting<Boolean> autoJump;
   private final Setting<Float> jumpMotionY;
   private final Setting<Boolean> fallModify;
   private final Setting<Float> fallSpeed;
   private final Setting<Boolean> timerSpeed;
   private final Setting<Float> timerSpeedVal;
   private final Setting<Boolean> resetXZ;
   private final Setting<Boolean> resetY;
   int stage;
   private double lastDist;
   private double moveSpeedNew;

   public SpeedNew() {
      super("Speed", "speed module!!", Module.Category.MOVEMENT, false, false, false);
      this.mode = this.register(new Setting("Mode", SpeedNew.SpeedNewModes.Custom));
      this.yPortAirSpeed = this.register(new Setting("AirSpeed", 0.35F, 0.2F, 5.0F, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.YPort);
      }));
      this.yPortGroundSpeed = this.register(new Setting("GroundSpeed", 0.35F, 0.2F, 5.0F, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.YPort);
      }));
      this.yPortJumpMotionY = this.register(new Setting("JumpMotionY", 0.42F, 0.0F, 4.0F, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.YPort);
      }));
      this.yPortFallSpeed = this.register(new Setting("FallSpeed", 1.0F, 0.0F, 4.0F, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.YPort);
      }));
      this.yPortTimerSpeed = this.register(new Setting("Timer", false, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.YPort);
      }));
      this.yPortTimerSpeedVal = this.register(new Setting("TimerSpeed", 1.8F, 1.0F, 5.0F, (t) -> {
         return (Boolean)this.yPortTimerSpeed.getValue() && ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.YPort);
      }));
      this.customStrafe = this.register(new Setting("CustomStrafe", true, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.airSpeed = this.register(new Setting("AirSpeed", 0.35F, 0.2F, 5.0F, (t) -> {
         return (Boolean)this.customStrafe.getValue() && ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.onGroundSpeed = this.register(new Setting("OnGroundSpeed", 0.35F, 0.2F, 5.0F, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.autoJump = this.register(new Setting("AutoJump", true, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.jumpMotionY = this.register(new Setting("JumpMotionY", 0.42F, 0.0F, 4.0F, (t) -> {
         return (Boolean)this.autoJump.getValue() && ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.fallModify = this.register(new Setting("FallModify", false, (t) -> {
         return (Boolean)this.autoJump.getValue() && ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.fallSpeed = this.register(new Setting("FallSpeed", 0.0F, 0.0F, 5.0F, (t) -> {
         return (Boolean)this.fallModify.getValue() && (Boolean)this.autoJump.getValue() && ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.timerSpeed = this.register(new Setting("Timer", false, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.timerSpeedVal = this.register(new Setting("TimerSpeed", 1.8F, 1.0F, 5.0F, (t) -> {
         return (Boolean)this.timerSpeed.getValue() && ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.resetXZ = this.register(new Setting("ResetXZ", false, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      this.resetY = this.register(new Setting("ResetY", false, (t) -> {
         return ((SpeedNew.SpeedNewModes)this.mode.getValue()).equals(SpeedNew.SpeedNewModes.Custom);
      }));
      instance = this;
   }

   public static SpeedNew getInstance() {
      if (instance == null) {
         instance = new SpeedNew();
      }

      return instance;
   }

   @SubscribeEvent
   public void onStrafe(MoveEvent event) {
      if (!Strafe.fullNullCheck()) {
         if (!Strafe.mc.field_71439_g.func_70090_H() && !Strafe.mc.field_71439_g.func_180799_ab()) {
            if (Strafe.mc.field_71439_g.field_70122_E) {
               this.stage = 2;
            }

            double n;
            switch(this.stage) {
            case 0:
               ++this.stage;
               this.lastDist = 0.0D;
               break;
            case 1:
            default:
               if ((Strafe.mc.field_71441_e.func_184144_a(Strafe.mc.field_71439_g, Strafe.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0D, Strafe.mc.field_71439_g.field_70181_x, 0.0D)).size() > 0 || Strafe.mc.field_71439_g.field_70124_G) && this.stage > 0) {
                  this.stage = Strafe.mc.field_71439_g.field_191988_bg == 0.0F && Strafe.mc.field_71439_g.field_70702_br == 0.0F ? 0 : 1;
               }

               this.moveSpeedNew = this.lastDist - this.lastDist / 159.0D;
               break;
            case 2:
               n = 0.40123128D;
               if (Strafe.mc.field_71439_g.field_70122_E && Strafe.mc.field_71474_y.field_74314_A.func_151470_d()) {
                  if (Strafe.mc.field_71439_g.func_70644_a(MobEffects.field_76430_j)) {
                     n += (double)((float)(Strafe.mc.field_71439_g.func_70660_b(MobEffects.field_76430_j).func_76458_c() + 1) * 0.1F);
                  }

                  Strafe.mc.field_71439_g.field_70181_x = n;
                  event.setY(Strafe.mc.field_71439_g.field_70181_x);
                  this.moveSpeedNew *= 2.149D;
               }
               break;
            case 3:
               this.moveSpeedNew = this.lastDist - 0.795D * (this.lastDist - this.getBaseMoveSpeedNew());
            }

            this.moveSpeedNew = !Strafe.mc.field_71474_y.field_74314_A.func_151470_d() && Strafe.mc.field_71439_g.field_70122_E ? this.getBaseMoveSpeedNew() : Math.max(this.moveSpeedNew, this.getBaseMoveSpeedNew());
            n = (double)Strafe.mc.field_71439_g.field_71158_b.field_192832_b;
            double n2 = (double)Strafe.mc.field_71439_g.field_71158_b.field_78902_a;
            double n3 = (double)Strafe.mc.field_71439_g.field_70177_z;
            if (n == 0.0D && n2 == 0.0D) {
               event.setX(0.0D);
               event.setZ(0.0D);
            } else if (n != 0.0D && n2 != 0.0D) {
               n *= Math.sin(0.7853981633974483D);
               n2 *= Math.cos(0.7853981633974483D);
            }

            double n4 = 0.99D;
            event.setX((n * this.moveSpeedNew * -Math.sin(Math.toRadians(n3)) + n2 * this.moveSpeedNew * Math.cos(Math.toRadians(n3))) * n4);
            event.setZ((n * this.moveSpeedNew * Math.cos(Math.toRadians(n3)) - n2 * this.moveSpeedNew * -Math.sin(Math.toRadians(n3))) * n4);
            ++this.stage;
            event.setCanceled(true);
         }
      }
   }

   public double getBaseMoveSpeedNew() {
      double n = 0.2873D;
      return !Strafe.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c) ? n : n * (1.0D + 0.2D * (double)(((PotionEffect)Objects.requireNonNull(Strafe.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c))).func_76458_c() + 1));
   }

   @SubscribeEvent
   public void onMotion(UpdateWalkingPlayerEvent event) {
      if (event.getStage() != 1 && !Strafe.fullNullCheck()) {
         switch((SpeedNew.SpeedNewModes)this.mode.getValue()) {
         case Custom:
            if (MovementUtil.isMoving(mc.field_71439_g)) {
               if (mc.field_71439_g.field_70122_E) {
                  EntityUtil.moveEntityStrafe((double)(Float)this.onGroundSpeed.getValue(), mc.field_71439_g);
                  if ((Boolean)this.autoJump.getValue()) {
                     mc.field_71439_g.field_70181_x = (double)(Float)this.jumpMotionY.getValue();
                     break;
                  }
               } else if ((Boolean)this.fallModify.getValue()) {
                  mc.field_71439_g.field_70181_x = (double)(-(Float)this.fallSpeed.getValue());
               }

               if ((Boolean)this.customStrafe.getValue()) {
                  EntityUtil.moveEntityStrafe((double)(Float)this.airSpeed.getValue(), mc.field_71439_g);
               } else {
                  EntityUtil.moveEntityStrafe(Math.sqrt(mc.field_71439_g.field_70159_w * mc.field_71439_g.field_70159_w + mc.field_71439_g.field_70181_x * mc.field_71439_g.field_70181_x + mc.field_71439_g.field_70179_y * mc.field_71439_g.field_70179_y), mc.field_71439_g);
               }
            } else {
               if ((Boolean)this.timerSpeed.getValue() == Boolean.TRUE) {
                  Loader.timerManager.setTimer((Float)this.timerSpeedVal.getValue());
               } else {
                  Loader.timerManager.reset();
               }

               mc.field_71439_g.field_70159_w = mc.field_71439_g.field_70179_y = 0.0D;
            }
            break;
         case YPort:
            if (!MovementUtil.isMoving(Speed.mc.field_71439_g) || Speed.mc.field_71439_g.field_70123_F) {
               return;
            }

            if ((Boolean)this.yPortTimerSpeed.getValue()) {
               Loader.timerManager.setTimer((Float)this.yPortTimerSpeedVal.getValue());
            } else {
               Loader.timerManager.reset();
            }

            if (Speed.mc.field_71439_g.field_70122_E) {
               mc.field_71439_g.field_70181_x = (double)(Float)this.yPortJumpMotionY.getValue();
               EntityUtil.moveEntityStrafe((double)(Float)this.yPortGroundSpeed.getValue(), mc.field_71439_g);
            } else {
               Speed.mc.field_71439_g.field_70181_x = (double)(-(Float)this.yPortFallSpeed.getValue());
            }

            if (!Speed.mc.field_71439_g.field_70122_E) {
               mc.field_71439_g.field_70181_x = (double)(Float)this.yPortJumpMotionY.getValue();
               EntityUtil.moveEntityStrafe((double)(Float)this.yPortAirSpeed.getValue(), mc.field_71439_g);
            }
         }

      }
   }

   public void onTick() {
      switch((SpeedNew.SpeedNewModes)this.mode.getValue()) {
      case Custom:
         if (MovementUtil.isMoving(mc.field_71439_g)) {
            if (mc.field_71439_g.field_70122_E) {
               EntityUtil.moveEntityStrafe((double)(Float)this.onGroundSpeed.getValue(), mc.field_71439_g);
               if ((Boolean)this.autoJump.getValue()) {
                  mc.field_71439_g.field_70181_x = (double)(Float)this.jumpMotionY.getValue();
                  break;
               }
            } else if ((Boolean)this.fallModify.getValue()) {
               mc.field_71439_g.field_70181_x = (double)(-(Float)this.fallSpeed.getValue());
            }

            if ((Boolean)this.customStrafe.getValue()) {
               EntityUtil.moveEntityStrafe((double)(Float)this.airSpeed.getValue(), mc.field_71439_g);
            } else {
               EntityUtil.moveEntityStrafe(Math.sqrt(mc.field_71439_g.field_70159_w * mc.field_71439_g.field_70159_w + mc.field_71439_g.field_70181_x * mc.field_71439_g.field_70181_x + mc.field_71439_g.field_70179_y * mc.field_71439_g.field_70179_y), mc.field_71439_g);
            }
         } else {
            if ((Boolean)this.timerSpeed.getValue() == Boolean.TRUE) {
               Loader.timerManager.setTimer((Float)this.timerSpeedVal.getValue());
            } else {
               Loader.timerManager.reset();
            }

            mc.field_71439_g.field_70159_w = mc.field_71439_g.field_70179_y = 0.0D;
         }
         break;
      case YPort:
         if (!MovementUtil.isMoving(Speed.mc.field_71439_g) || Speed.mc.field_71439_g.field_70123_F) {
            return;
         }

         if ((Boolean)this.yPortTimerSpeed.getValue()) {
            Loader.timerManager.setTimer((Float)this.yPortTimerSpeedVal.getValue());
         } else {
            Loader.timerManager.reset();
         }

         if (Speed.mc.field_71439_g.field_70122_E) {
            mc.field_71439_g.field_70181_x = (double)(Float)this.yPortJumpMotionY.getValue();
            EntityUtil.moveEntityStrafe((double)(Float)this.yPortGroundSpeed.getValue(), mc.field_71439_g);
         } else {
            Speed.mc.field_71439_g.field_70181_x = (double)(-(Float)this.yPortFallSpeed.getValue());
         }

         if (!Speed.mc.field_71439_g.field_70122_E) {
            EntityUtil.moveEntityStrafe((double)(Float)this.yPortAirSpeed.getValue(), mc.field_71439_g);
         }
      }

   }

   public void onEnable() {
      if ((Boolean)this.timerSpeed.getValue()) {
         Loader.timerManager.setTimer((Float)this.timerSpeedVal.getValue());
      }

      if ((Boolean)this.resetXZ.getValue()) {
         mc.field_71439_g.field_70159_w = mc.field_71439_g.field_70179_y = 0.0D;
      }

      if ((Boolean)this.resetY.getValue()) {
         mc.field_71439_g.field_70159_w = 0.0D;
      }

      super.onEnable();
   }

   public void onDisable() {
      Loader.timerManager.reset();
      super.onDisable();
   }

   public static enum SpeedNewModes {
      Custom,
      YPort;
   }
}
