package ryo.mrbubblegum.nhack4.lite.movement;

import net.minecraft.block.material.Material;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.EntityUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.StepEvent;

public class Step extends Module {
   private static Step instance;
   public Setting<Boolean> vanilla = this.register(new Setting("Vanilla", true));
   public Setting<Integer> stepHeight = this.register(new Setting("Height", 2, 1, 10));
   public Setting<Boolean> noLiquid = this.register(new Setting("NoLiquid", true));
   public Setting<Boolean> turnOff = this.register(new Setting("Disable", false));

   public Step() {
      super("Step", "upwards", Module.Category.MOVEMENT, true, false, false);
      instance = this;
   }

   public static Step getInstance() {
      if (instance == null) {
         instance = new Step();
      }

      return instance;
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         if ((Boolean)this.noLiquid.getValue() && EntityUtil.isInLiquid()) {
         }

      }
   }

   @SubscribeEvent
   public void onStep(StepEvent event) {
      if (mc.field_71439_g.field_70122_E && !mc.field_71439_g.func_70055_a(Material.field_151586_h) && !mc.field_71439_g.func_70055_a(Material.field_151587_i) && mc.field_71439_g.field_70124_G && mc.field_71439_g.field_70143_R == 0.0F && !mc.field_71474_y.field_74314_A.field_74513_e && !mc.field_71439_g.func_70617_f_()) {
         event.setHeight((float)(Integer)this.stepHeight.getValue());
         double rheight = mc.field_71439_g.func_174813_aQ().field_72338_b - mc.field_71439_g.field_70163_u;
         if (rheight >= 0.625D) {
            if (!(Boolean)this.vanilla.getValue()) {
               this.ncpStep(rheight);
            }

            if ((Boolean)this.turnOff.getValue()) {
               this.disable();
            }
         }
      } else {
         event.setHeight(0.6F);
      }

   }

   private void ncpStep(double height) {
      double posX = mc.field_71439_g.field_70165_t;
      double posZ = mc.field_71439_g.field_70161_v;
      double y = mc.field_71439_g.field_70163_u;
      if (!(height < 1.1D)) {
         double[] var10;
         int var11;
         int var12;
         double off;
         if (height < 1.6D) {
            var10 = new double[]{0.42D, 0.33D, 0.24D, 0.083D, -0.078D};
            var11 = var10.length;

            for(var12 = 0; var12 < var11; ++var12) {
               off = var10[var12];
               mc.field_71439_g.field_71174_a.func_147297_a(new Position(posX, y += off, posZ, false));
            }
         } else if (height < 2.1D) {
            var10 = new double[]{0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D};
            var11 = var10.length;

            for(var12 = 0; var12 < var11; ++var12) {
               off = var10[var12];
               mc.field_71439_g.field_71174_a.func_147297_a(new Position(posX, y + off, posZ, false));
            }
         } else {
            var10 = new double[]{0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D, 2.019D, 1.907D};
            var11 = var10.length;

            for(var12 = 0; var12 < var11; ++var12) {
               off = var10[var12];
               mc.field_71439_g.field_71174_a.func_147297_a(new Position(posX, y + off, posZ, false));
            }
         }
      } else {
         double first = 0.42D;
         double second = 0.75D;
         if (height != 1.0D) {
            first *= height;
            second *= height;
            if (first > 0.425D) {
               first = 0.425D;
            }

            if (second > 0.78D) {
               second = 0.78D;
            }

            if (second < 0.49D) {
               second = 0.49D;
            }
         }

         mc.field_71439_g.field_71174_a.func_147297_a(new Position(posX, y + first, posZ, false));
         if (y + second < y + height) {
            mc.field_71439_g.field_71174_a.func_147297_a(new Position(posX, y + second, posZ, false));
         }
      }

   }
}
