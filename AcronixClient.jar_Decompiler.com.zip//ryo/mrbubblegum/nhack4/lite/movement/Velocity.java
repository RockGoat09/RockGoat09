package ryo.mrbubblegum.nhack4.lite.movement;

import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.EntityCollisionEvent;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;
import ryo.mrbubblegum.nhack4.world.events.PushEvent;

public class Velocity extends Module {
   private static Velocity INSTANCE = new Velocity();
   public Setting<Boolean> knockBack = this.register(new Setting("KnockBack", true));
   public Setting<Boolean> noPush = this.register(new Setting("NoPush", true));
   public Setting<Float> horizontal = this.register(new Setting("Horizontal", 0.0F, 0.0F, 100.0F));
   public Setting<Float> vertical = this.register(new Setting("Vertical", 0.0F, 0.0F, 100.0F));
   public Setting<Boolean> explosions = this.register(new Setting("Explosions", true));
   public Setting<Boolean> entities = this.register(new Setting("Entities", true));
   public Setting<Boolean> bobbers = this.register(new Setting("Bobbers", true));
   public Setting<Boolean> water = this.register(new Setting("Water", false));
   public Setting<Boolean> blocks = this.register(new Setting("Blocks", false));
   public Setting<Boolean> ice = this.register(new Setting("Ice", false));
   private float collisionReduction;

   public Velocity() {
      super("Velocity", "no push", Module.Category.MOVEMENT, true, false, false);
      this.setInstance();
   }

   public static Velocity getINSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new Velocity();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onUpdate() {
      if ((Boolean)this.ice.getValue()) {
         Blocks.field_150432_aD.field_149765_K = 0.6F;
         Blocks.field_150403_cj.field_149765_K = 0.6F;
         Blocks.field_185778_de.field_149765_K = 0.6F;
      }

      if ((Boolean)this.entities.getValue()) {
         Util.mc.field_71439_g.field_70144_Y = 1.0F;
      }

   }

   public void onEnable() {
      this.collisionReduction = Util.mc.field_71439_g.field_70144_Y;
   }

   public void onDisable() {
      Blocks.field_150432_aD.field_149765_K = 0.98F;
      Blocks.field_150403_cj.field_149765_K = 0.98F;
      Blocks.field_185778_de.field_149765_K = 0.98F;
      Util.mc.field_71439_g.field_70144_Y = this.collisionReduction;
   }

   @SubscribeEvent
   public void onPacketReceived(PacketEvent.Receive event) {
      if (event.getStage() == 0 && mc.field_71439_g != null) {
         SPacketEntityVelocity velocity;
         if ((Boolean)this.knockBack.getValue() && event.getPacket() instanceof SPacketEntityVelocity && (velocity = (SPacketEntityVelocity)event.getPacket()).func_149412_c() == mc.field_71439_g.field_145783_c) {
            if ((Float)this.horizontal.getValue() == 0.0F && (Float)this.vertical.getValue() == 0.0F) {
               event.setCanceled(true);
               return;
            }

            velocity.field_149415_b = (int)((float)velocity.field_149415_b * (Float)this.horizontal.getValue());
            velocity.field_149416_c = (int)((float)velocity.field_149416_c * (Float)this.vertical.getValue());
            velocity.field_149414_d = (int)((float)velocity.field_149414_d * (Float)this.horizontal.getValue());
         }

         Entity entity;
         SPacketEntityStatus packet;
         if (event.getPacket() instanceof SPacketEntityStatus && (Boolean)this.bobbers.getValue() && (packet = (SPacketEntityStatus)event.getPacket()).func_149160_c() == 31 && (entity = packet.func_149161_a(mc.field_71441_e)) instanceof EntityFishHook) {
            EntityFishHook fishHook = (EntityFishHook)entity;
            if (fishHook.field_146043_c == mc.field_71439_g) {
               event.setCanceled(true);
            }
         }

         if ((Boolean)this.explosions.getValue() && event.getPacket() instanceof SPacketExplosion) {
            SPacketExplosion velocity_ = (SPacketExplosion)event.getPacket();
            velocity_.field_149152_f *= (Float)this.horizontal.getValue();
            velocity_.field_149153_g *= (Float)this.vertical.getValue();
            velocity_.field_149159_h *= (Float)this.horizontal.getValue();
         }
      }

   }

   @SubscribeEvent
   public void onEntityCollision(EntityCollisionEvent event) {
      if ((Boolean)this.entities.getValue()) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onPush(PushEvent event) {
      if (event.getStage() == 0 && (Boolean)this.noPush.getValue() && event.entity.equals(mc.field_71439_g)) {
         if ((Float)this.horizontal.getValue() == 0.0F && (Float)this.vertical.getValue() == 0.0F) {
            event.setCanceled(true);
            return;
         }

         event.x = -event.x * (double)(Float)this.horizontal.getValue();
         event.y = -event.y * (double)(Float)this.vertical.getValue();
         event.z = -event.z * (double)(Float)this.horizontal.getValue();
      } else if (event.getStage() == 1 && (Boolean)this.blocks.getValue()) {
         event.setCanceled(true);
      } else if (event.getStage() == 2 && (Boolean)this.water.getValue() && mc.field_71439_g != null && mc.field_71439_g.equals(event.entity)) {
         event.setCanceled(true);
      }

   }
}
