package ryo.mrbubblegum.nhack4.lite.player;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.MoverType;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class FakePlayer extends Module {
   private static FakePlayer INSTANCE = new FakePlayer();
   public List<Integer> fakePlayerIdList = new ArrayList();
   public Setting<Boolean> moving = this.register(new Setting("Moving", false));
   private EntityOtherPlayerMP otherPlayer;

   public FakePlayer() {
      super("FakePlayer", "average weakness player", Module.Category.PLAYER, false, false, false);
      this.setInstance();
   }

   public static FakePlayer getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new FakePlayer();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onTick() {
      if (this.otherPlayer != null) {
         Random random = new Random();
         this.otherPlayer.field_191988_bg = Util.mc.field_71439_g.field_191988_bg + (float)random.nextInt(5) / 10.0F;
         this.otherPlayer.field_70702_br = Util.mc.field_71439_g.field_70702_br + (float)random.nextInt(5) / 10.0F;
         if ((Boolean)this.moving.getValue()) {
            this.travel(this.otherPlayer.field_70702_br, this.otherPlayer.field_70701_bs, this.otherPlayer.field_191988_bg);
         }
      }

   }

   public void travel(float strafe, float vertical, float forward) {
      double d0 = this.otherPlayer.field_70163_u;
      float f1 = 0.8F;
      float f2 = 0.02F;
      float f3 = (float)EnchantmentHelper.func_185294_d(this.otherPlayer);
      if (f3 > 3.0F) {
         f3 = 3.0F;
      }

      if (!this.otherPlayer.field_70122_E) {
         f3 *= 0.5F;
      }

      if (f3 > 0.0F) {
         f1 += (0.54600006F - f1) * f3 / 3.0F;
         f2 += (this.otherPlayer.func_70689_ay() - f2) * f3 / 4.0F;
      }

      this.otherPlayer.func_191958_b(strafe, vertical, forward, f2);
      this.otherPlayer.func_70091_d(MoverType.SELF, this.otherPlayer.field_70159_w, this.otherPlayer.field_70181_x, this.otherPlayer.field_70179_y);
      EntityOtherPlayerMP var10000 = this.otherPlayer;
      var10000.field_70159_w *= (double)f1;
      var10000 = this.otherPlayer;
      var10000.field_70181_x *= 0.800000011920929D;
      var10000 = this.otherPlayer;
      var10000.field_70179_y *= (double)f1;
      if (!this.otherPlayer.func_189652_ae()) {
         var10000 = this.otherPlayer;
         var10000.field_70181_x -= 0.02D;
      }

      if (this.otherPlayer.field_70123_F && this.otherPlayer.func_70038_c(this.otherPlayer.field_70159_w, this.otherPlayer.field_70181_x + 0.6000000238418579D - this.otherPlayer.field_70163_u + d0, this.otherPlayer.field_70179_y)) {
         this.otherPlayer.field_70181_x = 0.30000001192092896D;
      }

   }

   public void onEnable() {
      if (Util.mc.field_71441_e != null && Util.mc.field_71439_g != null) {
         this.fakePlayerIdList = new ArrayList();
         this.addFakePlayer(-100);
      } else {
         this.toggle();
      }
   }

   public void addFakePlayer(int entityId) {
      if (this.otherPlayer == null) {
         this.otherPlayer = new EntityOtherPlayerMP(Util.mc.field_71441_e, new GameProfile(UUID.randomUUID(), "ryooooo"));
         this.otherPlayer.func_82149_j(Util.mc.field_71439_g);
         this.otherPlayer.field_71071_by.func_70455_b(Util.mc.field_71439_g.field_71071_by);
      }

      Util.mc.field_71441_e.func_73027_a(entityId, this.otherPlayer);
      this.fakePlayerIdList.add(entityId);
   }

   public void onDisable() {
      Iterator var1 = this.fakePlayerIdList.iterator();

      while(var1.hasNext()) {
         int id = (Integer)var1.next();
         mc.field_71441_e.func_73028_b(id);
      }

      if (this.otherPlayer != null) {
         Util.mc.field_71441_e.func_72900_e(this.otherPlayer);
         this.otherPlayer = null;
      }

   }
}
