package ryo.mrbubblegum.nhack4.lite.player;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import ryo.mrbubblegum.nhack4.impl.gui.LiteGui;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.lite.client.ClickGui;
import ryo.mrbubblegum.nhack4.lite.client.PingBypass;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Bind;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class MCF extends Module {
   private final Setting<Boolean> middleClick = this.register(new Setting("MiddleClick", true));
   private final Setting<Boolean> keyboard = this.register(new Setting("Keyboard", false));
   private final Setting<Boolean> server = this.register(new Setting("Server", true));
   private final Setting<Bind> key = this.register(new Setting("KeyBind", new Bind(-1), (v) -> {
      return (Boolean)this.keyboard.getValue();
   }));
   private boolean clicked = false;

   public MCF() {
      super("MiddleClickFriend", "allows u to friend ppl", Module.Category.PLAYER, true, false, false);
   }

   public void onUpdate() {
      if (Mouse.isButtonDown(2)) {
         if (!this.clicked && (Boolean)this.middleClick.getValue() && mc.field_71462_r == null) {
            this.onClick();
         }

         this.clicked = true;
      } else {
         this.clicked = false;
      }

   }

   @SubscribeEvent(
      priority = EventPriority.NORMAL,
      receiveCanceled = true
   )
   public void onKeyInput(KeyInputEvent event) {
      if ((Boolean)this.keyboard.getValue() && Keyboard.getEventKeyState() && !(mc.field_71462_r instanceof LiteGui) && ((Bind)this.key.getValue()).getKey() == Keyboard.getEventKey()) {
         this.onClick();
      }

   }

   private void onClick() {
      RayTraceResult result = mc.field_71476_x;
      Entity entity;
      if (result != null && result.field_72313_a == Type.ENTITY && (entity = result.field_72308_g) instanceof EntityPlayer) {
         if (Loader.friendManager.isFriend(entity.func_70005_c_())) {
            Loader.friendManager.removeFriend(entity.func_70005_c_());
            Command.sendMessage("§c" + entity.func_70005_c_() + "§r unfriended.");
            if ((Boolean)this.server.getValue() && PingBypass.getInstance().isConnected()) {
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("@Serverprefix" + (String)ClickGui.getInstance().prefix.getValue()));
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("@Server" + (String)ClickGui.getInstance().prefix.getValue() + "friend del " + entity.func_70005_c_()));
            }
         } else {
            Loader.friendManager.addFriend(entity.func_70005_c_());
            Command.sendMessage("§b" + entity.func_70005_c_() + "§r friended.");
            if ((Boolean)this.server.getValue() && PingBypass.getInstance().isConnected()) {
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("@Serverprefix" + (String)ClickGui.getInstance().prefix.getValue()));
               mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("@Server" + (String)ClickGui.getInstance().prefix.getValue() + "friend add " + entity.func_70005_c_()));
            }
         }
      }

      this.clicked = true;
   }
}
