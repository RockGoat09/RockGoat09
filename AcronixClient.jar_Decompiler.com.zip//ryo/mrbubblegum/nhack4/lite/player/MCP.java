package ryo.mrbubblegum.nhack4.lite.player;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.input.Mouse;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class MCP extends Module {
   private final Setting<MCP.Mode> mode;
   private final Setting<Boolean> stopRotation;
   private final Setting<Boolean> antiFriend;
   private final Setting<Integer> rotation;
   private boolean clicked;

   public MCP() {
      super("MiddleClickPearl", "silent pearl", Module.Category.PLAYER, false, false, false);
      this.mode = this.register(new Setting("Mode", MCP.Mode.MIDDLECLICK));
      this.stopRotation = this.register(new Setting("Rotation", true));
      this.antiFriend = this.register(new Setting("AntiFriend", true));
      this.rotation = this.register(new Setting("Delay", 10, 0, 100, (v) -> {
         return (Boolean)this.stopRotation.getValue();
      }));
      this.clicked = false;
   }

   public void onEnable() {
      if (!fullNullCheck() && this.mode.getValue() == MCP.Mode.TOGGLE) {
         this.throwPearl();
         this.disable();
      }

   }

   public void onTick() {
      if (this.mode.getValue() == MCP.Mode.MIDDLECLICK) {
         if (Mouse.isButtonDown(2)) {
            if (!this.clicked) {
               this.throwPearl();
            }

            this.clicked = true;
         } else {
            this.clicked = false;
         }
      }

   }

   private void throwPearl() {
      RayTraceResult result;
      if (!(Boolean)this.antiFriend.getValue() || (result = mc.field_71476_x) == null || result.field_72313_a != Type.ENTITY || !(result.field_72308_g instanceof EntityPlayer)) {
         int pearlSlot = InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
         boolean offhand = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151079_bi;
         if (pearlSlot != -1 || offhand) {
            int oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
            if (!offhand) {
               InventoryUtil.switchToHotbarSlot(pearlSlot, false);
            }

            mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            if (!offhand) {
               InventoryUtil.switchToHotbarSlot(oldslot, false);
            }
         }

      }
   }

   public static enum Mode {
      TOGGLE,
      MIDDLECLICK;
   }
}
