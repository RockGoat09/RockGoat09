package ryo.mrbubblegum.nhack4.lite.player;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Feature;
import ryo.mrbubblegum.nhack4.lite.Module;

public class NoEntityTrace extends Module {
   private boolean focus = false;

   public NoEntityTrace() {
      super("NoEntityTrace", "mines trought entities", Module.Category.PLAYER, false, false, false);
   }

   public void onUpdate() {
      if (!Feature.nullCheck()) {
         Util.mc.field_71441_e.field_72996_f.stream().filter((entity) -> {
            return entity instanceof EntityLivingBase;
         }).filter((entity) -> {
            return Util.mc.field_71439_g == entity;
         }).map((entity) -> {
            return (EntityLivingBase)entity;
         }).filter((entity) -> {
            return !entity.field_70128_L;
         }).forEach(this::process);
         RayTraceResult normalResult = Util.mc.field_71476_x;
         if (normalResult != null) {
            this.focus = normalResult.field_72313_a == Type.ENTITY;
         }

      }
   }

   private void process(EntityLivingBase event) {
      RayTraceResult bypassEntityResult = event.func_174822_a(6.0D, Util.mc.func_184121_ak());
      if (bypassEntityResult != null && this.focus && bypassEntityResult.field_72313_a == Type.BLOCK) {
         BlockPos pos = bypassEntityResult.func_178782_a();
         if (Util.mc.field_71474_y.field_74312_F.func_151470_d()) {
            Util.mc.field_71442_b.func_180512_c(pos, EnumFacing.UP);
         }
      }

   }
}
