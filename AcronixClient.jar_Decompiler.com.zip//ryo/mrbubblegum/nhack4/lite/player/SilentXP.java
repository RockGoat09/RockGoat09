package ryo.mrbubblegum.nhack4.lite.player;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import ryo.mrbubblegum.nhack4.impl.util.InventoryUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Bind;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class SilentXP extends Module {
   public Setting<SilentXP.Mode> mode;
   public Setting<Boolean> antiFriend;
   public Setting<Bind> key;
   public Setting<Boolean> groundOnly;
   private boolean last;
   private boolean on;

   public SilentXP() {
      super("AutoMend", "silent exp", Module.Category.PLAYER, false, false, false);
      this.mode = this.register(new Setting("Mode", SilentXP.Mode.MIDDLECLICK));
      this.antiFriend = this.register(new Setting("AntiFriend", true));
      this.key = this.register(new Setting("Key", new Bind(-1), (v) -> {
         return this.mode.getValue() != SilentXP.Mode.MIDDLECLICK;
      }));
      this.groundOnly = this.register(new Setting("BelowHorizon", false));
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         switch((SilentXP.Mode)this.mode.getValue()) {
         case PRESS:
            if (((Bind)this.key.getValue()).isDown()) {
               this.throwXP(false);
            }
            break;
         case TOGGLE:
            if (this.toggled()) {
               this.throwXP(false);
            }
            break;
         default:
            if ((Boolean)this.groundOnly.getValue() && mc.field_71439_g.field_70125_A < 0.0F) {
               return;
            }

            if (Mouse.isButtonDown(2)) {
               this.throwXP(true);
            }
         }

      }
   }

   private boolean toggled() {
      if (((Bind)this.key.getValue()).getKey() == -1) {
         return false;
      } else {
         if (!Keyboard.isKeyDown(((Bind)this.key.getValue()).getKey())) {
            this.last = true;
         } else {
            if (Keyboard.isKeyDown(((Bind)this.key.getValue()).getKey()) && this.last && !this.on) {
               this.last = false;
               this.on = true;
               return this.on;
            }

            if (Keyboard.isKeyDown(((Bind)this.key.getValue()).getKey()) && this.last && this.on) {
               this.last = false;
               this.on = false;
               return this.on;
            }
         }

         return this.on;
      }
   }

   private void throwXP(boolean mcf) {
      RayTraceResult result;
      if (!mcf || !(Boolean)this.antiFriend.getValue() || (result = mc.field_71476_x) == null || result.field_72313_a != Type.ENTITY || !(result.field_72308_g instanceof EntityPlayer)) {
         int xpSlot = InventoryUtil.findHotbarBlock(ItemExpBottle.class);
         boolean offhand = mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151062_by;
         if (xpSlot != -1 || offhand) {
            int oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
            if (!offhand) {
               InventoryUtil.switchToHotbarSlot(xpSlot, false);
            }

            mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            if (!offhand) {
               InventoryUtil.switchToHotbarSlot(oldslot, false);
            }
         }

      }
   }

   public static enum Mode {
      MIDDLECLICK,
      TOGGLE,
      PRESS;
   }
}
