package ryo.mrbubblegum.nhack4.lite.render;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.PerspectiveEvent;

public class Aspect extends Module {
   public Setting<Float> aspect = this.register(new Setting("Alpha", 1.0F, 0.1F, 5.0F));

   public Aspect() {
      super("Aspect", "best for media", Module.Category.RENDER, true, false, false);
   }

   @SubscribeEvent
   public void onPerspectiveEvent(PerspectiveEvent perspectiveEvent) {
      perspectiveEvent.setAspect((Float)this.aspect.getValue());
   }
}
