package ryo.mrbubblegum.nhack4.lite.render;

import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class CameraClip extends Module {
   private static CameraClip INSTANCE = new CameraClip();
   public Setting<Boolean> extend = this.register(new Setting("Extend", false));
   public Setting<Double> distance = this.register(new Setting("Distance", 10.0D, 0.0D, 50.0D, (v) -> {
      return (Boolean)this.extend.getValue();
   }, "By how much you want to extend the distance."));

   public CameraClip() {
      super("CameraClip", "Makes your Camera clip.", Module.Category.RENDER, false, false, false);
      this.setInstance();
   }

   public static CameraClip getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new CameraClip();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }
}
