package ryo.mrbubblegum.nhack4.lite.render;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.Render3DEvent;

public class ChinaHat extends Module {
   public Setting<Float> height = this.register(new Setting("Height", 0.3F, 0.1F, 1.0F));
   public Setting<Float> radius = this.register(new Setting("Radius", 0.7F, 0.3F, 1.5F));
   public Setting<Float> yPos = this.register(new Setting("YPos", 0.0F, -1.0F, 1.0F));
   public Setting<Boolean> drawThePlayer = this.register(new Setting("DrawThePlayer", true));
   public Setting<Boolean> onlyThirdPerson = this.register(new Setting("OnlyThirdPerson", true, (v) -> {
      return (Boolean)this.drawThePlayer.getValue();
   }));
   public Setting<Integer> red = this.register(new Setting("Red", 255, 0, 255));
   public Setting<Integer> green = this.register(new Setting("Green", 255, 0, 255));
   public Setting<Integer> blue = this.register(new Setting("Blue", 255, 0, 255));
   public Setting<Integer> alpha = this.register(new Setting("Alpha", 200, 0, 255));

   public ChinaHat() {
      super("ChinaHat", "lmaoo", Module.Category.RENDER, true, false, false);
   }

   public void onRender3D(Render3DEvent event) {
      if ((Boolean)this.drawThePlayer.getValue() && (!(Boolean)this.onlyThirdPerson.getValue() || Util.mc.field_71474_y.field_74320_O != 0)) {
         this.drawChinaHatFor(Util.mc.field_71439_g);
      }

   }

   public void drawChinaHatFor(EntityLivingBase entity) {
      GL11.glPushMatrix();
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glDisable(2884);
      GL11.glColor4f((float)(Integer)this.red.getValue() / 255.0F, (float)(Integer)this.green.getValue() / 255.0F, (float)(Integer)this.blue.getValue() / 255.0F, (float)(Integer)this.alpha.getValue() / 255.0F);
      GL11.glTranslated(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)Util.mc.field_71428_T.field_194147_b - Util.mc.field_175616_W.field_78725_b, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)Util.mc.field_71428_T.field_194147_b - Util.mc.field_175616_W.field_78726_c + (double)entity.field_70131_O + (double)(Float)this.yPos.getValue(), entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)Util.mc.field_71428_T.field_194147_b - Util.mc.field_175616_W.field_78723_d);
      GL11.glBegin(6);
      GL11.glVertex3d(0.0D, (double)(Float)this.height.getValue(), 0.0D);
      float radius = (Float)this.radius.getValue();

      for(int i = 0; i <= 360; ++i) {
         GL11.glVertex3d(Math.cos((double)i * 3.141592653589793D / 180.0D) * (double)radius, 0.0D, Math.sin((double)i * 3.141592653589793D / 180.0D) * (double)radius);
      }

      GL11.glVertex3d(0.0D, (double)(Float)this.height.getValue(), 0.0D);
      GL11.glEnd();
      GL11.glEnable(2884);
      GlStateManager.func_179117_G();
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
   }
}
