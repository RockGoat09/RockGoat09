package ryo.mrbubblegum.nhack4.lite.render;

import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class CrystalModify extends Module {
   public static CrystalModify INSTANCE;
   public Setting<CrystalModify.modes> mode;
   public Setting<CrystalModify.outlineModes> outlineMode;
   public Setting<Float> size;
   public Setting<Float> crystalSpeed;
   public Setting<Float> crystalBounce;
   public Setting<CrystalModify.BlendModes> blendModes;
   public Setting<Boolean> enchanted;
   public Setting<Integer> enchantRed;
   public Setting<Integer> enchantGreen;
   public Setting<Integer> enchantBlue;
   public Setting<Integer> enchantAlpha;
   public Setting<Boolean> texture;
   public Setting<Boolean> colorSync;
   public Setting<Integer> red;
   public Setting<Integer> green;
   public Setting<Integer> blue;
   public Setting<Integer> alpha;
   public Setting<Boolean> outline;
   public Setting<Float> lineWidth;
   public Setting<Integer> outlineRed;
   public Setting<Integer> outlineGreen;
   public Setting<Integer> outlineBlue;
   public Setting<Integer> outlineAlpha;
   public Setting<Boolean> hiddenSync;
   public Setting<Integer> hiddenRed;
   public Setting<Integer> hiddenGreen;
   public Setting<Integer> hiddenBlue;
   public Setting<Integer> hiddenAlpha;

   public CrystalModify() {
      super("CrystalChams", "crystal modifier", Module.Category.RENDER, true, false, false);
      this.mode = this.register(new Setting("Mode", CrystalModify.modes.FILL));
      this.outlineMode = this.register(new Setting("Outline Mode", CrystalModify.outlineModes.WIRE));
      this.size = this.register(new Setting("Size", 1.0F, 0.1F, 2.0F));
      this.crystalSpeed = this.register(new Setting("Speed", 1.0F, 0.1F, 20.0F));
      this.crystalBounce = this.register(new Setting("Bounce", 0.2F, 0.1F, 1.0F));
      this.blendModes = this.register(new Setting("Blend", CrystalModify.BlendModes.Default));
      this.enchanted = this.register(new Setting("Glint", false));
      this.enchantRed = this.register(new Setting("Glint Red", 135, 0, 255, (v) -> {
         return (Boolean)this.enchanted.getValue();
      }));
      this.enchantGreen = this.register(new Setting("Glint Green", 0, 0, 255, (v) -> {
         return (Boolean)this.enchanted.getValue();
      }));
      this.enchantBlue = this.register(new Setting("Glint Blue", 255, 0, 255, (v) -> {
         return (Boolean)this.enchanted.getValue();
      }));
      this.enchantAlpha = this.register(new Setting("Glint Alpha", 255, 0, 255, (v) -> {
         return (Boolean)this.enchanted.getValue();
      }));
      this.texture = this.register(new Setting("Texture", false));
      this.colorSync = this.register(new Setting("Sync", false));
      this.red = this.register(new Setting("Red", 135, 0, 255));
      this.green = this.register(new Setting("Green", 0, 0, 255));
      this.blue = this.register(new Setting("Blue", 255, 0, 255));
      this.alpha = this.register(new Setting("Alpha", 255, 0, 255));
      this.outline = this.register(new Setting("Outline", false));
      this.lineWidth = this.register(new Setting("LineWidth", 1.0F, 0.1F, 5.0F, (v) -> {
         return (Boolean)this.outline.getValue();
      }));
      this.outlineRed = this.register(new Setting("Outline Red", 135, 0, 255, (v) -> {
         return (Boolean)this.outline.getValue();
      }));
      this.outlineGreen = this.register(new Setting("Outline Green", 0, 0, 255, (v) -> {
         return (Boolean)this.outline.getValue();
      }));
      this.outlineBlue = this.register(new Setting("Outline Blue", 255, 0, 255, (v) -> {
         return (Boolean)this.outline.getValue();
      }));
      this.outlineAlpha = this.register(new Setting("Outline Alpha", 90, 0, 255, (v) -> {
         return (Boolean)this.outline.getValue();
      }));
      this.hiddenSync = this.register(new Setting("Hidden Sync", false));
      this.hiddenRed = this.register(new Setting("Hidden Red", 135, 0, 255, (v) -> {
         return !(Boolean)this.hiddenSync.getValue();
      }));
      this.hiddenGreen = this.register(new Setting("Hidden Green", 0, 0, 255, (v) -> {
         return !(Boolean)this.hiddenSync.getValue();
      }));
      this.hiddenBlue = this.register(new Setting("Hidden Blue", 255, 0, 255, (v) -> {
         return !(Boolean)this.hiddenSync.getValue();
      }));
      this.hiddenAlpha = this.register(new Setting("Hidden Alpha", 90, 0, 255, (v) -> {
         return !(Boolean)this.hiddenSync.getValue();
      }));
      INSTANCE = this;
   }

   public static enum BlendModes {
      Default,
      Brighter;
   }

   public static enum outlineModes {
      WIRE,
      FLAT;
   }

   public static enum modes {
      FILL,
      WIREFRAME;
   }
}
