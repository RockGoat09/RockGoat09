package ryo.mrbubblegum.nhack4.lite.render;

import java.awt.Color;
import java.util.Iterator;
import java.util.Random;
import net.minecraft.util.math.BlockPos;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.impl.util.RotationUtil;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.Render3DEvent;

public class HoleESP extends Module {
   private static HoleESP INSTANCE = new HoleESP();
   private final Setting<Integer> holes = this.register(new Setting("Holes", 3, 1, 500));
   private final Setting<Integer> red = this.register(new Setting("Red", 255, 0, 255));
   private final Setting<Integer> green = this.register(new Setting("Green", 0, 0, 255));
   private final Setting<Integer> blue = this.register(new Setting("Blue", 0, 0, 255));
   private final Setting<Integer> alpha = this.register(new Setting("Alpha", 255, 0, 255));
   public Setting<Boolean> ownHole = this.register(new Setting("OwnHole", false));
   public Setting<Boolean> box = this.register(new Setting("Box", true));
   private final Setting<Integer> boxAlpha = this.register(new Setting("BoxAlpha", 125, 0, 255, (v) -> {
      return (Boolean)this.box.getValue();
   }));
   public Setting<Boolean> gradientBox = this.register(new Setting("GradientBox", false, (v) -> {
      return (Boolean)this.box.getValue();
   }));
   public Setting<Boolean> pulseAlpha = this.register(new Setting("PulseAlpha", false, (v) -> {
      return (Boolean)this.gradientBox.getValue();
   }));
   private final Setting<Integer> minPulseAlpha = this.register(new Setting("MinPulse", 10, 0, 255, (v) -> {
      return (Boolean)this.pulseAlpha.getValue();
   }));
   private final Setting<Integer> maxPulseAlpha = this.register(new Setting("MaxPulse", 40, 0, 255, (v) -> {
      return (Boolean)this.pulseAlpha.getValue();
   }));
   private final Setting<Integer> pulseSpeed = this.register(new Setting("PulseSpeed", 10, 1, 50, (v) -> {
      return (Boolean)this.pulseAlpha.getValue();
   }));
   public Setting<Boolean> pulseOutline = this.register(new Setting("PulseOutline", true, (v) -> {
      return (Boolean)this.gradientBox.getValue();
   }));
   public Setting<Boolean> invertGradientBox = this.register(new Setting("InvertGradientBox", false, (v) -> {
      return (Boolean)this.gradientBox.getValue();
   }));
   public Setting<Boolean> outline = this.register(new Setting("Outline", true));
   private final Setting<Float> lineWidth = this.register(new Setting("LineWidth", 1.0F, 0.1F, 5.0F, (v) -> {
      return (Boolean)this.outline.getValue();
   }));
   public Setting<Boolean> gradientOutline = this.register(new Setting("GradientOutline", false, (v) -> {
      return (Boolean)this.outline.getValue();
   }));
   public Setting<Boolean> invertGradientOutline = this.register(new Setting("InvertGradientOutline", false, (v) -> {
      return (Boolean)this.gradientOutline.getValue();
   }));
   public Setting<Double> height = this.register(new Setting("Height", 0.0D, -2.0D, 2.0D));
   public Setting<Boolean> safeColor = this.register(new Setting("SafeColor", true));
   private final Setting<Integer> safeRed = this.register(new Setting("SafeRed", 0, 0, 255, (v) -> {
      return (Boolean)this.safeColor.getValue();
   }));
   private final Setting<Integer> safeGreen = this.register(new Setting("SafeGreen", 255, 0, 255, (v) -> {
      return (Boolean)this.safeColor.getValue();
   }));
   private final Setting<Integer> safeBlue = this.register(new Setting("SafeBlue", 0, 0, 255, (v) -> {
      return (Boolean)this.safeColor.getValue();
   }));
   private final Setting<Integer> safeAlpha = this.register(new Setting("SafeAlpha", 255, 0, 255, (v) -> {
      return (Boolean)this.safeColor.getValue();
   }));
   public Setting<Boolean> customOutline = this.register(new Setting("CustomLine", false, (v) -> {
      return (Boolean)this.outline.getValue();
   }));
   private final Setting<Integer> cRed = this.register(new Setting("OL-Red", 0, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue();
   }));
   private final Setting<Integer> cGreen = this.register(new Setting("OL-Green", 0, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue();
   }));
   private final Setting<Integer> cBlue = this.register(new Setting("OL-Blue", 255, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue();
   }));
   private final Setting<Integer> cAlpha = this.register(new Setting("OL-Alpha", 255, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue();
   }));
   private final Setting<Integer> safecRed = this.register(new Setting("OL-SafeRed", 0, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue() && (Boolean)this.safeColor.getValue();
   }));
   private final Setting<Integer> safecGreen = this.register(new Setting("OL-SafeGreen", 255, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue() && (Boolean)this.safeColor.getValue();
   }));
   private final Setting<Integer> safecBlue = this.register(new Setting("OL-SafeBlue", 0, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue() && (Boolean)this.safeColor.getValue();
   }));
   private final Setting<Integer> safecAlpha = this.register(new Setting("OL-SafeAlpha", 255, 0, 255, (v) -> {
      return (Boolean)this.customOutline.getValue() && (Boolean)this.outline.getValue() && (Boolean)this.safeColor.getValue();
   }));
   private boolean pulsing = false;
   private boolean shouldDecrease = false;
   private int pulseDelay = 0;
   private int currentPulseAlpha;
   private int currentAlpha = 0;

   public HoleESP() {
      super("HoleRender", "render safe holes", Module.Category.RENDER, false, false, false);
      this.setInstance();
   }

   public static HoleESP getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new HoleESP();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   public void onRender3D(Render3DEvent event) {
      int drawnHoles = 0;
      if (!this.pulsing && (Boolean)this.pulseAlpha.getValue()) {
         Random rand = new Random();
         this.currentPulseAlpha = rand.nextInt((Integer)this.maxPulseAlpha.getValue() - (Integer)this.minPulseAlpha.getValue() + 1) + (Integer)this.minPulseAlpha.getValue();
         this.pulsing = true;
         this.shouldDecrease = false;
      }

      if (this.pulseDelay == 0) {
         if (this.pulsing && (Boolean)this.pulseAlpha.getValue() && !this.shouldDecrease) {
            ++this.currentAlpha;
            if (this.currentAlpha >= this.currentPulseAlpha) {
               this.shouldDecrease = true;
            }
         }

         if (this.pulsing && (Boolean)this.pulseAlpha.getValue() && this.shouldDecrease) {
            --this.currentAlpha;
         }

         if (this.currentAlpha <= 0) {
            this.pulsing = false;
            this.shouldDecrease = false;
         }

         ++this.pulseDelay;
      } else {
         ++this.pulseDelay;
         if (this.pulseDelay == 51 - (Integer)this.pulseSpeed.getValue()) {
            this.pulseDelay = 0;
         }
      }

      if (!(Boolean)this.pulseAlpha.getValue() || !this.pulsing) {
         this.currentAlpha = 0;
      }

      Iterator var5 = Loader.holeManager.getSortedHoles().iterator();

      while(var5.hasNext()) {
         BlockPos pos = (BlockPos)var5.next();
         if (drawnHoles >= (Integer)this.holes.getValue()) {
            break;
         }

         if ((!pos.equals(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v)) || (Boolean)this.ownHole.getValue()) && RotationUtil.isInFov(pos)) {
            if ((Boolean)this.safeColor.getValue() && Loader.holeManager.isSafe(pos)) {
               RenderUtil.drawBoxESP(pos, new Color((Integer)this.safeRed.getValue(), (Integer)this.safeGreen.getValue(), (Integer)this.safeBlue.getValue(), (Integer)this.safeAlpha.getValue()), (Boolean)this.customOutline.getValue(), new Color((Integer)this.safecRed.getValue(), (Integer)this.safecGreen.getValue(), (Integer)this.safecBlue.getValue(), (Integer)this.safecAlpha.getValue()), (Float)this.lineWidth.getValue(), (Boolean)this.outline.getValue(), (Boolean)this.box.getValue(), (Integer)this.boxAlpha.getValue(), true, (Double)this.height.getValue(), (Boolean)this.gradientBox.getValue(), (Boolean)this.gradientOutline.getValue(), (Boolean)this.invertGradientBox.getValue(), (Boolean)this.invertGradientOutline.getValue(), this.currentAlpha);
            } else {
               RenderUtil.drawBoxESP(pos, new Color((Integer)this.red.getValue(), (Integer)this.green.getValue(), (Integer)this.blue.getValue(), (Integer)this.alpha.getValue()), (Boolean)this.customOutline.getValue(), new Color((Integer)this.cRed.getValue(), (Integer)this.cGreen.getValue(), (Integer)this.cBlue.getValue(), (Integer)this.cAlpha.getValue()), (Float)this.lineWidth.getValue(), (Boolean)this.outline.getValue(), (Boolean)this.box.getValue(), (Integer)this.boxAlpha.getValue(), true, (Double)this.height.getValue(), (Boolean)this.gradientBox.getValue(), (Boolean)this.gradientOutline.getValue(), (Boolean)this.invertGradientBox.getValue(), (Boolean)this.invertGradientOutline.getValue(), this.currentAlpha);
            }

            ++drawnHoles;
         }
      }

   }
}
