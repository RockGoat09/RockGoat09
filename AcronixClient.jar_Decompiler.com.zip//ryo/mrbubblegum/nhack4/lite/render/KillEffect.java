package ryo.mrbubblegum.nhack4.lite.render;

import java.util.ArrayList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class KillEffect extends Module {
   final Object sync = new Object();
   public Setting<Boolean> thunder = this.register(new Setting("Thunder", true));
   public Setting<Integer> numbersThunder = this.register(new Setting("Number Thunder", 1, 1, 10));
   public Setting<Boolean> sound = this.register(new Setting("Sound", true));
   public Setting<Integer> numberSound = this.register(new Setting("Number Sound", 1, 1, 10));
   public Setting<Integer> timeActive = this.register(new Setting("TimeActive", 20, 0, 50));
   public Setting<Boolean> lightning = this.register(new Setting("Lightning", true));
   public Setting<Boolean> totemPop = this.register(new Setting("TotemPop", true));
   public Setting<Boolean> totemPopSound = this.register(new Setting("TotemPopSound", false));
   public Setting<Boolean> firework = this.register(new Setting("FireWork", false));
   public Setting<Boolean> fire = this.register(new Setting("Fire", false));
   public Setting<Boolean> water = this.register(new Setting("Water", false));
   public Setting<Boolean> smoke = this.register(new Setting("Smoke", false));
   public Setting<Boolean> players = this.register(new Setting("Players", true));
   public Setting<Boolean> animals = this.register(new Setting("Animals", true));
   public Setting<Boolean> mobs = this.register(new Setting("Mobs", true));
   public Setting<Boolean> all = this.register(new Setting("All", true));
   ArrayList<EntityPlayer> playersDead = new ArrayList();

   public KillEffect() {
      super("KillRender", "render cool stuff when u kill someone", Module.Category.RENDER, true, false, false);
   }

   public void onEnable() {
      this.playersDead.clear();
   }

   public void onUpdate() {
      if (mc.field_71441_e == null) {
         this.playersDead.clear();
      } else {
         mc.field_71441_e.field_73010_i.forEach((entity) -> {
            if (this.playersDead.contains(entity)) {
               if (entity.func_110143_aJ() > 0.0F) {
                  this.playersDead.remove(entity);
               }
            } else if (entity.func_110143_aJ() == 0.0F) {
               int i;
               if ((Boolean)this.thunder.getValue()) {
                  for(i = 0; i < (Integer)this.numbersThunder.getValue(); ++i) {
                     mc.field_71441_e.func_72838_d(new EntityLightningBolt(mc.field_71441_e, entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, true));
                  }
               }

               if ((Boolean)this.sound.getValue()) {
                  for(i = 0; i < (Integer)this.numberSound.getValue(); ++i) {
                     mc.field_71439_g.func_184185_a(SoundEvents.field_187754_de, 0.5F, 1.0F);
                  }
               }

               this.playersDead.add(entity);
            }

         });
      }
   }

   @SubscribeEvent
   public void onDeath(LivingDeathEvent event) {
      if (event.getEntity() != mc.field_71439_g) {
         if (this.shouldRenderParticle(event.getEntity())) {
            if ((Boolean)this.lightning.getValue()) {
               mc.field_71441_e.func_73027_a(-999, new EntityLightningBolt(mc.field_71441_e, event.getEntity().field_70165_t, event.getEntity().field_70163_u, event.getEntity().field_70161_v, true));
            }

            if ((Boolean)this.totemPop.getValue()) {
               this.totemPop(event.getEntity());
            }

            if ((Boolean)this.firework.getValue()) {
               mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.FIREWORKS_SPARK, (Integer)this.timeActive.getValue());
            }

            if ((Boolean)this.fire.getValue()) {
               mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.FLAME, (Integer)this.timeActive.getValue());
               mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.DRIP_LAVA, (Integer)this.timeActive.getValue());
            }

            if ((Boolean)this.water.getValue()) {
               mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.WATER_BUBBLE, (Integer)this.timeActive.getValue());
               mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.WATER_DROP, (Integer)this.timeActive.getValue());
            }

            if ((Boolean)this.smoke.getValue()) {
               mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.SMOKE_NORMAL, (Integer)this.timeActive.getValue());
            }
         }

      }
   }

   public boolean shouldRenderParticle(Entity entity) {
      return entity != mc.field_71439_g && ((Boolean)this.all.getValue() || entity instanceof EntityPlayer && (Boolean)this.players.getValue() || entity instanceof EntityMob || entity instanceof EntitySlime && (Boolean)this.mobs.getValue() || entity instanceof EntityAnimal && (Boolean)this.animals.getValue());
   }

   public void totemPop(Entity entity) {
      mc.field_71452_i.func_191271_a(entity, EnumParticleTypes.TOTEM, (Integer)this.timeActive.getValue());
      if ((Boolean)this.totemPopSound.getValue()) {
         mc.field_71441_e.func_184134_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, SoundEvents.field_191263_gW, entity.func_184176_by(), 1.0F, 1.0F, false);
      }

   }
}
