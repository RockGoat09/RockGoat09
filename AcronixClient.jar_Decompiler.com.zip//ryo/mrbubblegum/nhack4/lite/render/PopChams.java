package ryo.mrbubblegum.nhack4.lite.render;

import com.mojang.authlib.GameProfile;
import java.awt.Color;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import ryo.mrbubblegum.nhack4.impl.util.NordTessellator;
import ryo.mrbubblegum.nhack4.impl.util.TotemPopChams;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.PacketEvent;

public class PopChams extends Module {
   public static Setting<Boolean> self;
   public static Setting<Boolean> elevator;
   public static Setting<Integer> rL;
   public static Setting<Integer> gL;
   public static Setting<Integer> bL;
   public static Setting<Integer> aL;
   public static Setting<Integer> rF;
   public static Setting<Integer> gF;
   public static Setting<Integer> bF;
   public static Setting<Integer> aF;
   public static Setting<Integer> fadestart;
   public static Setting<Float> fadetime;
   public static Setting<Boolean> onlyOneEsp;
   public static Setting<PopChams.ElevatorMode> elevatorMode;
   EntityOtherPlayerMP player;
   ModelPlayer playerModel;
   Long startTime;
   double alphaFill;
   double alphaLine;

   public PopChams() {
      super("PopChams", "Renders a Glowing fakeplayer in the exact location where your enemy popped", Module.Category.RENDER, true, false, false);
      self = this.register(new Setting("Render Own Pops", true));
      elevator = this.register(new Setting("Travel", true));
      elevatorMode = this.register(new Setting("Elevator", PopChams.ElevatorMode.UP, (v) -> {
         return (Boolean)elevator.getValue();
      }));
      rL = this.register(new Setting("Outline Red", 135, 0, 255));
      bL = this.register(new Setting("Outline Green", 0, 0, 255));
      gL = this.register(new Setting("Outline Blue", 255, 0, 255));
      aL = this.register(new Setting("Outline Alpha", 255, 0, 255));
      rF = this.register(new Setting("Fill Red", 135, 0, 255));
      bF = this.register(new Setting("Fill Green", 0, 0, 255));
      gF = this.register(new Setting("Fill Blue", 255, 0, 255));
      aF = this.register(new Setting("Fill Alpha", 140, 0, 255));
      fadestart = this.register(new Setting("Fade Start", 0, 0, 255));
      fadetime = this.register(new Setting("Fade Time", 0.5F, 0.0F, 2.0F));
      onlyOneEsp = this.register(new Setting("Only Render One", true));
   }

   public static void renderEntity(EntityLivingBase entity, ModelBase modelBase, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, int scale) {
      if (Util.mc.func_175598_ae() != null) {
         float partialTicks = Util.mc.func_184121_ak();
         double x = entity.field_70165_t - mc.func_175598_ae().field_78730_l;
         double y = entity.field_70163_u - mc.func_175598_ae().field_78731_m;
         double z = entity.field_70161_v - mc.func_175598_ae().field_78728_n;
         GlStateManager.func_179094_E();
         if (entity.func_70093_af()) {
            y -= 0.125D;
         }

         float interpolateRotation = interpolateRotation(entity.field_70760_ar, entity.field_70761_aq, partialTicks);
         float interpolateRotation2 = interpolateRotation(entity.field_70758_at, entity.field_70759_as, partialTicks);
         float var10000 = interpolateRotation2 - interpolateRotation;
         var10000 = entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks;
         renderLivingAt(x, y, z);
         float f8 = handleRotationFloat(entity, partialTicks);
         prepareRotations(entity);
         float f9 = prepareScale(entity, (float)scale);
         GlStateManager.func_179141_d();
         modelBase.func_78086_a(entity, limbSwing, limbSwingAmount, partialTicks);
         modelBase.func_78087_a(limbSwing, limbSwingAmount, f8, entity.field_70177_z, entity.field_70125_A, f9, entity);
         modelBase.func_78088_a(entity, limbSwing, limbSwingAmount, f8, entity.field_70177_z, entity.field_70125_A, f9);
         GlStateManager.func_179121_F();
      }
   }

   public static void prepareTranslate(EntityLivingBase entityIn, double x, double y, double z) {
      renderLivingAt(x - mc.func_175598_ae().field_78730_l, y - mc.func_175598_ae().field_78731_m, z - mc.func_175598_ae().field_78728_n);
   }

   public static void renderLivingAt(double x, double y, double z) {
      GlStateManager.func_179109_b((float)x, (float)y, (float)z);
   }

   public static float prepareScale(EntityLivingBase entity, float scale) {
      GlStateManager.func_179091_B();
      GlStateManager.func_179152_a(-1.0F, -1.0F, 1.0F);
      double widthX = entity.func_184177_bl().field_72336_d - entity.func_184177_bl().field_72340_a;
      double widthZ = entity.func_184177_bl().field_72334_f - entity.func_184177_bl().field_72339_c;
      GlStateManager.func_179139_a((double)scale + widthX, (double)(scale * entity.field_70131_O), (double)scale + widthZ);
      float f = 0.0625F;
      GlStateManager.func_179109_b(0.0F, -1.501F, 0.0F);
      return 0.0625F;
   }

   public static void prepareRotations(EntityLivingBase entityLivingBase) {
      GlStateManager.func_179114_b(180.0F - entityLivingBase.field_70177_z, 0.0F, 1.0F, 0.0F);
   }

   public static float interpolateRotation(float prevYawOffset, float yawOffset, float partialTicks) {
      float f;
      for(f = yawOffset - prevYawOffset; f < -180.0F; f += 360.0F) {
      }

      while(f >= 180.0F) {
         f -= 360.0F;
      }

      return prevYawOffset + partialTicks * f;
   }

   public static Color newAlpha(Color color, int alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   public static void glColor(Color color) {
      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
   }

   public static float handleRotationFloat(EntityLivingBase livingBase, float partialTicks) {
      return 0.0F;
   }

   @SubscribeEvent
   public void onUpdate(PacketEvent.Receive event) {
      SPacketEntityStatus packet;
      if (event.getPacket() instanceof SPacketEntityStatus && (packet = (SPacketEntityStatus)event.getPacket()).func_149160_c() == 35 && packet.func_149161_a(mc.field_71441_e) != null && ((Boolean)self.getValue() || packet.func_149161_a(mc.field_71441_e).func_145782_y() != mc.field_71439_g.func_145782_y())) {
         GameProfile profile = new GameProfile(mc.field_71439_g.func_110124_au(), "");
         this.player = new EntityOtherPlayerMP(mc.field_71441_e, profile);
         this.player.func_82149_j(packet.func_149161_a(mc.field_71441_e));
         this.playerModel = new ModelPlayer(0.0F, false);
         this.startTime = System.currentTimeMillis();
         this.playerModel.field_78116_c.field_78806_j = false;
         this.playerModel.field_78115_e.field_78806_j = false;
         this.playerModel.field_178734_a.field_78806_j = false;
         this.playerModel.field_178733_c.field_78806_j = false;
         this.playerModel.field_178732_b.field_78806_j = false;
         this.playerModel.field_178731_d.field_78806_j = false;
         this.alphaFill = (double)(Integer)aF.getValue();
         this.alphaLine = (double)(Integer)aL.getValue();
         if (!(Boolean)onlyOneEsp.getValue()) {
            new TotemPopChams(this.player, this.playerModel, this.startTime, this.alphaFill, this.alphaLine);
         }
      }

   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent event) {
      if ((Boolean)onlyOneEsp.getValue()) {
         if (this.player == null || mc.field_71441_e == null || mc.field_71439_g == null) {
            return;
         }

         if ((Boolean)elevator.getValue()) {
            EntityOtherPlayerMP var10000;
            if (elevatorMode.getValue() == PopChams.ElevatorMode.UP) {
               var10000 = this.player;
               var10000.field_70163_u += (double)(0.05F * event.getPartialTicks());
            } else if (elevatorMode.getValue() == PopChams.ElevatorMode.DOWN) {
               var10000 = this.player;
               var10000.field_70163_u -= (double)(0.05F * event.getPartialTicks());
            }
         }

         GL11.glLineWidth(1.0F);
         Color lineColorS = new Color((Integer)rL.getValue(), (Integer)bL.getValue(), (Integer)gL.getValue(), (Integer)aL.getValue());
         Color fillColorS = new Color((Integer)rF.getValue(), (Integer)bF.getValue(), (Integer)gF.getValue(), (Integer)aF.getValue());
         int lineA = lineColorS.getAlpha();
         int fillA = fillColorS.getAlpha();
         long time = System.currentTimeMillis() - this.startTime - ((Number)fadestart.getValue()).longValue();
         if (System.currentTimeMillis() - this.startTime > ((Number)fadestart.getValue()).longValue()) {
            double normal = this.normalize((double)time, 0.0D, ((Number)fadetime.getValue()).doubleValue());
            normal = MathHelper.func_151237_a(normal, 0.0D, 1.0D);
            normal = -normal + 1.0D;
            lineA *= (int)normal;
            fillA *= (int)normal;
         }

         Color lineColor = newAlpha(lineColorS, lineA);
         Color fillColor = newAlpha(fillColorS, fillA);
         if (this.player != null && this.playerModel != null) {
            NordTessellator.prepareGL();
            GL11.glPushAttrib(1048575);
            GL11.glEnable(2881);
            GL11.glEnable(2848);
            if (this.alphaFill > 1.0D) {
               this.alphaFill -= (double)(Float)fadetime.getValue();
            }

            Color fillFinal = new Color(fillColor.getRed(), fillColor.getGreen(), fillColor.getBlue(), (int)this.alphaFill);
            if (this.alphaLine > 1.0D) {
               this.alphaLine -= (double)(Float)fadetime.getValue();
            }

            Color outlineFinal = new Color(lineColor.getRed(), lineColor.getGreen(), lineColor.getBlue(), (int)this.alphaLine);
            glColor(fillFinal);
            GL11.glPolygonMode(1032, 6914);
            renderEntity(this.player, this.playerModel, this.player.field_184619_aG, this.player.field_70721_aZ, (float)this.player.field_70173_aa, this.player.field_70759_as, this.player.field_70125_A, 1);
            glColor(outlineFinal);
            GL11.glPolygonMode(1032, 6913);
            renderEntity(this.player, this.playerModel, this.player.field_184619_aG, this.player.field_70721_aZ, (float)this.player.field_70173_aa, this.player.field_70759_as, this.player.field_70125_A, 1);
            GL11.glPolygonMode(1032, 6914);
            GL11.glPopAttrib();
            NordTessellator.releaseGL();
         }
      }

   }

   double normalize(double value, double min, double max) {
      return (value - min) / (max - min);
   }

   public static enum ElevatorMode {
      UP,
      DOWN;
   }
}
