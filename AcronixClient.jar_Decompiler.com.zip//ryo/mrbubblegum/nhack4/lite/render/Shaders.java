package ryo.mrbubblegum.nhack4.lite.render;

import java.awt.Color;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.AquaShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.CircleShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.FillShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.FlowShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.GradientShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.PhobosShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.RainbowCubeShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.fill.SmokeShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.AquaOutlineShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.AstralOutlineShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.CircleOutlineShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.GlowShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.GradientOutlineShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.RainbowCubeOutlineShader;
import ryo.mrbubblegum.nhack4.impl.util.shaders.impl.outline.SmokeOutlineShader;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class Shaders extends Module {
   public Setting<Float> duplicateOutline = this.register(new Setting("duplicateOutline", 1.0F, 0.0F, 20.0F));
   public Setting<Float> duplicateFill = this.register(new Setting("Duplicate Fill", 1.0F, 0.0F, 5.0F));
   public Setting<Float> speedOutline = this.register(new Setting("Speed Outline", 10.0F, 1.0F, 100.0F));
   public Setting<Float> speedFill = this.register(new Setting("Speed Fill", 10.0F, 1.0F, 100.0F));
   public Setting<Float> quality = this.register(new Setting("Shader Quality", 1.0F, 0.0F, 20.0F));
   public Setting<Float> radius = this.register(new Setting("Shader Radius", 1.0F, 0.0F, 5.0F));
   public Setting<Integer> maxEntities = this.register(new Setting("Max Entities", 100, 10, 500));
   public Setting<Integer> alphaValue = this.register(new Setting("Alpha Outline", 255, 0, 255));
   public Setting<Integer> colorESPred = this.register(new Setting("colorESP Red", 0, 0, 255));
   public Setting<Integer> colorESPgreen = this.register(new Setting("colorESP Green", 0, 0, 255));
   public Setting<Integer> colorESPblue = this.register(new Setting("colorESP Blue", 0, 0, 255));
   public Setting<Integer> colorESPalpha = this.register(new Setting("colorESP Alpha", 255, 0, 255));
   public Setting<Integer> colorImgFillred = this.register(new Setting("colorImgFill Red", 0, 0, 255));
   public Setting<Integer> colorImgFillgreen = this.register(new Setting("colorImgFill Green", 0, 0, 255));
   public Setting<Integer> colorImgFillblue = this.register(new Setting("colorImgFill Blue", 0, 0, 255));
   public Setting<Integer> colorImgFillalpha = this.register(new Setting("colorImgFill Alpha", 255, 0, 255));
   public boolean renderTags = true;
   public boolean renderCape = true;
   private final Setting<Shaders.fillShadermode> fillShader;
   public Setting<Float> rad;
   public Setting<Float> PI;
   public Setting<Float> saturationFill;
   public Setting<Float> distfadingFill;
   public Setting<Float> titleFill;
   public Setting<Float> stepSizeFill;
   public Setting<Float> volumStepsFill;
   public Setting<Float> zoomFill;
   public Setting<Float> formuparam2Fill;
   public Setting<Integer> iterationsFill;
   public Setting<Integer> redFill;
   public Setting<Integer> MaxIterFill;
   public Setting<Integer> NUM_OCTAVESFill;
   public Setting<Integer> BSTARTFIll;
   public Setting<Integer> GSTARTFill;
   public Setting<Integer> RSTARTFill;
   public Setting<Integer> WaveLenghtFIll;
   public Setting<Float> alphaFill;
   public Setting<Float> blueFill;
   public Setting<Float> greenFill;
   public Setting<Float> tauFill;
   public Setting<Float> creepyFill;
   public Setting<Float> moreGradientFill;
   private final Setting<Shaders.glowESPmode> glowESP;
   public Setting<Float> saturationOutline;
   public Setting<Integer> volumStepsOutline;
   public Setting<Integer> iterationsOutline;
   public Setting<Integer> MaxIterOutline;
   public Setting<Integer> NUM_OCTAVESOutline;
   public Setting<Integer> BSTARTOutline;
   public Setting<Integer> GSTARTOutline;
   public Setting<Integer> RSTARTOutline;
   public Setting<Integer> WaveLenghtOutline;
   public Setting<Integer> redOutline;
   public Setting<Float> distfadingOutline;
   public Setting<Float> titleOutline;
   public Setting<Float> stepSizeOutline;
   public Setting<Float> zoomOutline;
   public Setting<Float> formuparam2Outline;
   public Setting<Float> alphaOutline;
   public Setting<Float> blueOutline;
   public Setting<Float> greenOutline;
   public Setting<Float> tauOutline;
   public Setting<Float> creepyOutline;
   public Setting<Float> moreGradientOutline;
   public Setting<Float> radOutline;
   public Setting<Float> PIOutline;
   public Setting<Integer> colorImgOutlinered;
   public Setting<Integer> colorImgOutlinegreen;
   public Setting<Integer> colorImgOutlineblue;
   public Setting<Integer> colorImgOutlinealpha;
   public Setting<Integer> thirdColorImgOutlinered;
   public Setting<Integer> thirdColorImgOutlinegreen;
   public Setting<Integer> thirdColorImgOutlineblue;
   public Setting<Integer> thirdColorImgOutlinealpha;
   public Setting<Integer> thirdColorImgFIllred;
   public Setting<Integer> thirdColorImgFIllgreen;
   public Setting<Integer> thirdColorImgFIllblue;
   public Setting<Integer> thirdColorImgFIllalpha;
   public Setting<Integer> secondColorImgFillred;
   public Setting<Integer> secondColorImgFillgreen;
   public Setting<Integer> secondColorImgFillblue;
   public Setting<Integer> secondColorImgFillalpha;
   private final Setting<Shaders.Crystal1> crystal;
   private final Setting<Shaders.Player1> player;
   private final Setting<Shaders.Mob1> mob;
   private final Setting<Shaders.Itemsl> items;
   private final Setting<Shaders.XPl> xpOrb;
   private final Setting<Shaders.XPBl> xpBottle;
   private final Setting<Shaders.EPl> enderPearl;
   private final Setting<Boolean> rangeCheck;
   public Setting<Float> maxRange;
   public Setting<Float> minRange;
   private final Setting<Boolean> default1;
   private final Setting<Boolean> Fpreset;
   private final Setting<Boolean> fadeFill;
   private final Setting<Boolean> fadeOutline;

   public Shaders() {
      super("Shader", "Spawns in a fake player", Module.Category.RENDER, true, false, false);
      this.fillShader = this.register(new Setting("Fill Shader", Shaders.fillShadermode.None));
      this.rad = this.register(new Setting("RAD Fill", 0.75F, 0.0F, 5.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Circle;
      }));
      this.PI = this.register(new Setting("PI Fill", 3.1415927F, 0.0F, 10.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Circle;
      }));
      this.saturationFill = this.register(new Setting("saturation", 0.4F, 0.0F, 3.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.distfadingFill = this.register(new Setting("distfading", 0.56F, 0.0F, 1.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.titleFill = this.register(new Setting("Tile", 0.45F, 0.0F, 1.3F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.stepSizeFill = this.register(new Setting("Step Size", 0.2F, 0.0F, 0.7F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.volumStepsFill = this.register(new Setting("Volum Steps", 10.0F, 0.0F, 10.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.zoomFill = this.register(new Setting("Zoom", 3.9F, 0.0F, 20.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.formuparam2Fill = this.register(new Setting("formuparam2", 0.89F, 0.0F, 1.5F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.iterationsFill = this.register(new Setting("Iteration", 4, 3, 20, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.redFill = this.register(new Setting("Tick Regen", 0, 0, 100, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.MaxIterFill = this.register(new Setting("Max Iter", 5, 0, 30, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Aqua;
      }));
      this.NUM_OCTAVESFill = this.register(new Setting("NUM_OCTAVES", 5, 1, 30, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke;
      }));
      this.BSTARTFIll = this.register(new Setting("BSTART", 0, 0, 1000, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube;
      }));
      this.GSTARTFill = this.register(new Setting("GSTART", 0, 0, 1000, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube;
      }));
      this.RSTARTFill = this.register(new Setting("RSTART", 0, 0, 1000, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube;
      }));
      this.WaveLenghtFIll = this.register(new Setting("Wave Lenght", 555, 0, 2000, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube;
      }));
      this.alphaFill = this.register(new Setting("AlphaF", 1.0F, 0.0F, 1.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral || this.fillShader.getValue() == Shaders.fillShadermode.Smoke;
      }));
      this.blueFill = this.register(new Setting("BlueF", 0.0F, 0.0F, 5.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.greenFill = this.register(new Setting("GreenF", 0.0F, 0.0F, 5.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral;
      }));
      this.tauFill = this.register(new Setting("TAU", 6.2831855F, 0.0F, 20.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Aqua;
      }));
      this.creepyFill = this.register(new Setting("Creepy", 1.0F, 0.0F, 20.0F, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke;
      }));
      this.moreGradientFill = this.register(new Setting("More Gradient", 1.0F, 0.0F, 10.0D, (object) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke;
      }));
      this.glowESP = this.register(new Setting("Glow ESP", Shaders.glowESPmode.None));
      this.saturationOutline = this.register(new Setting("saturation", 0.4F, 0.0F, 3.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.volumStepsOutline = this.register(new Setting("Volum Steps", 10, 0, 10, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.iterationsOutline = this.register(new Setting("Iteration", 4, 3, 20, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.MaxIterOutline = this.register(new Setting("Max Iter", 5, 0, 30, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Aqua;
      }));
      this.NUM_OCTAVESOutline = this.register(new Setting("NUM_OCTAVES", 5, 1, 30, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.BSTARTOutline = this.register(new Setting("BSTART", 0, 0, 1000, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.GSTARTOutline = this.register(new Setting("GSTART", 0, 0, 1000, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.RSTARTOutline = this.register(new Setting("RSTART", 0, 0, 1000, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.WaveLenghtOutline = this.register(new Setting("Wave Lenght", 555, 0, 2000, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.redOutline = this.register(new Setting("Red", 0, 0, 100, (n) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.distfadingOutline = this.register(new Setting("distfading", 0.56F, 0.0F, 1.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.titleOutline = this.register(new Setting("Tile", 0.45F, 0.0F, 1.3F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.stepSizeOutline = this.register(new Setting("Step Size", 0.19F, 0.0F, 0.7F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.zoomOutline = this.register(new Setting("Zoom", 3.9F, 0.0F, 20.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.formuparam2Outline = this.register(new Setting("formuparam2", 0.89F, 0.0F, 1.5F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.alphaOutline = this.register(new Setting("Alpha", 1.0F, 0.0F, 1.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral || this.glowESP.getValue() == Shaders.glowESPmode.Gradient;
      }));
      this.blueOutline = this.register(new Setting("Blue", 0.0F, 0.0F, 5.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.greenOutline = this.register(new Setting("Green", 0.0F, 0.0F, 5.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.tauOutline = this.register(new Setting("TAU", 6.2831855F, 0.0F, 20.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Aqua;
      }));
      this.creepyOutline = this.register(new Setting("Gradient Creepy", 1.0F, 0.0F, 20.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Gradient;
      }));
      this.moreGradientOutline = this.register(new Setting("More Gradient", 1.0F, 0.0F, 10.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Gradient;
      }));
      this.radOutline = this.register(new Setting("RAD Outline", 0.75F, 0.0F, 5.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Circle;
      }));
      this.PIOutline = this.register(new Setting("PI Outline", 3.1415927F, 0.0F, 10.0F, (object) -> {
         return this.glowESP.getValue() == Shaders.glowESPmode.Circle;
      }));
      this.colorImgOutlinered = this.register(new Setting("colorImgOutline Red", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube || this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.colorImgOutlinegreen = this.register(new Setting("colorImgOutline Green", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube || this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.colorImgOutlineblue = this.register(new Setting("colorImgOutline Blue", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube || this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.colorImgOutlinealpha = this.register(new Setting("colorImgOutline Alpha", 255, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube || this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube;
      }));
      this.thirdColorImgOutlinered = this.register(new Setting("thirdColorImgOutline Red", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgOutlinegreen = this.register(new Setting("thirdColorImgOutline Green", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgOutlineblue = this.register(new Setting("thirdColorImgOutline Blue", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgOutlinealpha = this.register(new Setting("thirdColorImgOutline Alpha", 255, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgFIllred = this.register(new Setting("SmokeImgFill Red", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgFIllgreen = this.register(new Setting("SmokeImgFill Green", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgFIllblue = this.register(new Setting("SmokeFImgill Blue", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.thirdColorImgFIllalpha = this.register(new Setting("SmokeImgFill Alpha", 255, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.secondColorImgFillred = this.register(new Setting("SmokeFill Red", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.secondColorImgFillgreen = this.register(new Setting("SmokeFill Green", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.secondColorImgFillblue = this.register(new Setting("SmokeFill Blue", 0, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.secondColorImgFillalpha = this.register(new Setting("SmokeFill Alpha", 255, 0, 255, (n) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Smoke || this.glowESP.getValue() == Shaders.glowESPmode.Smoke;
      }));
      this.crystal = this.register(new Setting("Crystals", Shaders.Crystal1.None));
      this.player = this.register(new Setting("Players", Shaders.Player1.None));
      this.mob = this.register(new Setting("Mobs", Shaders.Mob1.None));
      this.items = this.register(new Setting("Items", Shaders.Itemsl.None));
      this.xpOrb = this.register(new Setting("XP", Shaders.XPl.None));
      this.xpBottle = this.register(new Setting("XPBottle", Shaders.XPBl.None));
      this.enderPearl = this.register(new Setting("EnderPearl", Shaders.EPl.None));
      this.rangeCheck = this.register(new Setting("Range Check", true));
      this.maxRange = this.register(new Setting("Max Range", 35.0F, 10.0F, 100.0F, (object) -> {
         return (Boolean)this.rangeCheck.getValue();
      }));
      this.minRange = this.register(new Setting("Min range", 0.0F, 0.0F, 5.0F, (object) -> {
         return (Boolean)this.rangeCheck.getValue();
      }));
      this.default1 = this.register(new Setting("Reset Setting", false));
      this.Fpreset = this.register(new Setting("FutureRainbow Preset", false));
      this.fadeFill = this.register(new Setting("Fade Fill", false, (bl) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral || this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
      this.fadeOutline = this.register(new Setting("FadeOL Fill", false, (bl) -> {
         return this.fillShader.getValue() == Shaders.fillShadermode.Astral || this.glowESP.getValue() == Shaders.glowESPmode.Astral;
      }));
   }

   @SubscribeEvent
   public void onRenderGameOverlay(RenderGameOverlayEvent renderGameOverlayEvent) {
      if (renderGameOverlayEvent.getType() == ElementType.HOTBAR) {
         if (mc.field_71441_e == null || mc.field_71439_g == null) {
            return;
         }

         GlStateManager.func_179094_E();
         this.renderTags = false;
         this.renderCape = false;
         Color color = new Color((Integer)this.colorImgFillred.getValue(), (Integer)this.colorImgFillgreen.getValue(), (Integer)this.colorImgFillblue.getValue(), (Integer)this.colorImgFillalpha.getValue());
         Color color2 = new Color((Integer)this.colorESPred.getValue(), (Integer)this.colorESPgreen.getValue(), (Integer)this.colorESPblue.getValue(), (Integer)this.colorESPalpha.getValue());
         Color color3 = new Color((Integer)this.secondColorImgFillred.getValue(), (Integer)this.secondColorImgFillgreen.getValue(), (Integer)this.secondColorImgFillblue.getValue(), (Integer)this.secondColorImgFillalpha.getValue());
         Color color4 = new Color((Integer)this.thirdColorImgOutlinered.getValue(), (Integer)this.thirdColorImgOutlinegreen.getValue(), (Integer)this.thirdColorImgOutlineblue.getValue(), (Integer)this.thirdColorImgOutlinealpha.getValue());
         Color color5 = new Color((Integer)this.thirdColorImgFIllred.getValue(), (Integer)this.thirdColorImgFIllgreen.getValue(), (Integer)this.thirdColorImgFIllblue.getValue(), (Integer)this.thirdColorImgFIllalpha.getValue());
         Color color6 = new Color((Integer)this.colorImgOutlinered.getValue(), (Integer)this.colorImgOutlinegreen.getValue(), (Integer)this.colorImgOutlineblue.getValue(), (Integer)this.colorImgOutlinealpha.getValue());
         if (this.glowESP.getValue() != Shaders.glowESPmode.None && this.fillShader.getValue() != Shaders.fillShadermode.None) {
            Predicate<Boolean> predicate = this.getFill();
            switch((Shaders.fillShadermode)this.fillShader.getValue()) {
            case Astral:
               FlowShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               FlowShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), ((Integer)this.redFill.getValue()).floatValue(), (Float)this.greenFill.getValue(), (Float)this.blueFill.getValue(), (Float)this.alphaFill.getValue(), (Integer)this.iterationsFill.getValue(), (Float)this.formuparam2Fill.getValue(), (Float)this.zoomFill.getValue(), (Float)this.volumStepsFill.getValue(), (Float)this.stepSizeFill.getValue(), (Float)this.titleFill.getValue(), (Float)this.distfadingFill.getValue(), (Float)this.saturationFill.getValue(), 0.0F, (Boolean)this.fadeFill.getValue() ? 1 : 0);
               FlowShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Aqua:
               AquaShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               AquaShader.INSTANCE.stopDraw(color, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), (Integer)this.MaxIterFill.getValue(), (double)(Float)this.tauFill.getValue());
               AquaShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Smoke:
               SmokeShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               SmokeShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), color, color3, color5, (Integer)this.NUM_OCTAVESFill.getValue());
               SmokeShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case RainbowCube:
               RainbowCubeShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               RainbowCubeShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), color, (Integer)this.WaveLenghtFIll.getValue(), (Integer)this.RSTARTFill.getValue(), (Integer)this.GSTARTFill.getValue(), (Integer)this.BSTARTFIll.getValue());
               RainbowCubeShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Gradient:
               GradientShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               GradientShader.INSTANCE.stopDraw(color2, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), (Float)this.moreGradientFill.getValue(), (Float)this.creepyFill.getValue(), (Float)this.alphaFill.getValue(), (Integer)this.NUM_OCTAVESFill.getValue());
               GradientShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Fill:
               FillShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               FillShader.INSTANCE.stopDraw(color);
               FillShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Circle:
               CircleShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               CircleShader.INSTANCE.stopDraw((Float)this.duplicateFill.getValue(), color, (Float)this.PI.getValue(), (Float)this.rad.getValue());
               CircleShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Phobos:
               PhobosShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               PhobosShader.INSTANCE.stopDraw(color, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), (Integer)this.MaxIterFill.getValue(), (double)(Float)this.tauFill.getValue());
               PhobosShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
            }

            switch((Shaders.glowESPmode)this.glowESP.getValue()) {
            case Color:
               GlowShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               GlowShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue());
               break;
            case RainbowCube:
               RainbowCubeOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               RainbowCubeOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), color6, (Integer)this.WaveLenghtOutline.getValue(), (Integer)this.RSTARTOutline.getValue(), (Integer)this.GSTARTOutline.getValue(), (Integer)this.BSTARTOutline.getValue());
               RainbowCubeOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Gradient:
               GradientOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               GradientOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), (Float)this.moreGradientOutline.getValue(), (Float)this.creepyOutline.getValue(), (Float)this.alphaOutline.getValue(), (Integer)this.NUM_OCTAVESOutline.getValue());
               GradientOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Astral:
               AstralOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               AstralOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), ((Integer)this.redOutline.getValue()).floatValue(), (Float)this.greenOutline.getValue(), (Float)this.blueOutline.getValue(), (Float)this.alphaOutline.getValue(), (Integer)this.iterationsOutline.getValue(), (Float)this.formuparam2Outline.getValue(), (Float)this.zoomOutline.getValue(), (float)(Integer)this.volumStepsOutline.getValue(), (Float)this.stepSizeOutline.getValue(), (Float)this.titleOutline.getValue(), (Float)this.distfadingOutline.getValue(), (Float)this.saturationOutline.getValue(), 0.0F, (Boolean)this.fadeOutline.getValue() ? 1 : 0);
               AstralOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Aqua:
               AquaOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               AquaOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), (Integer)this.MaxIterOutline.getValue(), (double)(Float)this.tauOutline.getValue());
               AquaOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Circle:
               CircleOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               CircleOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), (Float)this.PIOutline.getValue(), (Float)this.radOutline.getValue());
               CircleOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Smoke:
               SmokeOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               SmokeOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), color3, color4, (Integer)this.NUM_OCTAVESOutline.getValue());
               SmokeOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
            }
         } else {
            switch((Shaders.glowESPmode)this.glowESP.getValue()) {
            case Color:
               GlowShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               GlowShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue());
               break;
            case RainbowCube:
               RainbowCubeOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               RainbowCubeOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), color6, (Integer)this.WaveLenghtOutline.getValue(), (Integer)this.RSTARTOutline.getValue(), (Integer)this.GSTARTOutline.getValue(), (Integer)this.BSTARTOutline.getValue());
               RainbowCubeOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Gradient:
               GradientOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               GradientOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), (Float)this.moreGradientOutline.getValue(), (Float)this.creepyOutline.getValue(), (Float)this.alphaOutline.getValue(), (Integer)this.NUM_OCTAVESOutline.getValue());
               GradientOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Astral:
               AstralOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               AstralOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), ((Integer)this.redOutline.getValue()).floatValue(), (Float)this.greenOutline.getValue(), (Float)this.blueOutline.getValue(), (Float)this.alphaOutline.getValue(), (Integer)this.iterationsOutline.getValue(), (Float)this.formuparam2Outline.getValue(), (Float)this.zoomOutline.getValue(), (float)(Integer)this.volumStepsOutline.getValue(), (Float)this.stepSizeOutline.getValue(), (Float)this.titleOutline.getValue(), (Float)this.distfadingOutline.getValue(), (Float)this.saturationOutline.getValue(), 0.0F, (Boolean)this.fadeOutline.getValue() ? 1 : 0);
               AstralOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Aqua:
               AquaOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               AquaOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), (Integer)this.MaxIterOutline.getValue(), (double)(Float)this.tauOutline.getValue());
               AquaOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Circle:
               CircleOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               CircleOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), (Float)this.PIOutline.getValue(), (Float)this.radOutline.getValue());
               CircleOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
               break;
            case Smoke:
               SmokeOutlineShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersOutline(renderGameOverlayEvent.getPartialTicks());
               SmokeOutlineShader.INSTANCE.stopDraw(color2, (Float)this.radius.getValue(), (Float)this.quality.getValue(), false, (Integer)this.alphaValue.getValue(), (Float)this.duplicateOutline.getValue(), color3, color4, (Integer)this.NUM_OCTAVESOutline.getValue());
               SmokeOutlineShader.INSTANCE.update((double)((Float)this.speedOutline.getValue() / 1000.0F));
            }

            switch((Shaders.fillShadermode)this.fillShader.getValue()) {
            case Astral:
               FlowShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               FlowShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), ((Integer)this.redFill.getValue()).floatValue(), (Float)this.greenFill.getValue(), (Float)this.blueFill.getValue(), (Float)this.alphaFill.getValue(), (Integer)this.iterationsFill.getValue(), (Float)this.formuparam2Fill.getValue(), (Float)this.zoomFill.getValue(), (Float)this.volumStepsFill.getValue(), (Float)this.stepSizeFill.getValue(), (Float)this.titleFill.getValue(), (Float)this.distfadingFill.getValue(), (Float)this.saturationFill.getValue(), 0.0F, (Boolean)this.fadeFill.getValue() ? 1 : 0);
               FlowShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Aqua:
               AquaShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               AquaShader.INSTANCE.stopDraw(color, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), (Integer)this.MaxIterFill.getValue(), (double)(Float)this.tauFill.getValue());
               AquaShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Smoke:
               SmokeShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               SmokeShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), color, color3, color5, (Integer)this.NUM_OCTAVESFill.getValue());
               SmokeShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case RainbowCube:
               RainbowCubeShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               RainbowCubeShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), color, (Integer)this.WaveLenghtFIll.getValue(), (Integer)this.RSTARTFill.getValue(), (Integer)this.GSTARTFill.getValue(), (Integer)this.BSTARTFIll.getValue());
               RainbowCubeShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Gradient:
               GradientShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               GradientShader.INSTANCE.stopDraw(color2, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), (Float)this.moreGradientFill.getValue(), (Float)this.creepyFill.getValue(), (Float)this.alphaFill.getValue(), (Integer)this.NUM_OCTAVESFill.getValue());
               GradientShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Fill:
               FillShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               FillShader.INSTANCE.stopDraw(color);
               FillShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Circle:
               CircleShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               CircleShader.INSTANCE.stopDraw((Float)this.duplicateFill.getValue(), color, (Float)this.PI.getValue(), (Float)this.rad.getValue());
               CircleShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
               break;
            case Phobos:
               PhobosShader.INSTANCE.startDraw(renderGameOverlayEvent.getPartialTicks());
               this.renderPlayersFill(renderGameOverlayEvent.getPartialTicks());
               PhobosShader.INSTANCE.stopDraw(color, 1.0F, 1.0F, (Float)this.duplicateFill.getValue(), (Integer)this.MaxIterFill.getValue(), (double)(Float)this.tauFill.getValue());
               PhobosShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
            }
         }

         this.renderTags = true;
         this.renderCape = true;
         GlStateManager.func_179121_F();
      }

   }

   void renderPlayersFill(float f) {
      boolean bl = (Boolean)this.rangeCheck.getValue();
      double d = (double)((Float)this.minRange.getValue() * (Float)this.minRange.getValue());
      double d2 = (double)((Float)this.maxRange.getValue() * (Float)this.maxRange.getValue());
      AtomicInteger atomicInteger = new AtomicInteger();
      int n = (Integer)this.maxEntities.getValue();

      try {
         mc.field_71441_e.field_72996_f.stream().filter((entity) -> {
            if (atomicInteger.getAndIncrement() > n) {
               return false;
            } else {
               return entity instanceof EntityPlayer ? (this.player.getValue() == Shaders.Player1.Fill || this.player.getValue() == Shaders.Player1.Both) && (entity != mc.field_71439_g || mc.field_71474_y.field_74320_O != 0) : (entity instanceof EntityEnderPearl ? this.enderPearl.getValue() == Shaders.EPl.Fill || this.enderPearl.getValue() == Shaders.EPl.Both : (entity instanceof EntityExpBottle ? this.xpBottle.getValue() == Shaders.XPBl.Fill || this.xpBottle.getValue() == Shaders.XPBl.Both : (entity instanceof EntityXPOrb ? this.xpOrb.getValue() == Shaders.XPl.Fill || this.xpOrb.getValue() == Shaders.XPl.Both : (entity instanceof EntityItem ? this.items.getValue() == Shaders.Itemsl.Fill || this.items.getValue() == Shaders.Itemsl.Both : (entity instanceof EntityCreature ? this.mob.getValue() == Shaders.Mob1.Fill || this.mob.getValue() == Shaders.Mob1.Both : entity instanceof EntityEnderCrystal && (this.crystal.getValue() == Shaders.Crystal1.Fill || this.crystal.getValue() == Shaders.Crystal1.Both))))));
            }
         }).filter((entity) -> {
            if (!bl) {
               return true;
            } else {
               double d3 = mc.field_71439_g.func_70068_e(entity);
               return d3 > d && d3 < d2;
            }
         }).forEach((entity) -> {
            Util.mc.func_175598_ae().func_188388_a(entity, f, true);
         });
      } catch (Exception var10) {
      }

   }

   void renderPlayersOutline(float f) {
      boolean bl = (Boolean)this.rangeCheck.getValue();
      double d = (double)((Float)this.minRange.getValue() * (Float)this.minRange.getValue());
      double d2 = (double)((Float)this.maxRange.getValue() * (Float)this.maxRange.getValue());
      AtomicInteger atomicInteger = new AtomicInteger();
      int n = (Integer)this.maxEntities.getValue();
      mc.field_71441_e.func_73027_a(-1000, new EntityXPOrb(mc.field_71441_e, mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1000000.0D, mc.field_71439_g.field_70161_v, 1));
      mc.field_71441_e.field_72996_f.stream().filter((entity) -> {
         if (atomicInteger.getAndIncrement() > n) {
            return false;
         } else {
            return entity instanceof EntityPlayer ? (this.player.getValue() == Shaders.Player1.Outline || this.player.getValue() == Shaders.Player1.Both) && (entity != mc.field_71439_g || mc.field_71474_y.field_74320_O != 0) : (entity instanceof EntityEnderPearl ? this.enderPearl.getValue() == Shaders.EPl.Outline || this.enderPearl.getValue() == Shaders.EPl.Both : (entity instanceof EntityExpBottle ? this.xpBottle.getValue() == Shaders.XPBl.Outline || this.xpBottle.getValue() == Shaders.XPBl.Both : (entity instanceof EntityXPOrb ? this.xpOrb.getValue() == Shaders.XPl.Outline || this.xpOrb.getValue() == Shaders.XPl.Both : (entity instanceof EntityItem ? this.items.getValue() == Shaders.Itemsl.Outline || this.items.getValue() == Shaders.Itemsl.Both : (entity instanceof EntityCreature ? this.mob.getValue() == Shaders.Mob1.Outline || this.mob.getValue() == Shaders.Mob1.Both : entity instanceof EntityEnderCrystal && (this.crystal.getValue() == Shaders.Crystal1.Outline || this.crystal.getValue() == Shaders.Crystal1.Both))))));
         }
      }).filter((entity) -> {
         if (!bl) {
            return true;
         } else {
            double d3 = mc.field_71439_g.func_70068_e(entity);
            return d3 > d && d3 < d2 || entity.func_145782_y() == -1000;
         }
      }).forEach((entity) -> {
         Util.mc.func_175598_ae().func_188388_a(entity, f, true);
      });
      mc.field_71441_e.func_73028_b(-1000);
   }

   public void onTick() {
      if ((Boolean)this.Fpreset.getValue()) {
         this.fillShader.setValue(Shaders.fillShadermode.None);
         this.glowESP.setValue(Shaders.glowESPmode.Gradient);
         this.player.setValue(Shaders.Player1.Outline);
         this.crystal.setValue(Shaders.Crystal1.Outline);
         this.duplicateOutline.setValue(2.0F);
         this.speedOutline.setValue(30.0F);
         this.quality.setValue(0.6F);
         this.radius.setValue(1.7F);
         this.creepyOutline.setValue(1.0F);
         this.moreGradientOutline.setValue(1.0F);
         this.Fpreset.setValue(false);
      }

      if ((Boolean)this.default1.getValue()) {
         this.fillShader.setValue(Shaders.fillShadermode.None);
         this.glowESP.setValue(Shaders.glowESPmode.None);
         this.rangeCheck.setValue(true);
         this.maxRange.setValue(35.0F);
         this.minRange.setValue(0.0F);
         this.crystal.setValue(Shaders.Crystal1.None);
         this.player.setValue(Shaders.Player1.None);
         this.mob.setValue(Shaders.Mob1.None);
         this.items.setValue(Shaders.Itemsl.None);
         this.fadeFill.setValue(false);
         this.fadeOutline.setValue(false);
         this.duplicateOutline.setValue(1.0F);
         this.duplicateFill.setValue(1.0F);
         this.speedOutline.setValue(10.0F);
         this.speedFill.setValue(10.0F);
         this.quality.setValue(1.0F);
         this.radius.setValue(1.0F);
         this.rad.setValue(0.75F);
         this.PI.setValue(3.1415927F);
         this.saturationFill.setValue(0.4F);
         this.distfadingFill.setValue(0.56F);
         this.titleFill.setValue(0.45F);
         this.stepSizeFill.setValue(0.2F);
         this.volumStepsFill.setValue(10.0F);
         this.zoomFill.setValue(3.9F);
         this.formuparam2Fill.setValue(0.89F);
         this.saturationOutline.setValue(0.4F);
         this.maxEntities.setValue(100);
         this.iterationsFill.setValue(4);
         this.redFill.setValue(0);
         this.MaxIterFill.setValue(5);
         this.NUM_OCTAVESFill.setValue(5);
         this.BSTARTFIll.setValue(0);
         this.GSTARTFill.setValue(0);
         this.RSTARTFill.setValue(0);
         this.WaveLenghtFIll.setValue(555);
         this.volumStepsOutline.setValue(10);
         this.iterationsOutline.setValue(4);
         this.MaxIterOutline.setValue(5);
         this.NUM_OCTAVESOutline.setValue(5);
         this.BSTARTOutline.setValue(0);
         this.GSTARTOutline.setValue(0);
         this.RSTARTOutline.setValue(0);
         this.alphaValue.setValue(255);
         this.WaveLenghtOutline.setValue(555);
         this.redOutline.setValue(0);
         this.alphaFill.setValue(1.0F);
         this.blueFill.setValue(0.0F);
         this.greenFill.setValue(0.0F);
         this.tauFill.setValue(6.2831855F);
         this.creepyFill.setValue(1.0F);
         this.moreGradientFill.setValue(1.0F);
         this.distfadingOutline.setValue(0.56F);
         this.titleOutline.setValue(0.45F);
         this.stepSizeOutline.setValue(0.19F);
         this.zoomOutline.setValue(3.9F);
         this.formuparam2Outline.setValue(0.89F);
         this.alphaOutline.setValue(1.0F);
         this.blueOutline.setValue(0.0F);
         this.greenOutline.setValue(0.0F);
         this.tauOutline.setValue(0.0F);
         this.creepyOutline.setValue(1.0F);
         this.moreGradientOutline.setValue(1.0F);
         this.radOutline.setValue(0.75F);
         this.PIOutline.setValue(3.1415927F);
         this.default1.setValue(false);
      }

   }

   Predicate<Boolean> getFill() {
      Color color = new Color((Integer)this.colorImgFillred.getValue(), (Integer)this.colorImgFillgreen.getValue(), (Integer)this.colorImgFillblue.getValue(), (Integer)this.colorImgFillalpha.getValue());
      new Color((Integer)this.colorESPred.getValue(), (Integer)this.colorESPgreen.getValue(), (Integer)this.colorESPblue.getValue(), (Integer)this.colorESPalpha.getValue());
      Color color3 = new Color((Integer)this.secondColorImgFillred.getValue(), (Integer)this.secondColorImgFillgreen.getValue(), (Integer)this.secondColorImgFillblue.getValue(), (Integer)this.secondColorImgFillalpha.getValue());
      new Color((Integer)this.thirdColorImgOutlinered.getValue(), (Integer)this.thirdColorImgOutlinegreen.getValue(), (Integer)this.thirdColorImgOutlineblue.getValue(), (Integer)this.thirdColorImgOutlinealpha.getValue());
      Color color5 = new Color((Integer)this.thirdColorImgFIllred.getValue(), (Integer)this.thirdColorImgFIllgreen.getValue(), (Integer)this.thirdColorImgFIllblue.getValue(), (Integer)this.thirdColorImgFIllalpha.getValue());
      new Color((Integer)this.colorImgOutlinered.getValue(), (Integer)this.colorImgOutlinegreen.getValue(), (Integer)this.colorImgOutlineblue.getValue(), (Integer)this.colorImgOutlinealpha.getValue());
      Predicate<Boolean> predicate = (bl) -> {
         return true;
      };
      switch((Shaders.fillShadermode)this.fillShader.getValue()) {
      case Astral:
         predicate = (bl) -> {
            FlowShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), ((Integer)this.redFill.getValue()).floatValue(), (Float)this.greenFill.getValue(), (Float)this.blueFill.getValue(), (Float)this.alphaFill.getValue(), (Integer)this.iterationsFill.getValue(), (Float)this.formuparam2Fill.getValue(), (Float)this.zoomFill.getValue(), (Float)this.volumStepsFill.getValue(), (Float)this.stepSizeFill.getValue(), (Float)this.titleFill.getValue(), (Float)this.distfadingFill.getValue(), (Float)this.saturationFill.getValue(), 0.0F, (Boolean)this.fadeFill.getValue() ? 1 : 0);
            return true;
         };
         FlowShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case Aqua:
         predicate = (bl) -> {
            AquaShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), color, (Integer)this.MaxIterFill.getValue(), (double)(Float)this.tauFill.getValue());
            return true;
         };
         AquaShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case Smoke:
         predicate = (bl) -> {
            SmokeShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), color, color3, color5, (Integer)this.NUM_OCTAVESFill.getValue());
            return true;
         };
         SmokeShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case RainbowCube:
         predicate = (bl) -> {
            RainbowCubeShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), color, (Integer)this.WaveLenghtFIll.getValue(), (Integer)this.RSTARTFill.getValue(), (Integer)this.GSTARTFill.getValue(), (Integer)this.BSTARTFIll.getValue());
            return true;
         };
         RainbowCubeShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case Gradient:
         predicate = (bl) -> {
            GradientShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), (Float)this.moreGradientFill.getValue(), (Float)this.creepyFill.getValue(), (Float)this.alphaFill.getValue(), (Integer)this.NUM_OCTAVESFill.getValue());
            return true;
         };
         GradientShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case Fill:
         Color color7 = new Color((Integer)this.colorImgFillred.getValue(), (Integer)this.colorImgFillgreen.getValue(), (Integer)this.colorImgFillblue.getValue(), (Integer)this.colorImgFillalpha.getValue());
         predicate = (bl) -> {
            FillShader.INSTANCE.startShader((float)color7.getRed() / 255.0F, (float)color7.getGreen() / 255.0F, (float)color7.getBlue() / 255.0F, (float)color7.getAlpha() / 255.0F);
            return false;
         };
         FillShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case Circle:
         predicate = (bl) -> {
            CircleShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), color, (Float)this.PI.getValue(), (Float)this.rad.getValue());
            return true;
         };
         CircleShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
         break;
      case Phobos:
         predicate = (bl) -> {
            PhobosShader.INSTANCE.startShader((Float)this.duplicateFill.getValue(), color, (Integer)this.MaxIterFill.getValue(), (double)(Float)this.tauFill.getValue());
            return true;
         };
         PhobosShader.INSTANCE.update((double)((Float)this.speedFill.getValue() / 1000.0F));
      }

      return predicate;
   }

   public static enum glowESPmode {
      None,
      Color,
      Astral,
      RainbowCube,
      Gradient,
      Circle,
      Smoke,
      Aqua;
   }

   public static enum EPl {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum Itemsl {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum Mob1 {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum XPBl {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum XPl {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum Crystal1 {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum Player1 {
      None,
      Fill,
      Outline,
      Both;
   }

   public static enum fillShadermode {
      Astral,
      Aqua,
      Smoke,
      RainbowCube,
      Gradient,
      Fill,
      Circle,
      Phobos,
      None;
   }
}
