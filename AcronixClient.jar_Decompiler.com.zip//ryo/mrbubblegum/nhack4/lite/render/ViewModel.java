package ryo.mrbubblegum.nhack4.lite.render;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.system.setting.Setting;
import ryo.mrbubblegum.nhack4.world.events.RenderItemEvent;

public class ViewModel extends Module {
   private static ViewModel INSTANCE = new ViewModel();
   public Setting<ViewModel.Settings> settings;
   public Setting<Boolean> noEatAnimation;
   public Setting<Double> eatX;
   public Setting<Double> eatY;
   public Setting<Boolean> doBob;
   public Setting<Double> mainX;
   public Setting<Double> mainY;
   public Setting<Double> mainZ;
   public Setting<Double> offX;
   public Setting<Double> offY;
   public Setting<Double> offZ;
   public Setting<Integer> mainRotX;
   public Setting<Integer> mainRotY;
   public Setting<Integer> mainRotZ;
   public Setting<Integer> offRotX;
   public Setting<Integer> offRotY;
   public Setting<Integer> offRotZ;
   public Setting<Double> mainScaleX;
   public Setting<Double> mainScaleY;
   public Setting<Double> mainScaleZ;
   public Setting<Double> offScaleX;
   public Setting<Double> offScaleY;
   public Setting<Double> offScaleZ;
   public Setting<Boolean> rotatexo;
   public Setting<Boolean> rotateyo;
   public Setting<Boolean> rotatezo;
   public Setting<Boolean> rotatex;
   public Setting<Boolean> rotatey;
   public Setting<Boolean> rotatez;
   public Setting<Integer> animDelay;
   public Timer timer;
   int rotation;

   public ViewModel() {
      super("ViewModel", "Cool", Module.Category.RENDER, true, false, false);
      this.settings = this.register(new Setting("Settings", ViewModel.Settings.TRANSLATE));
      this.noEatAnimation = this.register(new Setting("NoEatAnimation", false, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TWEAKS;
      }));
      this.eatX = this.register(new Setting("EatX", 1.0D, -2.0D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TWEAKS && !(Boolean)this.noEatAnimation.getValue();
      }));
      this.eatY = this.register(new Setting("EatY", 1.0D, -2.0D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TWEAKS && !(Boolean)this.noEatAnimation.getValue();
      }));
      this.doBob = this.register(new Setting("ItemBob", true, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TWEAKS;
      }));
      this.mainX = this.register(new Setting("MainX", 0.0D, -2.0D, 4.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TRANSLATE;
      }));
      this.mainY = this.register(new Setting("MainY", -0.0D, -3.0D, 3.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TRANSLATE;
      }));
      this.mainZ = this.register(new Setting("MainZ", -0.0D, -5.0D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TRANSLATE;
      }));
      this.offX = this.register(new Setting("OffX", 0.0D, -2.0D, 4.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TRANSLATE;
      }));
      this.offY = this.register(new Setting("OffY", -0.0D, -3.0D, 3.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TRANSLATE;
      }));
      this.offZ = this.register(new Setting("OffZ", -0.0D, -5.0D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.TRANSLATE;
      }));
      this.mainRotX = this.register(new Setting("MainRotationX", 0, -36, 36, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.ROTATE;
      }));
      this.mainRotY = this.register(new Setting("MainRotationY", 0, -36, 36, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.ROTATE;
      }));
      this.mainRotZ = this.register(new Setting("MainRotationZ", 0, -36, 36, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.ROTATE;
      }));
      this.offRotX = this.register(new Setting("OffRotationX", 0, -36, 36, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.ROTATE;
      }));
      this.offRotY = this.register(new Setting("OffRotationY", 0, -36, 36, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.ROTATE;
      }));
      this.offRotZ = this.register(new Setting("OffRotationZ", 0, -36, 36, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.ROTATE;
      }));
      this.mainScaleX = this.register(new Setting("MainScaleX", 1.0D, 0.1D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.SCALE;
      }));
      this.mainScaleY = this.register(new Setting("MainScaleY", 1.0D, 0.1D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.SCALE;
      }));
      this.mainScaleZ = this.register(new Setting("MainScaleZ", 1.0D, 0.1D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.SCALE;
      }));
      this.offScaleX = this.register(new Setting("OffScaleX", 1.0D, 0.1D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.SCALE;
      }));
      this.offScaleY = this.register(new Setting("OffScaleY", 1.0D, 0.1D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.SCALE;
      }));
      this.offScaleZ = this.register(new Setting("OffScaleZ", 1.0D, 0.1D, 5.0D, (v) -> {
         return this.settings.getValue() == ViewModel.Settings.SCALE;
      }));
      this.rotatexo = this.register(new Setting("RotateX", false));
      this.rotateyo = this.register(new Setting("RotateY", false));
      this.rotatezo = this.register(new Setting("RotateZ", false));
      this.rotatex = this.register(new Setting("RotateXOff", false));
      this.rotatey = this.register(new Setting("RotateYOff", false));
      this.rotatez = this.register(new Setting("RotateZOff", false));
      this.animDelay = this.register(new Setting("RotateSpeed", 500, 1, 1500, (v) -> {
         return (Boolean)this.rotatex.getValue() || (Boolean)this.rotatey.getValue() || (Boolean)this.rotatez.getValue() || (Boolean)this.rotatexo.getValue() || (Boolean)this.rotateyo.getValue() || (Boolean)this.rotatezo.getValue();
      }));
      this.timer = new Timer();
      this.rotation = -180;
      this.setInstance();
   }

   public static ViewModel getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new ViewModel();
      }

      return INSTANCE;
   }

   private void setInstance() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onItemRender(RenderItemEvent event) {
      event.setMainX((Double)this.mainX.getValue());
      event.setMainY((Double)this.mainY.getValue());
      event.setMainZ((Double)this.mainZ.getValue());
      event.setOffX(-(Double)this.offX.getValue());
      event.setOffY((Double)this.offY.getValue());
      event.setOffZ((Double)this.offZ.getValue());
      event.setMainRotX((double)((Integer)this.mainRotX.getValue() * 5));
      event.setMainRotY((double)((Integer)this.mainRotY.getValue() * 5));
      event.setMainRotZ((double)((Integer)this.mainRotZ.getValue() * 5));
      event.setOffRotX((double)((Integer)this.offRotX.getValue() * 5));
      event.setOffRotY((double)((Integer)this.offRotY.getValue() * 5));
      event.setOffRotZ((double)((Integer)this.offRotZ.getValue() * 5));
      event.setOffHandScaleX((Double)this.offScaleX.getValue());
      event.setOffHandScaleY((Double)this.offScaleY.getValue());
      event.setOffHandScaleZ((Double)this.offScaleZ.getValue());
      event.setMainHandScaleX((Double)this.mainScaleX.getValue());
      event.setMainHandScaleY((Double)this.mainScaleY.getValue());
      event.setMainHandScaleZ((Double)this.mainScaleZ.getValue());
      if (this.timer.passedMs((long)(1000 / (Integer)this.animDelay.getValue()))) {
         ++this.rotation;
         if (this.rotation > 180) {
            this.rotation = -180;
         }

         this.timer.reset();
      }

      if (!(Boolean)this.rotatex.getValue()) {
         event.setOffRotX((double)((Integer)this.offRotX.getValue() * 5));
      } else {
         event.setOffRotX((double)this.rotation);
      }

      if (!(Boolean)this.rotatey.getValue()) {
         event.setOffRotY((double)((Integer)this.offRotY.getValue() * 5));
      } else {
         event.setOffRotY((double)this.rotation);
      }

      if (!(Boolean)this.rotatez.getValue()) {
         event.setOffRotZ((double)((Integer)this.offRotZ.getValue() * 5));
      } else {
         event.setOffRotZ((double)this.rotation);
      }

      if (!(Boolean)this.rotatexo.getValue()) {
         event.setMainRotX((double)((Integer)this.offRotX.getValue() * 5));
      } else {
         event.setMainRotX((double)this.rotation);
      }

      if (!(Boolean)this.rotateyo.getValue()) {
         event.setMainRotY((double)((Integer)this.offRotY.getValue() * 5));
      } else {
         event.setMainRotY((double)this.rotation);
      }

      if (!(Boolean)this.rotatezo.getValue()) {
         event.setMainRotZ((double)((Integer)this.offRotZ.getValue() * 5));
      } else {
         event.setMainRotZ((double)this.rotation);
      }

   }

   private static enum Settings {
      TRANSLATE,
      ROTATE,
      SCALE,
      TWEAKS;
   }
}
