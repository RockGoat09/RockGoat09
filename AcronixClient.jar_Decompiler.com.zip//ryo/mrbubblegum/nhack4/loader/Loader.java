package ryo.mrbubblegum.nhack4.loader;

import java.io.InputStream;
import java.nio.ByteBuffer;
import me.zero.alpine.bus.EventBus;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;
import net.minecraft.util.Util.EnumOS;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;
import ryo.mrbubblegum.nhack4.impl.manager.ColorManager;
import ryo.mrbubblegum.nhack4.impl.manager.CommandManager;
import ryo.mrbubblegum.nhack4.impl.manager.ConfigManager;
import ryo.mrbubblegum.nhack4.impl.manager.EventManager;
import ryo.mrbubblegum.nhack4.impl.manager.FileManager;
import ryo.mrbubblegum.nhack4.impl.manager.FriendManager;
import ryo.mrbubblegum.nhack4.impl.manager.HoleManager;
import ryo.mrbubblegum.nhack4.impl.manager.InventoryManager;
import ryo.mrbubblegum.nhack4.impl.manager.ModuleManager;
import ryo.mrbubblegum.nhack4.impl.manager.MovementManager;
import ryo.mrbubblegum.nhack4.impl.manager.NoStopManager;
import ryo.mrbubblegum.nhack4.impl.manager.NotificationManager;
import ryo.mrbubblegum.nhack4.impl.manager.PacketManager;
import ryo.mrbubblegum.nhack4.impl.manager.PositionManager;
import ryo.mrbubblegum.nhack4.impl.manager.PotionManager;
import ryo.mrbubblegum.nhack4.impl.manager.ReloadManager;
import ryo.mrbubblegum.nhack4.impl.manager.RotationManager;
import ryo.mrbubblegum.nhack4.impl.manager.SafetyManager;
import ryo.mrbubblegum.nhack4.impl.manager.ServerManager;
import ryo.mrbubblegum.nhack4.impl.manager.SpeedManager;
import ryo.mrbubblegum.nhack4.impl.manager.TextManager;
import ryo.mrbubblegum.nhack4.impl.manager.TimerManager;
import ryo.mrbubblegum.nhack4.impl.manager.TotemPopManager;
import ryo.mrbubblegum.nhack4.impl.util.DiscordUtil;
import ryo.mrbubblegum.nhack4.impl.util.IconUtil;
import ryo.mrbubblegum.nhack4.lite.client.RPC;

@Mod(
   modid = "nhack4",
   name = "NHACK4",
   version = "0.1.0"
)
public class Loader {
   public static final String MODID = "nhack4";
   public static final String MODNAME = "NHACK4";
   public static final String MODVER = "0.1.0";
   public static final Logger LOGGER = LogManager.getLogger("Loader");
   public static EventBus dispatcher;
   public static ModuleManager moduleManager;
   public static MovementManager movementManager;
   public static SpeedManager speedManager;
   public static PositionManager positionManager;
   public static RotationManager rotationManager;
   public static CommandManager commandManager;
   public static EventManager eventManager;
   public static ConfigManager configManager;
   public static FileManager fileManager;
   public static FriendManager friendManager;
   public static TextManager textManager;
   public static ColorManager colorManager;
   public static ServerManager serverManager;
   public static PotionManager potionManager;
   public static InventoryManager inventoryManager;
   public static TimerManager timerManager;
   public static PacketManager packetManager;
   public static ReloadManager reloadManager;
   public static TotemPopManager totemPopManager;
   public static HoleManager holeManager;
   public static NotificationManager notificationManager;
   public static SafetyManager safetyManager;
   public static NoStopManager baritoneManager;
   @Instance
   public static Loader INSTANCE;
   private static boolean unloaded = false;

   public static void load() {
      LOGGER.info("\n\nLoading Loader");
      unloaded = false;
      if (reloadManager != null) {
         reloadManager.unload();
         reloadManager = null;
      }

      dispatcher = new me.zero.alpine.bus.EventManager();
      baritoneManager = new NoStopManager();
      totemPopManager = new TotemPopManager();
      timerManager = new TimerManager();
      packetManager = new PacketManager();
      serverManager = new ServerManager();
      colorManager = new ColorManager();
      textManager = new TextManager();
      moduleManager = new ModuleManager();
      movementManager = new MovementManager();
      speedManager = new SpeedManager();
      rotationManager = new RotationManager();
      positionManager = new PositionManager();
      commandManager = new CommandManager();
      eventManager = new EventManager();
      configManager = new ConfigManager();
      fileManager = new FileManager();
      friendManager = new FriendManager();
      potionManager = new PotionManager();
      inventoryManager = new InventoryManager();
      holeManager = new HoleManager();
      notificationManager = new NotificationManager();
      safetyManager = new SafetyManager();
      LOGGER.info("Initialized Managers");
      moduleManager.init();
      LOGGER.info("Modules loaded.");
      configManager.init();
      eventManager.init();
      LOGGER.info("EventManager loaded.");
      textManager.init(true);
      moduleManager.onLoad();
      totemPopManager.init();
      timerManager.init();
      if (((RPC)moduleManager.getModuleByClass(RPC.class)).isEnabled()) {
         DiscordUtil.start();
      }

      LOGGER.info("Loader initialized!\n");
   }

   public static void unload(boolean unload) {
      LOGGER.info("\n\nUnloading Loader");
      if (unload) {
         reloadManager = new ReloadManager();
         reloadManager.init(commandManager != null ? commandManager.getPrefix() : ".");
      }

      if (baritoneManager != null) {
         baritoneManager.stop();
      }

      onUnload();
      dispatcher = null;
      eventManager = null;
      holeManager = null;
      timerManager = null;
      moduleManager = null;
      movementManager = null;
      totemPopManager = null;
      serverManager = null;
      colorManager = null;
      textManager = null;
      speedManager = null;
      rotationManager = null;
      positionManager = null;
      commandManager = null;
      configManager = null;
      fileManager = null;
      friendManager = null;
      potionManager = null;
      inventoryManager = null;
      notificationManager = null;
      safetyManager = null;
      LOGGER.info("nhack4 unloaded!\n");
   }

   public static void reload() {
      unload(false);
      load();
   }

   public static void onUnload() {
      if (!unloaded) {
         eventManager.onUnload();
         moduleManager.onUnload();
         configManager.saveConfig(configManager.config.replaceFirst("nhack4/", ""));
         moduleManager.onUnloadPost();
         timerManager.unload();
         unloaded = true;
      }

   }

   public static void setWindowIcon() {
      if (Util.func_110647_a() != EnumOS.OSX) {
         try {
            InputStream inputStream16x = Minecraft.class.getResourceAsStream("/assets/minecraft/textures/icons/icon-16x.png");
            Throwable var1 = null;

            try {
               InputStream inputStream32x = Minecraft.class.getResourceAsStream("/assets/minecraft/textures/icons/icon-32x.png");
               Throwable var3 = null;

               try {
                  ByteBuffer[] icons = new ByteBuffer[]{IconUtil.INSTANCE.readImageToBuffer(inputStream16x), IconUtil.INSTANCE.readImageToBuffer(inputStream32x)};
                  Display.setIcon(icons);
               } catch (Throwable var28) {
                  var3 = var28;
                  throw var28;
               } finally {
                  if (inputStream32x != null) {
                     if (var3 != null) {
                        try {
                           inputStream32x.close();
                        } catch (Throwable var27) {
                           var3.addSuppressed(var27);
                        }
                     } else {
                        inputStream32x.close();
                     }
                  }

               }
            } catch (Throwable var30) {
               var1 = var30;
               throw var30;
            } finally {
               if (inputStream16x != null) {
                  if (var1 != null) {
                     try {
                        inputStream16x.close();
                     } catch (Throwable var26) {
                        var1.addSuppressed(var26);
                     }
                  } else {
                     inputStream16x.close();
                  }
               }

            }
         } catch (Exception var32) {
            LOGGER.error("Couldn't set Windows Icon", var32);
         }
      }

   }

   private void setWindowsIcon() {
      setWindowIcon();
   }

   @EventHandler
   public void init(FMLInitializationEvent event) {
      Minecraft mc = Minecraft.func_71410_x();
      Display.setTitle("Username: " + mc.func_110432_I().func_111285_a());
      this.setWindowsIcon();
      load();
   }
}
