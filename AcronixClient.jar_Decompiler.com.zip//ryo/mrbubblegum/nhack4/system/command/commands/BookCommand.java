package ryo.mrbubblegum.nhack4.system.command.commands;

import io.netty.buffer.Unpooled;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class BookCommand extends Command {
   public BookCommand() {
      super("book", new String[0]);
   }

   public void execute(String[] commands) {
      ItemStack heldItem = mc.field_71439_g.func_184614_ca();
      if (heldItem.func_77973_b() == Items.field_151099_bA) {
         int limit = true;
         Random rand = new Random();
         IntStream characterGenerator = rand.ints(128, 1112063).map((i) -> {
            return i < 55296 ? i : i + 2048;
         });
         String joinedPages = (String)characterGenerator.limit(10500L).mapToObj((i) -> {
            return String.valueOf((char)i);
         }).collect(Collectors.joining());
         NBTTagList pages = new NBTTagList();

         for(int page = 0; page < 50; ++page) {
            pages.func_74742_a(new NBTTagString(joinedPages.substring(page * 210, (page + 1) * 210)));
         }

         if (heldItem.func_77942_o()) {
            heldItem.func_77978_p().func_74782_a("pages", pages);
         } else {
            heldItem.func_77983_a("pages", pages);
         }

         StringBuilder stackName = new StringBuilder();

         for(int i2 = 0; i2 < 16; ++i2) {
            stackName.append("\u0014\f");
         }

         heldItem.func_77983_a("author", new NBTTagString(mc.field_71439_g.func_70005_c_()));
         heldItem.func_77983_a("title", new NBTTagString(stackName.toString()));
         PacketBuffer buf = new PacketBuffer(Unpooled.buffer());
         buf.func_150788_a(heldItem);
         mc.field_71439_g.field_71174_a.func_147297_a(new CPacketCustomPayload("MC|BSign", buf));
         sendMessage(Loader.commandManager.getPrefix() + "Book Hack Success!");
      } else {
         sendMessage(Loader.commandManager.getPrefix() + "b1g 3rr0r!");
      }

   }
}
