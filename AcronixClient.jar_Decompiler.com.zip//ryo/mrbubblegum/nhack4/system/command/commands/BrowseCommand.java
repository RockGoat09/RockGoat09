package ryo.mrbubblegum.nhack4.system.command.commands;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class BrowseCommand extends Command {
   Desktop desktop = Desktop.getDesktop();

   public BrowseCommand() {
      super("browse", new String[]{"text"});
   }

   public void execute(String[] commands) {
      try {
         this.desktop.browse(new URI("https://www.google.com/search?q=" + URLEncoder.encode(commands[0]) + "&sxsrf=APq-WBs6H06yXya-qlggIMTKxjRwW7jvOA%3A1650656158846&ei=ngNjYo2nM4b_rgStiaO4BA&oq=sxsrf&gs_lcp=Cgdnd3Mtd2l6EAMYATIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBggAEAoQHjIGCAAQBRAeSgQIQRgASgQIRhgAUABYAGCmDWgAcAF4AIABVogBVpIBATGYAQCgAQKgAQHAAQE&sclient=gws-wiz"));
      } catch (IOException var3) {
         var3.printStackTrace();
      } catch (URISyntaxException var4) {
         var4.printStackTrace();
      }

   }
}
