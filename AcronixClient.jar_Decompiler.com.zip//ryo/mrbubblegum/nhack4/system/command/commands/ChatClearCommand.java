package ryo.mrbubblegum.nhack4.system.command.commands;

import ryo.mrbubblegum.nhack4.system.command.Command;

public class ChatClearCommand extends Command {
   public ChatClearCommand() {
      super("chatclear", new String[0]);
   }

   public void execute(String[] commands) {
      mc.field_71456_v.func_146158_b().func_146231_a(true);
   }
}
