package ryo.mrbubblegum.nhack4.system.command.commands;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.text.DecimalFormat;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class CoordsCommand extends Command {
   public CoordsCommand() {
      super("coords", new String[0]);
   }

   public void execute(String[] commands) {
      DecimalFormat format = new DecimalFormat("#");
      StringSelection contents = new StringSelection(format.format(mc.field_71439_g.field_70165_t) + ", " + format.format(mc.field_71439_g.field_70163_u) + ", " + format.format(mc.field_71439_g.field_70161_v));
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      clipboard.setContents(contents, (ClipboardOwner)null);
      Command.sendMessage("Saved Coordinates To Clipboard.", false);
   }
}
