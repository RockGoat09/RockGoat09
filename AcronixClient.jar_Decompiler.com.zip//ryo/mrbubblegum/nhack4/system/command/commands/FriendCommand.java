package ryo.mrbubblegum.nhack4.system.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Iterator;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.network.play.client.CPacketChatMessage;
import ryo.mrbubblegum.nhack4.impl.util.Util;
import ryo.mrbubblegum.nhack4.lite.client.FriendSettings;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class FriendCommand extends Command {
   public FriendCommand() {
      super("friend", new String[]{"<add/del/name/clear>", "<name>"});
   }

   public void execute(String[] commands) {
      if (commands.length != 1) {
         if (commands.length == 2) {
            if (commands[0].equals("reset")) {
               Loader.friendManager.onLoad();
               sendMessage("Friends got reset.");
            } else {
               sendMessage(commands[0] + (Loader.friendManager.isFriend(commands[0]) ? " is friended." : " isn't friended."));
            }
         } else {
            if (commands.length >= 2) {
               String var4 = commands[0];
               byte var5 = -1;
               switch(var4.hashCode()) {
               case 96417:
                  if (var4.equals("add")) {
                     var5 = 0;
                  }
                  break;
               case 99339:
                  if (var4.equals("del")) {
                     var5 = 1;
                  }
               }

               switch(var5) {
               case 0:
                  Loader.friendManager.addFriend(commands[1]);
                  sendMessage(ChatFormatting.GREEN + commands[1] + " has been friended");
                  if ((Boolean)FriendSettings.getInstance().notify.getValue()) {
                     Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("/w " + commands[1] + " I just added you to my friends list on Charlie dana hack!"));
                  }

                  return;
               case 1:
                  Loader.friendManager.removeFriend(commands[1]);
                  if ((Boolean)FriendSettings.getInstance().notify.getValue()) {
                     Util.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("/w " + commands[1] + " I just removed you from my friends list on Charlie dana hack!"));
                  }

                  sendMessage(ChatFormatting.RED + commands[1] + " has been unfriended");
                  return;
               default:
                  sendMessage("Unknown Command, try friend add/del (name)");
               }
            }

         }
      } else {
         if (Loader.friendManager.getFriends().isEmpty()) {
            sendMessage("You currently dont have any friends added.");
         } else {
            sendMessage("Friends: ");
            Iterator var2 = Loader.friendManager.getFriends().entrySet().iterator();

            while(var2.hasNext()) {
               Entry<String, UUID> entry = (Entry)var2.next();
               sendMessage((String)entry.getKey());
            }
         }

      }
   }
}
