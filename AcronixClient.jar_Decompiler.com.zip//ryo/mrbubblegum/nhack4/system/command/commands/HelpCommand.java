package ryo.mrbubblegum.nhack4.system.command.commands;

import java.util.Iterator;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class HelpCommand extends Command {
   public HelpCommand() {
      super("help");
   }

   public void execute(String[] commands) {
      sendMessage("You can use following commands: ");
      Iterator var2 = Loader.commandManager.getCommands().iterator();

      while(var2.hasNext()) {
         Command command = (Command)var2.next();
         sendMessage(Loader.commandManager.getPrefix() + command.getName());
      }

   }
}
