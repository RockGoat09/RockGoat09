package ryo.mrbubblegum.nhack4.system.command.commands;

import com.google.gson.JsonParser;
import java.util.Iterator;
import ryo.mrbubblegum.nhack4.impl.manager.ConfigManager;
import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;
import ryo.mrbubblegum.nhack4.system.setting.Setting;

public class ModuleCommand extends Command {
   public ModuleCommand() {
      super("module", new String[]{"<module>", "<set/reset>", "<setting>", "<value>"});
   }

   public void execute(String[] commands) {
      if (commands.length == 1) {
         sendMessage("Modules: ");
         Iterator var9 = Loader.moduleManager.getCategories().iterator();

         while(var9.hasNext()) {
            Module.Category category = (Module.Category)var9.next();
            String modules = category.getName() + ": ";

            Module module;
            for(Iterator var6 = Loader.moduleManager.getModulesByCategory(category).iterator(); var6.hasNext(); modules = modules + (module.isEnabled() ? "§a" : "§c") + module.getName() + "§r, ") {
               module = (Module)var6.next();
            }

            sendMessage(modules);
         }

      } else {
         Module module = Loader.moduleManager.getModuleByDisplayName(commands[0]);
         if (module == null) {
            module = Loader.moduleManager.getModuleByName(commands[0]);
            if (module == null) {
               sendMessage("§cThis module doesnt exist.");
            } else {
               sendMessage("§c This is the original name of the module. Its current name is: " + module.getDisplayName());
            }
         } else {
            Setting setting3;
            Iterator var10;
            if (commands.length == 2) {
               sendMessage(module.getDisplayName() + " : " + module.getDescription());
               var10 = module.getSettings().iterator();

               while(var10.hasNext()) {
                  setting3 = (Setting)var10.next();
                  sendMessage(setting3.getName() + " : " + setting3.getValue() + ", " + setting3.getDescription());
               }

            } else if (commands.length == 3) {
               if (commands[1].equalsIgnoreCase("set")) {
                  sendMessage("§cPlease specify a setting.");
               } else if (commands[1].equalsIgnoreCase("reset")) {
                  var10 = module.getSettings().iterator();

                  while(var10.hasNext()) {
                     setting3 = (Setting)var10.next();
                     setting3.setValue(setting3.getDefaultValue());
                  }
               } else {
                  sendMessage("§cThis command doesnt exist.");
               }

            } else if (commands.length == 4) {
               sendMessage("§cPlease specify a value.");
            } else {
               Setting setting;
               if (commands.length == 5 && (setting = module.getSettingByName(commands[2])) != null) {
                  JsonParser jp = new JsonParser();
                  if (setting.getType().equalsIgnoreCase("String")) {
                     setting.setValue(commands[3]);
                     sendMessage("§a" + module.getName() + " " + setting.getName() + " has been set to " + commands[3] + ".");
                     return;
                  }

                  try {
                     if (setting.getName().equalsIgnoreCase("Enabled")) {
                        if (commands[3].equalsIgnoreCase("true")) {
                           module.enable();
                        }

                        if (commands[3].equalsIgnoreCase("false")) {
                           module.disable();
                        }
                     }

                     ConfigManager.setValueFromJson(module, setting, jp.parse(commands[3]));
                  } catch (Exception var8) {
                     sendMessage("§cBad Value! This setting requires a: " + setting.getType() + " value.");
                     return;
                  }

                  sendMessage("§a" + module.getName() + " " + setting.getName() + " has been set to " + commands[3] + ".");
               }

            }
         }
      }
   }
}
