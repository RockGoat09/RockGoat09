package ryo.mrbubblegum.nhack4.system.command.commands;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class OpenFolderCommand extends Command {
   public OpenFolderCommand() {
      super("openfolder", new String[0]);
   }

   public void execute(String[] commands) {
      try {
         Desktop.getDesktop().open(new File("nhack4/"));
         Command.sendMessage("Opened config folder!", false);
      } catch (IOException var3) {
         Command.sendMessage("Could not open config folder!", false);
         var3.printStackTrace();
      }

   }
}
