package ryo.mrbubblegum.nhack4.system.command.commands;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class PornCommand extends Command {
   Desktop desktop = Desktop.getDesktop();

   public PornCommand() {
      super("porn", new String[]{"type"});
   }

   public void execute(String[] commands) {
      try {
         this.desktop.browse(new URI("https://www.pornhub.com/video/search?search=" + URLEncoder.encode(commands[0])));
      } catch (IOException var3) {
         var3.printStackTrace();
      } catch (URISyntaxException var4) {
         var4.printStackTrace();
      }

   }
}
