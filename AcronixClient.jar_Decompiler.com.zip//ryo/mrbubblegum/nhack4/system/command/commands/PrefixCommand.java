package ryo.mrbubblegum.nhack4.system.command.commands;

import ryo.mrbubblegum.nhack4.lite.client.ClickGui;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class PrefixCommand extends Command {
   public PrefixCommand() {
      super("prefix", new String[]{"<char>"});
   }

   public void execute(String[] commands) {
      if (commands.length == 1) {
         Command.sendMessage("§cSpecify a new prefix.");
      } else {
         ((ClickGui)Loader.moduleManager.getModuleByClass(ClickGui.class)).prefix.setValue(commands[0]);
         Command.sendMessage("Prefix set to §a" + Loader.commandManager.getPrefix());
      }
   }
}
