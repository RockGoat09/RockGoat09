package ryo.mrbubblegum.nhack4.system.command.commands;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class QueueCommand extends Command {
   public QueueCommand() {
      super("queue", new String[]{"priority, regular"});
   }

   public void execute(String[] commands) {
      if (commands.length != 1 && commands.length != 0) {
         String sURL = "https://2bqueue.info/*";
         String adjsaofj = commands[0];
         URL url;
         URLConnection request;
         JsonParser jp;
         JsonElement root;
         JsonObject rootobj;
         String aaaaaa;
         if (adjsaofj.equalsIgnoreCase("regular")) {
            try {
               url = new URL(sURL);
               request = url.openConnection();
               request.connect();
               jp = new JsonParser();
               root = jp.parse(new InputStreamReader((InputStream)request.getContent()));
               rootobj = root.getAsJsonObject();
               aaaaaa = rootobj.get("regular").getAsString();
               sendMessage("Regular queue currently have: " + aaaaaa);
            } catch (IOException var11) {
               var11.printStackTrace();
            }
         } else if (adjsaofj.equalsIgnoreCase("priority")) {
            try {
               url = new URL(sURL);
               request = url.openConnection();
               request.connect();
               jp = new JsonParser();
               root = jp.parse(new InputStreamReader((InputStream)request.getContent()));
               rootobj = root.getAsJsonObject();
               aaaaaa = rootobj.get("prio").getAsString();
               sendMessage("Priority queue currently have: " + aaaaaa);
            } catch (IOException var10) {
               var10.printStackTrace();
            }
         }

      } else {
         sendMessage("ayo, specify the type! (priority/regular)");
      }
   }
}
