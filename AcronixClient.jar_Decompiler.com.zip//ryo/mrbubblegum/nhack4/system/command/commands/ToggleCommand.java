package ryo.mrbubblegum.nhack4.system.command.commands;

import ryo.mrbubblegum.nhack4.lite.Module;
import ryo.mrbubblegum.nhack4.loader.Loader;
import ryo.mrbubblegum.nhack4.system.command.Command;

public class ToggleCommand extends Command {
   public ToggleCommand() {
      super("toggle", new String[]{"<toggle>", "<module>"});
   }

   public void execute(String[] commands) {
      if (commands.length == 2) {
         String name = commands[0].replaceAll("_", " ");
         Module module = Loader.moduleManager.getModuleByName(name);
         if (module != null) {
            module.toggle();
         } else {
            Command.sendMessage("Unable to find a module with that name!");
         }
      } else {
         Command.sendMessage("Please provide a valid module name!");
      }

   }
}
