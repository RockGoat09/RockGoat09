package ryo.mrbubblegum.nhack4.system.notifications;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import ryo.mrbubblegum.nhack4.impl.util.RenderUtil;
import ryo.mrbubblegum.nhack4.impl.util.Timer;
import ryo.mrbubblegum.nhack4.lite.hud.HUD;
import ryo.mrbubblegum.nhack4.loader.Loader;

public class Notifications {
   private final String text;
   private final long disableTime;
   private final float width;
   private final Timer timer = new Timer();

   public Notifications(String text, long disableTime) {
      this.text = text;
      this.disableTime = disableTime;
      this.width = (float)((HUD)Loader.moduleManager.getModuleByClass(HUD.class)).renderer.getStringWidth(text);
      this.timer.reset();
   }

   public void onDraw(int y) {
      ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
      if (this.timer.passedMs(this.disableTime)) {
         Loader.notificationManager.getNotifications().remove(this);
      }

      RenderUtil.drawRect((float)(scaledResolution.func_78326_a() - 4) - this.width, (float)y, (float)(scaledResolution.func_78326_a() - 2), (float)(y + ((HUD)Loader.moduleManager.getModuleByClass(HUD.class)).renderer.getFontHeight() + 3), 1962934272);
      ((HUD)Loader.moduleManager.getModuleByClass(HUD.class)).renderer.drawString(this.text, (float)scaledResolution.func_78326_a() - this.width - 3.0F, (float)(y + 2), -1, true);
   }
}
