package ryo.mrbubblegum.nhack4.world.events;

import ryo.mrbubblegum.nhack4.world.EventStage;

public class KeyEvent extends EventStage {
   public boolean info;
   public boolean pressed;

   public KeyEvent(int stage, boolean info, boolean pressed) {
      super(stage);
      this.info = info;
      this.pressed = pressed;
   }
}
