package ryo.mrbubblegum.nhack4.world.events;

public class PlayerUpdateEvent {
}
