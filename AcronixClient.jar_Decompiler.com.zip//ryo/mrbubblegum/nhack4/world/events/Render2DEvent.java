package ryo.mrbubblegum.nhack4.world.events;

import net.minecraft.client.gui.ScaledResolution;
import ryo.mrbubblegum.nhack4.world.EventStage;

public class Render2DEvent extends EventStage {
   public float partialTicks;
   public ScaledResolution scaledResolution;

   public Render2DEvent(float partialTicks, ScaledResolution scaledResolution) {
      this.partialTicks = partialTicks;
      this.scaledResolution = scaledResolution;
   }

   public void setPartialTicks(float partialTicks) {
      this.partialTicks = partialTicks;
   }

   public void setScaledResolution(ScaledResolution scaledResolution) {
      this.scaledResolution = scaledResolution;
   }

   public double getScreenWidth() {
      return this.scaledResolution.func_78327_c();
   }

   public double getScreenHeight() {
      return this.scaledResolution.func_78324_d();
   }
}
